!function (a, b) {
    'object' == typeof module && 'object' == typeof module.exports ? module.exports = a.document ? b(a, !0) : function (a) {
        if (!a.document)
            throw new Error('jQuery requires a window with a document');
        return b(a);
    } : b(a);
}('undefined' != typeof window ? window : this, function (a, b) {
    var c = [], d = c.slice, e = c.concat, f = c.push, g = c.indexOf, h = {}, i = h.toString, j = h.hasOwnProperty, k = {}, l = '1.11.3', m = function (a, b) {
            return new m.fn.init(a, b);
        }, n = /^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, o = /^-ms-/, p = /-([\da-z])/gi, q = function (a, b) {
            return b.toUpperCase();
        };
    m.fn = m.prototype = {
        jquery: l,
        constructor: m,
        selector: '',
        length: 0,
        toArray: function () {
            return d.call(this);
        },
        get: function (a) {
            return null != a ? 0 > a ? this[a + this.length] : this[a] : d.call(this);
        },
        pushStack: function (a) {
            var b = m.merge(this.constructor(), a);
            return b.prevObject = this, b.context = this.context, b;
        },
        each: function (a, b) {
            return m.each(this, a, b);
        },
        map: function (a) {
            return this.pushStack(m.map(this, function (b, c) {
                return a.call(b, c, b);
            }));
        },
        slice: function () {
            return this.pushStack(d.apply(this, arguments));
        },
        first: function () {
            return this.eq(0);
        },
        last: function () {
            return this.eq(-1);
        },
        eq: function (a) {
            var b = this.length, c = +a + (0 > a ? b : 0);
            return this.pushStack(c >= 0 && b > c ? [this[c]] : []);
        },
        end: function () {
            return this.prevObject || this.constructor(null);
        },
        push: f,
        sort: c.sort,
        splice: c.splice
    }, m.extend = m.fn.extend = function () {
        var a, b, c, d, e, f, g = arguments[0] || {}, h = 1, i = arguments.length, j = !1;
        for ('boolean' == typeof g && (j = g, g = arguments[h] || {}, h++), 'object' == typeof g || m.isFunction(g) || (g = {}), h === i && (g = this, h--); i > h; h++)
            if (null != (e = arguments[h]))
                for (d in e)
                    a = g[d], c = e[d], g !== c && (j && c && (m.isPlainObject(c) || (b = m.isArray(c))) ? (b ? (b = !1, f = a && m.isArray(a) ? a : []) : f = a && m.isPlainObject(a) ? a : {}, g[d] = m.extend(j, f, c)) : void 0 !== c && (g[d] = c));
        return g;
    }, m.extend({
        expando: 'jQuery' + (l + Math.random()).replace(/\D/g, ''),
        isReady: !0,
        error: function (a) {
            throw new Error(a);
        },
        noop: function () {
        },
        isFunction: function (a) {
            return 'function' === m.type(a);
        },
        isArray: Array.isArray || function (a) {
            return 'array' === m.type(a);
        },
        isWindow: function (a) {
            return null != a && a == a.window;
        },
        isNumeric: function (a) {
            return !m.isArray(a) && a - parseFloat(a) + 1 >= 0;
        },
        isEmptyObject: function (a) {
            var b;
            for (b in a)
                return !1;
            return !0;
        },
        isPlainObject: function (a) {
            var b;
            if (!a || 'object' !== m.type(a) || a.nodeType || m.isWindow(a))
                return !1;
            try {
                if (a.constructor && !j.call(a, 'constructor') && !j.call(a.constructor.prototype, 'isPrototypeOf'))
                    return !1;
            } catch (c) {
                return !1;
            }
            if (k.ownLast)
                for (b in a)
                    return j.call(a, b);
            for (b in a);
            return void 0 === b || j.call(a, b);
        },
        type: function (a) {
            return null == a ? a + '' : 'object' == typeof a || 'function' == typeof a ? h[i.call(a)] || 'object' : typeof a;
        },
        globalEval: function (b) {
            b && m.trim(b) && (a.execScript || function (b) {
                a.eval.call(a, b);
            })(b);
        },
        camelCase: function (a) {
            return a.replace(o, 'ms-').replace(p, q);
        },
        nodeName: function (a, b) {
            return a.nodeName && a.nodeName.toLowerCase() === b.toLowerCase();
        },
        each: function (a, b, c) {
            var d, e = 0, f = a.length, g = r(a);
            if (c) {
                if (g) {
                    for (; f > e; e++)
                        if (d = b.apply(a[e], c), d === !1)
                            break;
                } else
                    for (e in a)
                        if (d = b.apply(a[e], c), d === !1)
                            break;
            } else if (g) {
                for (; f > e; e++)
                    if (d = b.call(a[e], e, a[e]), d === !1)
                        break;
            } else
                for (e in a)
                    if (d = b.call(a[e], e, a[e]), d === !1)
                        break;
            return a;
        },
        trim: function (a) {
            return null == a ? '' : (a + '').replace(n, '');
        },
        makeArray: function (a, b) {
            var c = b || [];
            return null != a && (r(Object(a)) ? m.merge(c, 'string' == typeof a ? [a] : a) : f.call(c, a)), c;
        },
        inArray: function (a, b, c) {
            var d;
            if (b) {
                if (g)
                    return g.call(b, a, c);
                for (d = b.length, c = c ? 0 > c ? Math.max(0, d + c) : c : 0; d > c; c++)
                    if (c in b && b[c] === a)
                        return c;
            }
            return -1;
        },
        merge: function (a, b) {
            var c = +b.length, d = 0, e = a.length;
            while (c > d)
                a[e++] = b[d++];
            if (c !== c)
                while (void 0 !== b[d])
                    a[e++] = b[d++];
            return a.length = e, a;
        },
        grep: function (a, b, c) {
            for (var d, e = [], f = 0, g = a.length, h = !c; g > f; f++)
                d = !b(a[f], f), d !== h && e.push(a[f]);
            return e;
        },
        map: function (a, b, c) {
            var d, f = 0, g = a.length, h = r(a), i = [];
            if (h)
                for (; g > f; f++)
                    d = b(a[f], f, c), null != d && i.push(d);
            else
                for (f in a)
                    d = b(a[f], f, c), null != d && i.push(d);
            return e.apply([], i);
        },
        guid: 1,
        proxy: function (a, b) {
            var c, e, f;
            return 'string' == typeof b && (f = a[b], b = a, a = f), m.isFunction(a) ? (c = d.call(arguments, 2), e = function () {
                return a.apply(b || this, c.concat(d.call(arguments)));
            }, e.guid = a.guid = a.guid || m.guid++, e) : void 0;
        },
        now: function () {
            return +new Date();
        },
        support: k
    }), m.each('Boolean Number String Function Array Date RegExp Object Error'.split(' '), function (a, b) {
        h['[object ' + b + ']'] = b.toLowerCase();
    });
    function r(a) {
        var b = 'length' in a && a.length, c = m.type(a);
        return 'function' === c || m.isWindow(a) ? !1 : 1 === a.nodeType && b ? !0 : 'array' === c || 0 === b || 'number' == typeof b && b > 0 && b - 1 in a;
    }
    var s = function (a) {
        var b, c, d, e, f, g, h, i, j, k, l, m, n, o, p, q, r, s, t, u = 'sizzle' + 1 * new Date(), v = a.document, w = 0, x = 0, y = ha(), z = ha(), A = ha(), B = function (a, b) {
                return a === b && (l = !0), 0;
            }, C = 1 << 31, D = {}.hasOwnProperty, E = [], F = E.pop, G = E.push, H = E.push, I = E.slice, J = function (a, b) {
                for (var c = 0, d = a.length; d > c; c++)
                    if (a[c] === b)
                        return c;
                return -1;
            }, K = 'checked|selected|async|autofocus|autoplay|controls|defer|disabled|hidden|ismap|loop|multiple|open|readonly|required|scoped', L = '[\\x20\\t\\r\\n\\f]', M = '(?:\\\\.|[\\w-]|[^\\x00-\\xa0])+', N = M.replace('w', 'w#'), O = '\\[' + L + '*(' + M + ')(?:' + L + '*([*^$|!~]?=)' + L + '*(?:\'((?:\\\\.|[^\\\\\'])*)\'|"((?:\\\\.|[^\\\\"])*)"|(' + N + '))|)' + L + '*\\]', P = ':(' + M + ')(?:\\(((\'((?:\\\\.|[^\\\\\'])*)\'|"((?:\\\\.|[^\\\\"])*)")|((?:\\\\.|[^\\\\()[\\]]|' + O + ')*)|.*)\\)|)', Q = new RegExp(L + '+', 'g'), R = new RegExp('^' + L + '+|((?:^|[^\\\\])(?:\\\\.)*)' + L + '+$', 'g'), S = new RegExp('^' + L + '*,' + L + '*'), T = new RegExp('^' + L + '*([>+~]|' + L + ')' + L + '*'), U = new RegExp('=' + L + '*([^\\]\'"]*?)' + L + '*\\]', 'g'), V = new RegExp(P), W = new RegExp('^' + N + '$'), X = {
                ID: new RegExp('^#(' + M + ')'),
                CLASS: new RegExp('^\\.(' + M + ')'),
                TAG: new RegExp('^(' + M.replace('w', 'w*') + ')'),
                ATTR: new RegExp('^' + O),
                PSEUDO: new RegExp('^' + P),
                CHILD: new RegExp('^:(only|first|last|nth|nth-last)-(child|of-type)(?:\\(' + L + '*(even|odd|(([+-]|)(\\d*)n|)' + L + '*(?:([+-]|)' + L + '*(\\d+)|))' + L + '*\\)|)', 'i'),
                bool: new RegExp('^(?:' + K + ')$', 'i'),
                needsContext: new RegExp('^' + L + '*[>+~]|:(even|odd|eq|gt|lt|nth|first|last)(?:\\(' + L + '*((?:-\\d)?\\d*)' + L + '*\\)|)(?=[^-]|$)', 'i')
            }, Y = /^(?:input|select|textarea|button)$/i, Z = /^h\d$/i, $ = /^[^{]+\{\s*\[native \w/, _ = /^(?:#([\w-]+)|(\w+)|\.([\w-]+))$/, aa = /[+~]/, ba = /'|\\/g, ca = new RegExp('\\\\([\\da-f]{1,6}' + L + '?|(' + L + ')|.)', 'ig'), da = function (a, b, c) {
                var d = '0x' + b - 65536;
                return d !== d || c ? b : 0 > d ? String.fromCharCode(d + 65536) : String.fromCharCode(d >> 10 | 55296, 1023 & d | 56320);
            }, ea = function () {
                m();
            };
        try {
            H.apply(E = I.call(v.childNodes), v.childNodes), E[v.childNodes.length].nodeType;
        } catch (fa) {
            H = {
                apply: E.length ? function (a, b) {
                    G.apply(a, I.call(b));
                } : function (a, b) {
                    var c = a.length, d = 0;
                    while (a[c++] = b[d++]);
                    a.length = c - 1;
                }
            };
        }
        function ga(a, b, d, e) {
            var f, h, j, k, l, o, r, s, w, x;
            if ((b ? b.ownerDocument || b : v) !== n && m(b), b = b || n, d = d || [], k = b.nodeType, 'string' != typeof a || !a || 1 !== k && 9 !== k && 11 !== k)
                return d;
            if (!e && p) {
                if (11 !== k && (f = _.exec(a)))
                    if (j = f[1]) {
                        if (9 === k) {
                            if (h = b.getElementById(j), !h || !h.parentNode)
                                return d;
                            if (h.id === j)
                                return d.push(h), d;
                        } else if (b.ownerDocument && (h = b.ownerDocument.getElementById(j)) && t(b, h) && h.id === j)
                            return d.push(h), d;
                    } else {
                        if (f[2])
                            return H.apply(d, b.getElementsByTagName(a)), d;
                        if ((j = f[3]) && c.getElementsByClassName)
                            return H.apply(d, b.getElementsByClassName(j)), d;
                    }
                if (c.qsa && (!q || !q.test(a))) {
                    if (s = r = u, w = b, x = 1 !== k && a, 1 === k && 'object' !== b.nodeName.toLowerCase()) {
                        o = g(a), (r = b.getAttribute('id')) ? s = r.replace(ba, '\\$&') : b.setAttribute('id', s), s = '[id=\'' + s + '\'] ', l = o.length;
                        while (l--)
                            o[l] = s + ra(o[l]);
                        w = aa.test(a) && pa(b.parentNode) || b, x = o.join(',');
                    }
                    if (x)
                        try {
                            return H.apply(d, w.querySelectorAll(x)), d;
                        } catch (y) {
                        } finally {
                            r || b.removeAttribute('id');
                        }
                }
            }
            return i(a.replace(R, '$1'), b, d, e);
        }
        function ha() {
            var a = [];
            function b(c, e) {
                return a.push(c + ' ') > d.cacheLength && delete b[a.shift()], b[c + ' '] = e;
            }
            return b;
        }
        function ia(a) {
            return a[u] = !0, a;
        }
        function ja(a) {
            var b = n.createElement('div');
            try {
                return !!a(b);
            } catch (c) {
                return !1;
            } finally {
                b.parentNode && b.parentNode.removeChild(b), b = null;
            }
        }
        function ka(a, b) {
            var c = a.split('|'), e = a.length;
            while (e--)
                d.attrHandle[c[e]] = b;
        }
        function la(a, b) {
            var c = b && a, d = c && 1 === a.nodeType && 1 === b.nodeType && (~b.sourceIndex || C) - (~a.sourceIndex || C);
            if (d)
                return d;
            if (c)
                while (c = c.nextSibling)
                    if (c === b)
                        return -1;
            return a ? 1 : -1;
        }
        function ma(a) {
            return function (b) {
                var c = b.nodeName.toLowerCase();
                return 'input' === c && b.type === a;
            };
        }
        function na(a) {
            return function (b) {
                var c = b.nodeName.toLowerCase();
                return ('input' === c || 'button' === c) && b.type === a;
            };
        }
        function oa(a) {
            return ia(function (b) {
                return b = +b, ia(function (c, d) {
                    var e, f = a([], c.length, b), g = f.length;
                    while (g--)
                        c[e = f[g]] && (c[e] = !(d[e] = c[e]));
                });
            });
        }
        function pa(a) {
            return a && 'undefined' != typeof a.getElementsByTagName && a;
        }
        c = ga.support = {}, f = ga.isXML = function (a) {
            var b = a && (a.ownerDocument || a).documentElement;
            return b ? 'HTML' !== b.nodeName : !1;
        }, m = ga.setDocument = function (a) {
            var b, e, g = a ? a.ownerDocument || a : v;
            return g !== n && 9 === g.nodeType && g.documentElement ? (n = g, o = g.documentElement, e = g.defaultView, e && e !== e.top && (e.addEventListener ? e.addEventListener('unload', ea, !1) : e.attachEvent && e.attachEvent('onunload', ea)), p = !f(g), c.attributes = ja(function (a) {
                return a.className = 'i', !a.getAttribute('className');
            }), c.getElementsByTagName = ja(function (a) {
                return a.appendChild(g.createComment('')), !a.getElementsByTagName('*').length;
            }), c.getElementsByClassName = $.test(g.getElementsByClassName), c.getById = ja(function (a) {
                return o.appendChild(a).id = u, !g.getElementsByName || !g.getElementsByName(u).length;
            }), c.getById ? (d.find.ID = function (a, b) {
                if ('undefined' != typeof b.getElementById && p) {
                    var c = b.getElementById(a);
                    return c && c.parentNode ? [c] : [];
                }
            }, d.filter.ID = function (a) {
                var b = a.replace(ca, da);
                return function (a) {
                    return a.getAttribute('id') === b;
                };
            }) : (delete d.find.ID, d.filter.ID = function (a) {
                var b = a.replace(ca, da);
                return function (a) {
                    var c = 'undefined' != typeof a.getAttributeNode && a.getAttributeNode('id');
                    return c && c.value === b;
                };
            }), d.find.TAG = c.getElementsByTagName ? function (a, b) {
                return 'undefined' != typeof b.getElementsByTagName ? b.getElementsByTagName(a) : c.qsa ? b.querySelectorAll(a) : void 0;
            } : function (a, b) {
                var c, d = [], e = 0, f = b.getElementsByTagName(a);
                if ('*' === a) {
                    while (c = f[e++])
                        1 === c.nodeType && d.push(c);
                    return d;
                }
                return f;
            }, d.find.CLASS = c.getElementsByClassName && function (a, b) {
                return p ? b.getElementsByClassName(a) : void 0;
            }, r = [], q = [], (c.qsa = $.test(g.querySelectorAll)) && (ja(function (a) {
                o.appendChild(a).innerHTML = '<a id=\'' + u + '\'></a><select id=\'' + u + '-\f]\' msallowcapture=\'\'><option selected=\'\'></option></select>', a.querySelectorAll('[msallowcapture^=\'\']').length && q.push('[*^$]=' + L + '*(?:\'\'|"")'), a.querySelectorAll('[selected]').length || q.push('\\[' + L + '*(?:value|' + K + ')'), a.querySelectorAll('[id~=' + u + '-]').length || q.push('~='), a.querySelectorAll(':checked').length || q.push(':checked'), a.querySelectorAll('a#' + u + '+*').length || q.push('.#.+[+~]');
            }), ja(function (a) {
                var b = g.createElement('input');
                b.setAttribute('type', 'hidden'), a.appendChild(b).setAttribute('name', 'D'), a.querySelectorAll('[name=d]').length && q.push('name' + L + '*[*^$|!~]?='), a.querySelectorAll(':enabled').length || q.push(':enabled', ':disabled'), a.querySelectorAll('*,:x'), q.push(',.*:');
            })), (c.matchesSelector = $.test(s = o.matches || o.webkitMatchesSelector || o.mozMatchesSelector || o.oMatchesSelector || o.msMatchesSelector)) && ja(function (a) {
                c.disconnectedMatch = s.call(a, 'div'), s.call(a, '[s!=\'\']:x'), r.push('!=', P);
            }), q = q.length && new RegExp(q.join('|')), r = r.length && new RegExp(r.join('|')), b = $.test(o.compareDocumentPosition), t = b || $.test(o.contains) ? function (a, b) {
                var c = 9 === a.nodeType ? a.documentElement : a, d = b && b.parentNode;
                return a === d || !(!d || 1 !== d.nodeType || !(c.contains ? c.contains(d) : a.compareDocumentPosition && 16 & a.compareDocumentPosition(d)));
            } : function (a, b) {
                if (b)
                    while (b = b.parentNode)
                        if (b === a)
                            return !0;
                return !1;
            }, B = b ? function (a, b) {
                if (a === b)
                    return l = !0, 0;
                var d = !a.compareDocumentPosition - !b.compareDocumentPosition;
                return d ? d : (d = (a.ownerDocument || a) === (b.ownerDocument || b) ? a.compareDocumentPosition(b) : 1, 1 & d || !c.sortDetached && b.compareDocumentPosition(a) === d ? a === g || a.ownerDocument === v && t(v, a) ? -1 : b === g || b.ownerDocument === v && t(v, b) ? 1 : k ? J(k, a) - J(k, b) : 0 : 4 & d ? -1 : 1);
            } : function (a, b) {
                if (a === b)
                    return l = !0, 0;
                var c, d = 0, e = a.parentNode, f = b.parentNode, h = [a], i = [b];
                if (!e || !f)
                    return a === g ? -1 : b === g ? 1 : e ? -1 : f ? 1 : k ? J(k, a) - J(k, b) : 0;
                if (e === f)
                    return la(a, b);
                c = a;
                while (c = c.parentNode)
                    h.unshift(c);
                c = b;
                while (c = c.parentNode)
                    i.unshift(c);
                while (h[d] === i[d])
                    d++;
                return d ? la(h[d], i[d]) : h[d] === v ? -1 : i[d] === v ? 1 : 0;
            }, g) : n;
        }, ga.matches = function (a, b) {
            return ga(a, null, null, b);
        }, ga.matchesSelector = function (a, b) {
            if ((a.ownerDocument || a) !== n && m(a), b = b.replace(U, '=\'$1\']'), !(!c.matchesSelector || !p || r && r.test(b) || q && q.test(b)))
                try {
                    var d = s.call(a, b);
                    if (d || c.disconnectedMatch || a.document && 11 !== a.document.nodeType)
                        return d;
                } catch (e) {
                }
            return ga(b, n, null, [a]).length > 0;
        }, ga.contains = function (a, b) {
            return (a.ownerDocument || a) !== n && m(a), t(a, b);
        }, ga.attr = function (a, b) {
            (a.ownerDocument || a) !== n && m(a);
            var e = d.attrHandle[b.toLowerCase()], f = e && D.call(d.attrHandle, b.toLowerCase()) ? e(a, b, !p) : void 0;
            return void 0 !== f ? f : c.attributes || !p ? a.getAttribute(b) : (f = a.getAttributeNode(b)) && f.specified ? f.value : null;
        }, ga.error = function (a) {
            throw new Error('Syntax error, unrecognized expression: ' + a);
        }, ga.uniqueSort = function (a) {
            var b, d = [], e = 0, f = 0;
            if (l = !c.detectDuplicates, k = !c.sortStable && a.slice(0), a.sort(B), l) {
                while (b = a[f++])
                    b === a[f] && (e = d.push(f));
                while (e--)
                    a.splice(d[e], 1);
            }
            return k = null, a;
        }, e = ga.getText = function (a) {
            var b, c = '', d = 0, f = a.nodeType;
            if (f) {
                if (1 === f || 9 === f || 11 === f) {
                    if ('string' == typeof a.textContent)
                        return a.textContent;
                    for (a = a.firstChild; a; a = a.nextSibling)
                        c += e(a);
                } else if (3 === f || 4 === f)
                    return a.nodeValue;
            } else
                while (b = a[d++])
                    c += e(b);
            return c;
        }, d = ga.selectors = {
            cacheLength: 50,
            createPseudo: ia,
            match: X,
            attrHandle: {},
            find: {},
            relative: {
                '>': {
                    dir: 'parentNode',
                    first: !0
                },
                ' ': { dir: 'parentNode' },
                '+': {
                    dir: 'previousSibling',
                    first: !0
                },
                '~': { dir: 'previousSibling' }
            },
            preFilter: {
                ATTR: function (a) {
                    return a[1] = a[1].replace(ca, da), a[3] = (a[3] || a[4] || a[5] || '').replace(ca, da), '~=' === a[2] && (a[3] = ' ' + a[3] + ' '), a.slice(0, 4);
                },
                CHILD: function (a) {
                    return a[1] = a[1].toLowerCase(), 'nth' === a[1].slice(0, 3) ? (a[3] || ga.error(a[0]), a[4] = +(a[4] ? a[5] + (a[6] || 1) : 2 * ('even' === a[3] || 'odd' === a[3])), a[5] = +(a[7] + a[8] || 'odd' === a[3])) : a[3] && ga.error(a[0]), a;
                },
                PSEUDO: function (a) {
                    var b, c = !a[6] && a[2];
                    return X.CHILD.test(a[0]) ? null : (a[3] ? a[2] = a[4] || a[5] || '' : c && V.test(c) && (b = g(c, !0)) && (b = c.indexOf(')', c.length - b) - c.length) && (a[0] = a[0].slice(0, b), a[2] = c.slice(0, b)), a.slice(0, 3));
                }
            },
            filter: {
                TAG: function (a) {
                    var b = a.replace(ca, da).toLowerCase();
                    return '*' === a ? function () {
                        return !0;
                    } : function (a) {
                        return a.nodeName && a.nodeName.toLowerCase() === b;
                    };
                },
                CLASS: function (a) {
                    var b = y[a + ' '];
                    return b || (b = new RegExp('(^|' + L + ')' + a + '(' + L + '|$)')) && y(a, function (a) {
                        return b.test('string' == typeof a.className && a.className || 'undefined' != typeof a.getAttribute && a.getAttribute('class') || '');
                    });
                },
                ATTR: function (a, b, c) {
                    return function (d) {
                        var e = ga.attr(d, a);
                        return null == e ? '!=' === b : b ? (e += '', '=' === b ? e === c : '!=' === b ? e !== c : '^=' === b ? c && 0 === e.indexOf(c) : '*=' === b ? c && e.indexOf(c) > -1 : '$=' === b ? c && e.slice(-c.length) === c : '~=' === b ? (' ' + e.replace(Q, ' ') + ' ').indexOf(c) > -1 : '|=' === b ? e === c || e.slice(0, c.length + 1) === c + '-' : !1) : !0;
                    };
                },
                CHILD: function (a, b, c, d, e) {
                    var f = 'nth' !== a.slice(0, 3), g = 'last' !== a.slice(-4), h = 'of-type' === b;
                    return 1 === d && 0 === e ? function (a) {
                        return !!a.parentNode;
                    } : function (b, c, i) {
                        var j, k, l, m, n, o, p = f !== g ? 'nextSibling' : 'previousSibling', q = b.parentNode, r = h && b.nodeName.toLowerCase(), s = !i && !h;
                        if (q) {
                            if (f) {
                                while (p) {
                                    l = b;
                                    while (l = l[p])
                                        if (h ? l.nodeName.toLowerCase() === r : 1 === l.nodeType)
                                            return !1;
                                    o = p = 'only' === a && !o && 'nextSibling';
                                }
                                return !0;
                            }
                            if (o = [g ? q.firstChild : q.lastChild], g && s) {
                                k = q[u] || (q[u] = {}), j = k[a] || [], n = j[0] === w && j[1], m = j[0] === w && j[2], l = n && q.childNodes[n];
                                while (l = ++n && l && l[p] || (m = n = 0) || o.pop())
                                    if (1 === l.nodeType && ++m && l === b) {
                                        k[a] = [
                                            w,
                                            n,
                                            m
                                        ];
                                        break;
                                    }
                            } else if (s && (j = (b[u] || (b[u] = {}))[a]) && j[0] === w)
                                m = j[1];
                            else
                                while (l = ++n && l && l[p] || (m = n = 0) || o.pop())
                                    if ((h ? l.nodeName.toLowerCase() === r : 1 === l.nodeType) && ++m && (s && ((l[u] || (l[u] = {}))[a] = [
                                            w,
                                            m
                                        ]), l === b))
                                        break;
                            return m -= e, m === d || m % d === 0 && m / d >= 0;
                        }
                    };
                },
                PSEUDO: function (a, b) {
                    var c, e = d.pseudos[a] || d.setFilters[a.toLowerCase()] || ga.error('unsupported pseudo: ' + a);
                    return e[u] ? e(b) : e.length > 1 ? (c = [
                        a,
                        a,
                        '',
                        b
                    ], d.setFilters.hasOwnProperty(a.toLowerCase()) ? ia(function (a, c) {
                        var d, f = e(a, b), g = f.length;
                        while (g--)
                            d = J(a, f[g]), a[d] = !(c[d] = f[g]);
                    }) : function (a) {
                        return e(a, 0, c);
                    }) : e;
                }
            },
            pseudos: {
                not: ia(function (a) {
                    var b = [], c = [], d = h(a.replace(R, '$1'));
                    return d[u] ? ia(function (a, b, c, e) {
                        var f, g = d(a, null, e, []), h = a.length;
                        while (h--)
                            (f = g[h]) && (a[h] = !(b[h] = f));
                    }) : function (a, e, f) {
                        return b[0] = a, d(b, null, f, c), b[0] = null, !c.pop();
                    };
                }),
                has: ia(function (a) {
                    return function (b) {
                        return ga(a, b).length > 0;
                    };
                }),
                contains: ia(function (a) {
                    return a = a.replace(ca, da), function (b) {
                        return (b.textContent || b.innerText || e(b)).indexOf(a) > -1;
                    };
                }),
                lang: ia(function (a) {
                    return W.test(a || '') || ga.error('unsupported lang: ' + a), a = a.replace(ca, da).toLowerCase(), function (b) {
                        var c;
                        do
                            if (c = p ? b.lang : b.getAttribute('xml:lang') || b.getAttribute('lang'))
                                return c = c.toLowerCase(), c === a || 0 === c.indexOf(a + '-');
                        while ((b = b.parentNode) && 1 === b.nodeType);
                        return !1;
                    };
                }),
                target: function (b) {
                    var c = a.location && a.location.hash;
                    return c && c.slice(1) === b.id;
                },
                root: function (a) {
                    return a === o;
                },
                focus: function (a) {
                    return a === n.activeElement && (!n.hasFocus || n.hasFocus()) && !!(a.type || a.href || ~a.tabIndex);
                },
                enabled: function (a) {
                    return a.disabled === !1;
                },
                disabled: function (a) {
                    return a.disabled === !0;
                },
                checked: function (a) {
                    var b = a.nodeName.toLowerCase();
                    return 'input' === b && !!a.checked || 'option' === b && !!a.selected;
                },
                selected: function (a) {
                    return a.parentNode && a.parentNode.selectedIndex, a.selected === !0;
                },
                empty: function (a) {
                    for (a = a.firstChild; a; a = a.nextSibling)
                        if (a.nodeType < 6)
                            return !1;
                    return !0;
                },
                parent: function (a) {
                    return !d.pseudos.empty(a);
                },
                header: function (a) {
                    return Z.test(a.nodeName);
                },
                input: function (a) {
                    return Y.test(a.nodeName);
                },
                button: function (a) {
                    var b = a.nodeName.toLowerCase();
                    return 'input' === b && 'button' === a.type || 'button' === b;
                },
                text: function (a) {
                    var b;
                    return 'input' === a.nodeName.toLowerCase() && 'text' === a.type && (null == (b = a.getAttribute('type')) || 'text' === b.toLowerCase());
                },
                first: oa(function () {
                    return [0];
                }),
                last: oa(function (a, b) {
                    return [b - 1];
                }),
                eq: oa(function (a, b, c) {
                    return [0 > c ? c + b : c];
                }),
                even: oa(function (a, b) {
                    for (var c = 0; b > c; c += 2)
                        a.push(c);
                    return a;
                }),
                odd: oa(function (a, b) {
                    for (var c = 1; b > c; c += 2)
                        a.push(c);
                    return a;
                }),
                lt: oa(function (a, b, c) {
                    for (var d = 0 > c ? c + b : c; --d >= 0;)
                        a.push(d);
                    return a;
                }),
                gt: oa(function (a, b, c) {
                    for (var d = 0 > c ? c + b : c; ++d < b;)
                        a.push(d);
                    return a;
                })
            }
        }, d.pseudos.nth = d.pseudos.eq;
        for (b in {
                radio: !0,
                checkbox: !0,
                file: !0,
                password: !0,
                image: !0
            })
            d.pseudos[b] = ma(b);
        for (b in {
                submit: !0,
                reset: !0
            })
            d.pseudos[b] = na(b);
        function qa() {
        }
        qa.prototype = d.filters = d.pseudos, d.setFilters = new qa(), g = ga.tokenize = function (a, b) {
            var c, e, f, g, h, i, j, k = z[a + ' '];
            if (k)
                return b ? 0 : k.slice(0);
            h = a, i = [], j = d.preFilter;
            while (h) {
                (!c || (e = S.exec(h))) && (e && (h = h.slice(e[0].length) || h), i.push(f = [])), c = !1, (e = T.exec(h)) && (c = e.shift(), f.push({
                    value: c,
                    type: e[0].replace(R, ' ')
                }), h = h.slice(c.length));
                for (g in d.filter)
                    !(e = X[g].exec(h)) || j[g] && !(e = j[g](e)) || (c = e.shift(), f.push({
                        value: c,
                        type: g,
                        matches: e
                    }), h = h.slice(c.length));
                if (!c)
                    break;
            }
            return b ? h.length : h ? ga.error(a) : z(a, i).slice(0);
        };
        function ra(a) {
            for (var b = 0, c = a.length, d = ''; c > b; b++)
                d += a[b].value;
            return d;
        }
        function sa(a, b, c) {
            var d = b.dir, e = c && 'parentNode' === d, f = x++;
            return b.first ? function (b, c, f) {
                while (b = b[d])
                    if (1 === b.nodeType || e)
                        return a(b, c, f);
            } : function (b, c, g) {
                var h, i, j = [
                        w,
                        f
                    ];
                if (g) {
                    while (b = b[d])
                        if ((1 === b.nodeType || e) && a(b, c, g))
                            return !0;
                } else
                    while (b = b[d])
                        if (1 === b.nodeType || e) {
                            if (i = b[u] || (b[u] = {}), (h = i[d]) && h[0] === w && h[1] === f)
                                return j[2] = h[2];
                            if (i[d] = j, j[2] = a(b, c, g))
                                return !0;
                        }
            };
        }
        function ta(a) {
            return a.length > 1 ? function (b, c, d) {
                var e = a.length;
                while (e--)
                    if (!a[e](b, c, d))
                        return !1;
                return !0;
            } : a[0];
        }
        function ua(a, b, c) {
            for (var d = 0, e = b.length; e > d; d++)
                ga(a, b[d], c);
            return c;
        }
        function va(a, b, c, d, e) {
            for (var f, g = [], h = 0, i = a.length, j = null != b; i > h; h++)
                (f = a[h]) && (!c || c(f, d, e)) && (g.push(f), j && b.push(h));
            return g;
        }
        function wa(a, b, c, d, e, f) {
            return d && !d[u] && (d = wa(d)), e && !e[u] && (e = wa(e, f)), ia(function (f, g, h, i) {
                var j, k, l, m = [], n = [], o = g.length, p = f || ua(b || '*', h.nodeType ? [h] : h, []), q = !a || !f && b ? p : va(p, m, a, h, i), r = c ? e || (f ? a : o || d) ? [] : g : q;
                if (c && c(q, r, h, i), d) {
                    j = va(r, n), d(j, [], h, i), k = j.length;
                    while (k--)
                        (l = j[k]) && (r[n[k]] = !(q[n[k]] = l));
                }
                if (f) {
                    if (e || a) {
                        if (e) {
                            j = [], k = r.length;
                            while (k--)
                                (l = r[k]) && j.push(q[k] = l);
                            e(null, r = [], j, i);
                        }
                        k = r.length;
                        while (k--)
                            (l = r[k]) && (j = e ? J(f, l) : m[k]) > -1 && (f[j] = !(g[j] = l));
                    }
                } else
                    r = va(r === g ? r.splice(o, r.length) : r), e ? e(null, g, r, i) : H.apply(g, r);
            });
        }
        function xa(a) {
            for (var b, c, e, f = a.length, g = d.relative[a[0].type], h = g || d.relative[' '], i = g ? 1 : 0, k = sa(function (a) {
                        return a === b;
                    }, h, !0), l = sa(function (a) {
                        return J(b, a) > -1;
                    }, h, !0), m = [function (a, c, d) {
                            var e = !g && (d || c !== j) || ((b = c).nodeType ? k(a, c, d) : l(a, c, d));
                            return b = null, e;
                        }]; f > i; i++)
                if (c = d.relative[a[i].type])
                    m = [sa(ta(m), c)];
                else {
                    if (c = d.filter[a[i].type].apply(null, a[i].matches), c[u]) {
                        for (e = ++i; f > e; e++)
                            if (d.relative[a[e].type])
                                break;
                        return wa(i > 1 && ta(m), i > 1 && ra(a.slice(0, i - 1).concat({ value: ' ' === a[i - 2].type ? '*' : '' })).replace(R, '$1'), c, e > i && xa(a.slice(i, e)), f > e && xa(a = a.slice(e)), f > e && ra(a));
                    }
                    m.push(c);
                }
            return ta(m);
        }
        function ya(a, b) {
            var c = b.length > 0, e = a.length > 0, f = function (f, g, h, i, k) {
                    var l, m, o, p = 0, q = '0', r = f && [], s = [], t = j, u = f || e && d.find.TAG('*', k), v = w += null == t ? 1 : Math.random() || 0.1, x = u.length;
                    for (k && (j = g !== n && g); q !== x && null != (l = u[q]); q++) {
                        if (e && l) {
                            m = 0;
                            while (o = a[m++])
                                if (o(l, g, h)) {
                                    i.push(l);
                                    break;
                                }
                            k && (w = v);
                        }
                        c && ((l = !o && l) && p--, f && r.push(l));
                    }
                    if (p += q, c && q !== p) {
                        m = 0;
                        while (o = b[m++])
                            o(r, s, g, h);
                        if (f) {
                            if (p > 0)
                                while (q--)
                                    r[q] || s[q] || (s[q] = F.call(i));
                            s = va(s);
                        }
                        H.apply(i, s), k && !f && s.length > 0 && p + b.length > 1 && ga.uniqueSort(i);
                    }
                    return k && (w = v, j = t), r;
                };
            return c ? ia(f) : f;
        }
        return h = ga.compile = function (a, b) {
            var c, d = [], e = [], f = A[a + ' '];
            if (!f) {
                b || (b = g(a)), c = b.length;
                while (c--)
                    f = xa(b[c]), f[u] ? d.push(f) : e.push(f);
                f = A(a, ya(e, d)), f.selector = a;
            }
            return f;
        }, i = ga.select = function (a, b, e, f) {
            var i, j, k, l, m, n = 'function' == typeof a && a, o = !f && g(a = n.selector || a);
            if (e = e || [], 1 === o.length) {
                if (j = o[0] = o[0].slice(0), j.length > 2 && 'ID' === (k = j[0]).type && c.getById && 9 === b.nodeType && p && d.relative[j[1].type]) {
                    if (b = (d.find.ID(k.matches[0].replace(ca, da), b) || [])[0], !b)
                        return e;
                    n && (b = b.parentNode), a = a.slice(j.shift().value.length);
                }
                i = X.needsContext.test(a) ? 0 : j.length;
                while (i--) {
                    if (k = j[i], d.relative[l = k.type])
                        break;
                    if ((m = d.find[l]) && (f = m(k.matches[0].replace(ca, da), aa.test(j[0].type) && pa(b.parentNode) || b))) {
                        if (j.splice(i, 1), a = f.length && ra(j), !a)
                            return H.apply(e, f), e;
                        break;
                    }
                }
            }
            return (n || h(a, o))(f, b, !p, e, aa.test(a) && pa(b.parentNode) || b), e;
        }, c.sortStable = u.split('').sort(B).join('') === u, c.detectDuplicates = !!l, m(), c.sortDetached = ja(function (a) {
            return 1 & a.compareDocumentPosition(n.createElement('div'));
        }), ja(function (a) {
            return a.innerHTML = '<a href=\'#\'></a>', '#' === a.firstChild.getAttribute('href');
        }) || ka('type|href|height|width', function (a, b, c) {
            return c ? void 0 : a.getAttribute(b, 'type' === b.toLowerCase() ? 1 : 2);
        }), c.attributes && ja(function (a) {
            return a.innerHTML = '<input/>', a.firstChild.setAttribute('value', ''), '' === a.firstChild.getAttribute('value');
        }) || ka('value', function (a, b, c) {
            return c || 'input' !== a.nodeName.toLowerCase() ? void 0 : a.defaultValue;
        }), ja(function (a) {
            return null == a.getAttribute('disabled');
        }) || ka(K, function (a, b, c) {
            var d;
            return c ? void 0 : a[b] === !0 ? b.toLowerCase() : (d = a.getAttributeNode(b)) && d.specified ? d.value : null;
        }), ga;
    }(a);
    m.find = s, m.expr = s.selectors, m.expr[':'] = m.expr.pseudos, m.unique = s.uniqueSort, m.text = s.getText, m.isXMLDoc = s.isXML, m.contains = s.contains;
    var t = m.expr.match.needsContext, u = /^<(\w+)\s*\/?>(?:<\/\1>|)$/, v = /^.[^:#\[\.,]*$/;
    function w(a, b, c) {
        if (m.isFunction(b))
            return m.grep(a, function (a, d) {
                return !!b.call(a, d, a) !== c;
            });
        if (b.nodeType)
            return m.grep(a, function (a) {
                return a === b !== c;
            });
        if ('string' == typeof b) {
            if (v.test(b))
                return m.filter(b, a, c);
            b = m.filter(b, a);
        }
        return m.grep(a, function (a) {
            return m.inArray(a, b) >= 0 !== c;
        });
    }
    m.filter = function (a, b, c) {
        var d = b[0];
        return c && (a = ':not(' + a + ')'), 1 === b.length && 1 === d.nodeType ? m.find.matchesSelector(d, a) ? [d] : [] : m.find.matches(a, m.grep(b, function (a) {
            return 1 === a.nodeType;
        }));
    }, m.fn.extend({
        find: function (a) {
            var b, c = [], d = this, e = d.length;
            if ('string' != typeof a)
                return this.pushStack(m(a).filter(function () {
                    for (b = 0; e > b; b++)
                        if (m.contains(d[b], this))
                            return !0;
                }));
            for (b = 0; e > b; b++)
                m.find(a, d[b], c);
            return c = this.pushStack(e > 1 ? m.unique(c) : c), c.selector = this.selector ? this.selector + ' ' + a : a, c;
        },
        filter: function (a) {
            return this.pushStack(w(this, a || [], !1));
        },
        not: function (a) {
            return this.pushStack(w(this, a || [], !0));
        },
        is: function (a) {
            return !!w(this, 'string' == typeof a && t.test(a) ? m(a) : a || [], !1).length;
        }
    });
    var x, y = a.document, z = /^(?:\s*(<[\w\W]+>)[^>]*|#([\w-]*))$/, A = m.fn.init = function (a, b) {
            var c, d;
            if (!a)
                return this;
            if ('string' == typeof a) {
                if (c = '<' === a.charAt(0) && '>' === a.charAt(a.length - 1) && a.length >= 3 ? [
                        null,
                        a,
                        null
                    ] : z.exec(a), !c || !c[1] && b)
                    return !b || b.jquery ? (b || x).find(a) : this.constructor(b).find(a);
                if (c[1]) {
                    if (b = b instanceof m ? b[0] : b, m.merge(this, m.parseHTML(c[1], b && b.nodeType ? b.ownerDocument || b : y, !0)), u.test(c[1]) && m.isPlainObject(b))
                        for (c in b)
                            m.isFunction(this[c]) ? this[c](b[c]) : this.attr(c, b[c]);
                    return this;
                }
                if (d = y.getElementById(c[2]), d && d.parentNode) {
                    if (d.id !== c[2])
                        return x.find(a);
                    this.length = 1, this[0] = d;
                }
                return this.context = y, this.selector = a, this;
            }
            return a.nodeType ? (this.context = this[0] = a, this.length = 1, this) : m.isFunction(a) ? 'undefined' != typeof x.ready ? x.ready(a) : a(m) : (void 0 !== a.selector && (this.selector = a.selector, this.context = a.context), m.makeArray(a, this));
        };
    A.prototype = m.fn, x = m(y);
    var B = /^(?:parents|prev(?:Until|All))/, C = {
            children: !0,
            contents: !0,
            next: !0,
            prev: !0
        };
    m.extend({
        dir: function (a, b, c) {
            var d = [], e = a[b];
            while (e && 9 !== e.nodeType && (void 0 === c || 1 !== e.nodeType || !m(e).is(c)))
                1 === e.nodeType && d.push(e), e = e[b];
            return d;
        },
        sibling: function (a, b) {
            for (var c = []; a; a = a.nextSibling)
                1 === a.nodeType && a !== b && c.push(a);
            return c;
        }
    }), m.fn.extend({
        has: function (a) {
            var b, c = m(a, this), d = c.length;
            return this.filter(function () {
                for (b = 0; d > b; b++)
                    if (m.contains(this, c[b]))
                        return !0;
            });
        },
        closest: function (a, b) {
            for (var c, d = 0, e = this.length, f = [], g = t.test(a) || 'string' != typeof a ? m(a, b || this.context) : 0; e > d; d++)
                for (c = this[d]; c && c !== b; c = c.parentNode)
                    if (c.nodeType < 11 && (g ? g.index(c) > -1 : 1 === c.nodeType && m.find.matchesSelector(c, a))) {
                        f.push(c);
                        break;
                    }
            return this.pushStack(f.length > 1 ? m.unique(f) : f);
        },
        index: function (a) {
            return a ? 'string' == typeof a ? m.inArray(this[0], m(a)) : m.inArray(a.jquery ? a[0] : a, this) : this[0] && this[0].parentNode ? this.first().prevAll().length : -1;
        },
        add: function (a, b) {
            return this.pushStack(m.unique(m.merge(this.get(), m(a, b))));
        },
        addBack: function (a) {
            return this.add(null == a ? this.prevObject : this.prevObject.filter(a));
        }
    });
    function D(a, b) {
        do
            a = a[b];
        while (a && 1 !== a.nodeType);
        return a;
    }
    m.each({
        parent: function (a) {
            var b = a.parentNode;
            return b && 11 !== b.nodeType ? b : null;
        },
        parents: function (a) {
            return m.dir(a, 'parentNode');
        },
        parentsUntil: function (a, b, c) {
            return m.dir(a, 'parentNode', c);
        },
        next: function (a) {
            return D(a, 'nextSibling');
        },
        prev: function (a) {
            return D(a, 'previousSibling');
        },
        nextAll: function (a) {
            return m.dir(a, 'nextSibling');
        },
        prevAll: function (a) {
            return m.dir(a, 'previousSibling');
        },
        nextUntil: function (a, b, c) {
            return m.dir(a, 'nextSibling', c);
        },
        prevUntil: function (a, b, c) {
            return m.dir(a, 'previousSibling', c);
        },
        siblings: function (a) {
            return m.sibling((a.parentNode || {}).firstChild, a);
        },
        children: function (a) {
            return m.sibling(a.firstChild);
        },
        contents: function (a) {
            return m.nodeName(a, 'iframe') ? a.contentDocument || a.contentWindow.document : m.merge([], a.childNodes);
        }
    }, function (a, b) {
        m.fn[a] = function (c, d) {
            var e = m.map(this, b, c);
            return 'Until' !== a.slice(-5) && (d = c), d && 'string' == typeof d && (e = m.filter(d, e)), this.length > 1 && (C[a] || (e = m.unique(e)), B.test(a) && (e = e.reverse())), this.pushStack(e);
        };
    });
    var E = /\S+/g, F = {};
    function G(a) {
        var b = F[a] = {};
        return m.each(a.match(E) || [], function (a, c) {
            b[c] = !0;
        }), b;
    }
    m.Callbacks = function (a) {
        a = 'string' == typeof a ? F[a] || G(a) : m.extend({}, a);
        var b, c, d, e, f, g, h = [], i = !a.once && [], j = function (l) {
                for (c = a.memory && l, d = !0, f = g || 0, g = 0, e = h.length, b = !0; h && e > f; f++)
                    if (h[f].apply(l[0], l[1]) === !1 && a.stopOnFalse) {
                        c = !1;
                        break;
                    }
                b = !1, h && (i ? i.length && j(i.shift()) : c ? h = [] : k.disable());
            }, k = {
                add: function () {
                    if (h) {
                        var d = h.length;
                        !function f(b) {
                            m.each(b, function (b, c) {
                                var d = m.type(c);
                                'function' === d ? a.unique && k.has(c) || h.push(c) : c && c.length && 'string' !== d && f(c);
                            });
                        }(arguments), b ? e = h.length : c && (g = d, j(c));
                    }
                    return this;
                },
                remove: function () {
                    return h && m.each(arguments, function (a, c) {
                        var d;
                        while ((d = m.inArray(c, h, d)) > -1)
                            h.splice(d, 1), b && (e >= d && e--, f >= d && f--);
                    }), this;
                },
                has: function (a) {
                    return a ? m.inArray(a, h) > -1 : !(!h || !h.length);
                },
                empty: function () {
                    return h = [], e = 0, this;
                },
                disable: function () {
                    return h = i = c = void 0, this;
                },
                disabled: function () {
                    return !h;
                },
                lock: function () {
                    return i = void 0, c || k.disable(), this;
                },
                locked: function () {
                    return !i;
                },
                fireWith: function (a, c) {
                    return !h || d && !i || (c = c || [], c = [
                        a,
                        c.slice ? c.slice() : c
                    ], b ? i.push(c) : j(c)), this;
                },
                fire: function () {
                    return k.fireWith(this, arguments), this;
                },
                fired: function () {
                    return !!d;
                }
            };
        return k;
    }, m.extend({
        Deferred: function (a) {
            var b = [
                    [
                        'resolve',
                        'done',
                        m.Callbacks('once memory'),
                        'resolved'
                    ],
                    [
                        'reject',
                        'fail',
                        m.Callbacks('once memory'),
                        'rejected'
                    ],
                    [
                        'notify',
                        'progress',
                        m.Callbacks('memory')
                    ]
                ], c = 'pending', d = {
                    state: function () {
                        return c;
                    },
                    always: function () {
                        return e.done(arguments).fail(arguments), this;
                    },
                    then: function () {
                        var a = arguments;
                        return m.Deferred(function (c) {
                            m.each(b, function (b, f) {
                                var g = m.isFunction(a[b]) && a[b];
                                e[f[1]](function () {
                                    var a = g && g.apply(this, arguments);
                                    a && m.isFunction(a.promise) ? a.promise().done(c.resolve).fail(c.reject).progress(c.notify) : c[f[0] + 'With'](this === d ? c.promise() : this, g ? [a] : arguments);
                                });
                            }), a = null;
                        }).promise();
                    },
                    promise: function (a) {
                        return null != a ? m.extend(a, d) : d;
                    }
                }, e = {};
            return d.pipe = d.then, m.each(b, function (a, f) {
                var g = f[2], h = f[3];
                d[f[1]] = g.add, h && g.add(function () {
                    c = h;
                }, b[1 ^ a][2].disable, b[2][2].lock), e[f[0]] = function () {
                    return e[f[0] + 'With'](this === e ? d : this, arguments), this;
                }, e[f[0] + 'With'] = g.fireWith;
            }), d.promise(e), a && a.call(e, e), e;
        },
        when: function (a) {
            var b = 0, c = d.call(arguments), e = c.length, f = 1 !== e || a && m.isFunction(a.promise) ? e : 0, g = 1 === f ? a : m.Deferred(), h = function (a, b, c) {
                    return function (e) {
                        b[a] = this, c[a] = arguments.length > 1 ? d.call(arguments) : e, c === i ? g.notifyWith(b, c) : --f || g.resolveWith(b, c);
                    };
                }, i, j, k;
            if (e > 1)
                for (i = new Array(e), j = new Array(e), k = new Array(e); e > b; b++)
                    c[b] && m.isFunction(c[b].promise) ? c[b].promise().done(h(b, k, c)).fail(g.reject).progress(h(b, j, i)) : --f;
            return f || g.resolveWith(k, c), g.promise();
        }
    });
    var H;
    m.fn.ready = function (a) {
        return m.ready.promise().done(a), this;
    }, m.extend({
        isReady: !1,
        readyWait: 1,
        holdReady: function (a) {
            a ? m.readyWait++ : m.ready(!0);
        },
        ready: function (a) {
            if (a === !0 ? !--m.readyWait : !m.isReady) {
                if (!y.body)
                    return setTimeout(m.ready);
                m.isReady = !0, a !== !0 && --m.readyWait > 0 || (H.resolveWith(y, [m]), m.fn.triggerHandler && (m(y).triggerHandler('ready'), m(y).off('ready')));
            }
        }
    });
    function I() {
        y.addEventListener ? (y.removeEventListener('DOMContentLoaded', J, !1), a.removeEventListener('load', J, !1)) : (y.detachEvent('onreadystatechange', J), a.detachEvent('onload', J));
    }
    function J() {
        (y.addEventListener || 'load' === event.type || 'complete' === y.readyState) && (I(), m.ready());
    }
    m.ready.promise = function (b) {
        if (!H)
            if (H = m.Deferred(), 'complete' === y.readyState)
                setTimeout(m.ready);
            else if (y.addEventListener)
                y.addEventListener('DOMContentLoaded', J, !1), a.addEventListener('load', J, !1);
            else {
                y.attachEvent('onreadystatechange', J), a.attachEvent('onload', J);
                var c = !1;
                try {
                    c = null == a.frameElement && y.documentElement;
                } catch (d) {
                }
                c && c.doScroll && !function e() {
                    if (!m.isReady) {
                        try {
                            c.doScroll('left');
                        } catch (a) {
                            return setTimeout(e, 50);
                        }
                        I(), m.ready();
                    }
                }();
            }
        return H.promise(b);
    };
    var K = 'undefined', L;
    for (L in m(k))
        break;
    k.ownLast = '0' !== L, k.inlineBlockNeedsLayout = !1, m(function () {
        var a, b, c, d;
        c = y.getElementsByTagName('body')[0], c && c.style && (b = y.createElement('div'), d = y.createElement('div'), d.style.cssText = 'position:absolute;border:0;width:0;height:0;top:0;left:-9999px', c.appendChild(d).appendChild(b), typeof b.style.zoom !== K && (b.style.cssText = 'display:inline;margin:0;border:0;padding:1px;width:1px;zoom:1', k.inlineBlockNeedsLayout = a = 3 === b.offsetWidth, a && (c.style.zoom = 1)), c.removeChild(d));
    }), function () {
        var a = y.createElement('div');
        if (null == k.deleteExpando) {
            k.deleteExpando = !0;
            try {
                delete a.test;
            } catch (b) {
                k.deleteExpando = !1;
            }
        }
        a = null;
    }(), m.acceptData = function (a) {
        var b = m.noData[(a.nodeName + ' ').toLowerCase()], c = +a.nodeType || 1;
        return 1 !== c && 9 !== c ? !1 : !b || b !== !0 && a.getAttribute('classid') === b;
    };
    var M = /^(?:\{[\w\W]*\}|\[[\w\W]*\])$/, N = /([A-Z])/g;
    function O(a, b, c) {
        if (void 0 === c && 1 === a.nodeType) {
            var d = 'data-' + b.replace(N, '-$1').toLowerCase();
            if (c = a.getAttribute(d), 'string' == typeof c) {
                try {
                    c = 'true' === c ? !0 : 'false' === c ? !1 : 'null' === c ? null : +c + '' === c ? +c : M.test(c) ? m.parseJSON(c) : c;
                } catch (e) {
                }
                m.data(a, b, c);
            } else
                c = void 0;
        }
        return c;
    }
    function P(a) {
        var b;
        for (b in a)
            if (('data' !== b || !m.isEmptyObject(a[b])) && 'toJSON' !== b)
                return !1;
        return !0;
    }
    function Q(a, b, d, e) {
        if (m.acceptData(a)) {
            var f, g, h = m.expando, i = a.nodeType, j = i ? m.cache : a, k = i ? a[h] : a[h] && h;
            if (k && j[k] && (e || j[k].data) || void 0 !== d || 'string' != typeof b)
                return k || (k = i ? a[h] = c.pop() || m.guid++ : h), j[k] || (j[k] = i ? {} : { toJSON: m.noop }), ('object' == typeof b || 'function' == typeof b) && (e ? j[k] = m.extend(j[k], b) : j[k].data = m.extend(j[k].data, b)), g = j[k], e || (g.data || (g.data = {}), g = g.data), void 0 !== d && (g[m.camelCase(b)] = d), 'string' == typeof b ? (f = g[b], null == f && (f = g[m.camelCase(b)])) : f = g, f;
        }
    }
    function R(a, b, c) {
        if (m.acceptData(a)) {
            var d, e, f = a.nodeType, g = f ? m.cache : a, h = f ? a[m.expando] : m.expando;
            if (g[h]) {
                if (b && (d = c ? g[h] : g[h].data)) {
                    m.isArray(b) ? b = b.concat(m.map(b, m.camelCase)) : b in d ? b = [b] : (b = m.camelCase(b), b = b in d ? [b] : b.split(' ')), e = b.length;
                    while (e--)
                        delete d[b[e]];
                    if (c ? !P(d) : !m.isEmptyObject(d))
                        return;
                }
                (c || (delete g[h].data, P(g[h]))) && (f ? m.cleanData([a], !0) : k.deleteExpando || g != g.window ? delete g[h] : g[h] = null);
            }
        }
    }
    m.extend({
        cache: {},
        noData: {
            'applet ': !0,
            'embed ': !0,
            'object ': 'clsid:D27CDB6E-AE6D-11cf-96B8-444553540000'
        },
        hasData: function (a) {
            return a = a.nodeType ? m.cache[a[m.expando]] : a[m.expando], !!a && !P(a);
        },
        data: function (a, b, c) {
            return Q(a, b, c);
        },
        removeData: function (a, b) {
            return R(a, b);
        },
        _data: function (a, b, c) {
            return Q(a, b, c, !0);
        },
        _removeData: function (a, b) {
            return R(a, b, !0);
        }
    }), m.fn.extend({
        data: function (a, b) {
            var c, d, e, f = this[0], g = f && f.attributes;
            if (void 0 === a) {
                if (this.length && (e = m.data(f), 1 === f.nodeType && !m._data(f, 'parsedAttrs'))) {
                    c = g.length;
                    while (c--)
                        g[c] && (d = g[c].name, 0 === d.indexOf('data-') && (d = m.camelCase(d.slice(5)), O(f, d, e[d])));
                    m._data(f, 'parsedAttrs', !0);
                }
                return e;
            }
            return 'object' == typeof a ? this.each(function () {
                m.data(this, a);
            }) : arguments.length > 1 ? this.each(function () {
                m.data(this, a, b);
            }) : f ? O(f, a, m.data(f, a)) : void 0;
        },
        removeData: function (a) {
            return this.each(function () {
                m.removeData(this, a);
            });
        }
    }), m.extend({
        queue: function (a, b, c) {
            var d;
            return a ? (b = (b || 'fx') + 'queue', d = m._data(a, b), c && (!d || m.isArray(c) ? d = m._data(a, b, m.makeArray(c)) : d.push(c)), d || []) : void 0;
        },
        dequeue: function (a, b) {
            b = b || 'fx';
            var c = m.queue(a, b), d = c.length, e = c.shift(), f = m._queueHooks(a, b), g = function () {
                    m.dequeue(a, b);
                };
            'inprogress' === e && (e = c.shift(), d--), e && ('fx' === b && c.unshift('inprogress'), delete f.stop, e.call(a, g, f)), !d && f && f.empty.fire();
        },
        _queueHooks: function (a, b) {
            var c = b + 'queueHooks';
            return m._data(a, c) || m._data(a, c, {
                empty: m.Callbacks('once memory').add(function () {
                    m._removeData(a, b + 'queue'), m._removeData(a, c);
                })
            });
        }
    }), m.fn.extend({
        queue: function (a, b) {
            var c = 2;
            return 'string' != typeof a && (b = a, a = 'fx', c--), arguments.length < c ? m.queue(this[0], a) : void 0 === b ? this : this.each(function () {
                var c = m.queue(this, a, b);
                m._queueHooks(this, a), 'fx' === a && 'inprogress' !== c[0] && m.dequeue(this, a);
            });
        },
        dequeue: function (a) {
            return this.each(function () {
                m.dequeue(this, a);
            });
        },
        clearQueue: function (a) {
            return this.queue(a || 'fx', []);
        },
        promise: function (a, b) {
            var c, d = 1, e = m.Deferred(), f = this, g = this.length, h = function () {
                    --d || e.resolveWith(f, [f]);
                };
            'string' != typeof a && (b = a, a = void 0), a = a || 'fx';
            while (g--)
                c = m._data(f[g], a + 'queueHooks'), c && c.empty && (d++, c.empty.add(h));
            return h(), e.promise(b);
        }
    });
    var S = /[+-]?(?:\d*\.|)\d+(?:[eE][+-]?\d+|)/.source, T = [
            'Top',
            'Right',
            'Bottom',
            'Left'
        ], U = function (a, b) {
            return a = b || a, 'none' === m.css(a, 'display') || !m.contains(a.ownerDocument, a);
        }, V = m.access = function (a, b, c, d, e, f, g) {
            var h = 0, i = a.length, j = null == c;
            if ('object' === m.type(c)) {
                e = !0;
                for (h in c)
                    m.access(a, b, h, c[h], !0, f, g);
            } else if (void 0 !== d && (e = !0, m.isFunction(d) || (g = !0), j && (g ? (b.call(a, d), b = null) : (j = b, b = function (a, b, c) {
                    return j.call(m(a), c);
                })), b))
                for (; i > h; h++)
                    b(a[h], c, g ? d : d.call(a[h], h, b(a[h], c)));
            return e ? a : j ? b.call(a) : i ? b(a[0], c) : f;
        }, W = /^(?:checkbox|radio)$/i;
    !function () {
        var a = y.createElement('input'), b = y.createElement('div'), c = y.createDocumentFragment();
        if (b.innerHTML = '  <link/><table></table><a href=\'/a\'>a</a><input type=\'checkbox\'/>', k.leadingWhitespace = 3 === b.firstChild.nodeType, k.tbody = !b.getElementsByTagName('tbody').length, k.htmlSerialize = !!b.getElementsByTagName('link').length, k.html5Clone = '<:nav></:nav>' !== y.createElement('nav').cloneNode(!0).outerHTML, a.type = 'checkbox', a.checked = !0, c.appendChild(a), k.appendChecked = a.checked, b.innerHTML = '<textarea>x</textarea>', k.noCloneChecked = !!b.cloneNode(!0).lastChild.defaultValue, c.appendChild(b), b.innerHTML = '<input type=\'radio\' checked=\'checked\' name=\'t\'/>', k.checkClone = b.cloneNode(!0).cloneNode(!0).lastChild.checked, k.noCloneEvent = !0, b.attachEvent && (b.attachEvent('onclick', function () {
                k.noCloneEvent = !1;
            }), b.cloneNode(!0).click()), null == k.deleteExpando) {
            k.deleteExpando = !0;
            try {
                delete b.test;
            } catch (d) {
                k.deleteExpando = !1;
            }
        }
    }(), function () {
        var b, c, d = y.createElement('div');
        for (b in {
                submit: !0,
                change: !0,
                focusin: !0
            })
            c = 'on' + b, (k[b + 'Bubbles'] = c in a) || (d.setAttribute(c, 't'), k[b + 'Bubbles'] = d.attributes[c].expando === !1);
        d = null;
    }();
    var X = /^(?:input|select|textarea)$/i, Y = /^key/, Z = /^(?:mouse|pointer|contextmenu)|click/, $ = /^(?:focusinfocus|focusoutblur)$/, _ = /^([^.]*)(?:\.(.+)|)$/;
    function aa() {
        return !0;
    }
    function ba() {
        return !1;
    }
    function ca() {
        try {
            return y.activeElement;
        } catch (a) {
        }
    }
    m.event = {
        global: {},
        add: function (a, b, c, d, e) {
            var f, g, h, i, j, k, l, n, o, p, q, r = m._data(a);
            if (r) {
                c.handler && (i = c, c = i.handler, e = i.selector), c.guid || (c.guid = m.guid++), (g = r.events) || (g = r.events = {}), (k = r.handle) || (k = r.handle = function (a) {
                    return typeof m === K || a && m.event.triggered === a.type ? void 0 : m.event.dispatch.apply(k.elem, arguments);
                }, k.elem = a), b = (b || '').match(E) || [''], h = b.length;
                while (h--)
                    f = _.exec(b[h]) || [], o = q = f[1], p = (f[2] || '').split('.').sort(), o && (j = m.event.special[o] || {}, o = (e ? j.delegateType : j.bindType) || o, j = m.event.special[o] || {}, l = m.extend({
                        type: o,
                        origType: q,
                        data: d,
                        handler: c,
                        guid: c.guid,
                        selector: e,
                        needsContext: e && m.expr.match.needsContext.test(e),
                        namespace: p.join('.')
                    }, i), (n = g[o]) || (n = g[o] = [], n.delegateCount = 0, j.setup && j.setup.call(a, d, p, k) !== !1 || (a.addEventListener ? a.addEventListener(o, k, !1) : a.attachEvent && a.attachEvent('on' + o, k))), j.add && (j.add.call(a, l), l.handler.guid || (l.handler.guid = c.guid)), e ? n.splice(n.delegateCount++, 0, l) : n.push(l), m.event.global[o] = !0);
                a = null;
            }
        },
        remove: function (a, b, c, d, e) {
            var f, g, h, i, j, k, l, n, o, p, q, r = m.hasData(a) && m._data(a);
            if (r && (k = r.events)) {
                b = (b || '').match(E) || [''], j = b.length;
                while (j--)
                    if (h = _.exec(b[j]) || [], o = q = h[1], p = (h[2] || '').split('.').sort(), o) {
                        l = m.event.special[o] || {}, o = (d ? l.delegateType : l.bindType) || o, n = k[o] || [], h = h[2] && new RegExp('(^|\\.)' + p.join('\\.(?:.*\\.|)') + '(\\.|$)'), i = f = n.length;
                        while (f--)
                            g = n[f], !e && q !== g.origType || c && c.guid !== g.guid || h && !h.test(g.namespace) || d && d !== g.selector && ('**' !== d || !g.selector) || (n.splice(f, 1), g.selector && n.delegateCount--, l.remove && l.remove.call(a, g));
                        i && !n.length && (l.teardown && l.teardown.call(a, p, r.handle) !== !1 || m.removeEvent(a, o, r.handle), delete k[o]);
                    } else
                        for (o in k)
                            m.event.remove(a, o + b[j], c, d, !0);
                m.isEmptyObject(k) && (delete r.handle, m._removeData(a, 'events'));
            }
        },
        trigger: function (b, c, d, e) {
            var f, g, h, i, k, l, n, o = [d || y], p = j.call(b, 'type') ? b.type : b, q = j.call(b, 'namespace') ? b.namespace.split('.') : [];
            if (h = l = d = d || y, 3 !== d.nodeType && 8 !== d.nodeType && !$.test(p + m.event.triggered) && (p.indexOf('.') >= 0 && (q = p.split('.'), p = q.shift(), q.sort()), g = p.indexOf(':') < 0 && 'on' + p, b = b[m.expando] ? b : new m.Event(p, 'object' == typeof b && b), b.isTrigger = e ? 2 : 3, b.namespace = q.join('.'), b.namespace_re = b.namespace ? new RegExp('(^|\\.)' + q.join('\\.(?:.*\\.|)') + '(\\.|$)') : null, b.result = void 0, b.target || (b.target = d), c = null == c ? [b] : m.makeArray(c, [b]), k = m.event.special[p] || {}, e || !k.trigger || k.trigger.apply(d, c) !== !1)) {
                if (!e && !k.noBubble && !m.isWindow(d)) {
                    for (i = k.delegateType || p, $.test(i + p) || (h = h.parentNode); h; h = h.parentNode)
                        o.push(h), l = h;
                    l === (d.ownerDocument || y) && o.push(l.defaultView || l.parentWindow || a);
                }
                n = 0;
                while ((h = o[n++]) && !b.isPropagationStopped())
                    b.type = n > 1 ? i : k.bindType || p, f = (m._data(h, 'events') || {})[b.type] && m._data(h, 'handle'), f && f.apply(h, c), f = g && h[g], f && f.apply && m.acceptData(h) && (b.result = f.apply(h, c), b.result === !1 && b.preventDefault());
                if (b.type = p, !e && !b.isDefaultPrevented() && (!k._default || k._default.apply(o.pop(), c) === !1) && m.acceptData(d) && g && d[p] && !m.isWindow(d)) {
                    l = d[g], l && (d[g] = null), m.event.triggered = p;
                    try {
                        d[p]();
                    } catch (r) {
                    }
                    m.event.triggered = void 0, l && (d[g] = l);
                }
                return b.result;
            }
        },
        dispatch: function (a) {
            a = m.event.fix(a);
            var b, c, e, f, g, h = [], i = d.call(arguments), j = (m._data(this, 'events') || {})[a.type] || [], k = m.event.special[a.type] || {};
            if (i[0] = a, a.delegateTarget = this, !k.preDispatch || k.preDispatch.call(this, a) !== !1) {
                h = m.event.handlers.call(this, a, j), b = 0;
                while ((f = h[b++]) && !a.isPropagationStopped()) {
                    a.currentTarget = f.elem, g = 0;
                    while ((e = f.handlers[g++]) && !a.isImmediatePropagationStopped())
                        (!a.namespace_re || a.namespace_re.test(e.namespace)) && (a.handleObj = e, a.data = e.data, c = ((m.event.special[e.origType] || {}).handle || e.handler).apply(f.elem, i), void 0 !== c && (a.result = c) === !1 && (a.preventDefault(), a.stopPropagation()));
                }
                return k.postDispatch && k.postDispatch.call(this, a), a.result;
            }
        },
        handlers: function (a, b) {
            var c, d, e, f, g = [], h = b.delegateCount, i = a.target;
            if (h && i.nodeType && (!a.button || 'click' !== a.type))
                for (; i != this; i = i.parentNode || this)
                    if (1 === i.nodeType && (i.disabled !== !0 || 'click' !== a.type)) {
                        for (e = [], f = 0; h > f; f++)
                            d = b[f], c = d.selector + ' ', void 0 === e[c] && (e[c] = d.needsContext ? m(c, this).index(i) >= 0 : m.find(c, this, null, [i]).length), e[c] && e.push(d);
                        e.length && g.push({
                            elem: i,
                            handlers: e
                        });
                    }
            return h < b.length && g.push({
                elem: this,
                handlers: b.slice(h)
            }), g;
        },
        fix: function (a) {
            if (a[m.expando])
                return a;
            var b, c, d, e = a.type, f = a, g = this.fixHooks[e];
            g || (this.fixHooks[e] = g = Z.test(e) ? this.mouseHooks : Y.test(e) ? this.keyHooks : {}), d = g.props ? this.props.concat(g.props) : this.props, a = new m.Event(f), b = d.length;
            while (b--)
                c = d[b], a[c] = f[c];
            return a.target || (a.target = f.srcElement || y), 3 === a.target.nodeType && (a.target = a.target.parentNode), a.metaKey = !!a.metaKey, g.filter ? g.filter(a, f) : a;
        },
        props: 'altKey bubbles cancelable ctrlKey currentTarget eventPhase metaKey relatedTarget shiftKey target timeStamp view which'.split(' '),
        fixHooks: {},
        keyHooks: {
            props: 'char charCode key keyCode'.split(' '),
            filter: function (a, b) {
                return null == a.which && (a.which = null != b.charCode ? b.charCode : b.keyCode), a;
            }
        },
        mouseHooks: {
            props: 'button buttons clientX clientY fromElement offsetX offsetY pageX pageY screenX screenY toElement'.split(' '),
            filter: function (a, b) {
                var c, d, e, f = b.button, g = b.fromElement;
                return null == a.pageX && null != b.clientX && (d = a.target.ownerDocument || y, e = d.documentElement, c = d.body, a.pageX = b.clientX + (e && e.scrollLeft || c && c.scrollLeft || 0) - (e && e.clientLeft || c && c.clientLeft || 0), a.pageY = b.clientY + (e && e.scrollTop || c && c.scrollTop || 0) - (e && e.clientTop || c && c.clientTop || 0)), !a.relatedTarget && g && (a.relatedTarget = g === a.target ? b.toElement : g), a.which || void 0 === f || (a.which = 1 & f ? 1 : 2 & f ? 3 : 4 & f ? 2 : 0), a;
            }
        },
        special: {
            load: { noBubble: !0 },
            focus: {
                trigger: function () {
                    if (this !== ca() && this.focus)
                        try {
                            return this.focus(), !1;
                        } catch (a) {
                        }
                },
                delegateType: 'focusin'
            },
            blur: {
                trigger: function () {
                    return this === ca() && this.blur ? (this.blur(), !1) : void 0;
                },
                delegateType: 'focusout'
            },
            click: {
                trigger: function () {
                    return m.nodeName(this, 'input') && 'checkbox' === this.type && this.click ? (this.click(), !1) : void 0;
                },
                _default: function (a) {
                    return m.nodeName(a.target, 'a');
                }
            },
            beforeunload: {
                postDispatch: function (a) {
                    void 0 !== a.result && a.originalEvent && (a.originalEvent.returnValue = a.result);
                }
            }
        },
        simulate: function (a, b, c, d) {
            var e = m.extend(new m.Event(), c, {
                type: a,
                isSimulated: !0,
                originalEvent: {}
            });
            d ? m.event.trigger(e, null, b) : m.event.dispatch.call(b, e), e.isDefaultPrevented() && c.preventDefault();
        }
    }, m.removeEvent = y.removeEventListener ? function (a, b, c) {
        a.removeEventListener && a.removeEventListener(b, c, !1);
    } : function (a, b, c) {
        var d = 'on' + b;
        a.detachEvent && (typeof a[d] === K && (a[d] = null), a.detachEvent(d, c));
    }, m.Event = function (a, b) {
        return this instanceof m.Event ? (a && a.type ? (this.originalEvent = a, this.type = a.type, this.isDefaultPrevented = a.defaultPrevented || void 0 === a.defaultPrevented && a.returnValue === !1 ? aa : ba) : this.type = a, b && m.extend(this, b), this.timeStamp = a && a.timeStamp || m.now(), void (this[m.expando] = !0)) : new m.Event(a, b);
    }, m.Event.prototype = {
        isDefaultPrevented: ba,
        isPropagationStopped: ba,
        isImmediatePropagationStopped: ba,
        preventDefault: function () {
            var a = this.originalEvent;
            this.isDefaultPrevented = aa, a && (a.preventDefault ? a.preventDefault() : a.returnValue = !1);
        },
        stopPropagation: function () {
            var a = this.originalEvent;
            this.isPropagationStopped = aa, a && (a.stopPropagation && a.stopPropagation(), a.cancelBubble = !0);
        },
        stopImmediatePropagation: function () {
            var a = this.originalEvent;
            this.isImmediatePropagationStopped = aa, a && a.stopImmediatePropagation && a.stopImmediatePropagation(), this.stopPropagation();
        }
    }, m.each({
        mouseenter: 'mouseover',
        mouseleave: 'mouseout',
        pointerenter: 'pointerover',
        pointerleave: 'pointerout'
    }, function (a, b) {
        m.event.special[a] = {
            delegateType: b,
            bindType: b,
            handle: function (a) {
                var c, d = this, e = a.relatedTarget, f = a.handleObj;
                return (!e || e !== d && !m.contains(d, e)) && (a.type = f.origType, c = f.handler.apply(this, arguments), a.type = b), c;
            }
        };
    }), k.submitBubbles || (m.event.special.submit = {
        setup: function () {
            return m.nodeName(this, 'form') ? !1 : void m.event.add(this, 'click._submit keypress._submit', function (a) {
                var b = a.target, c = m.nodeName(b, 'input') || m.nodeName(b, 'button') ? b.form : void 0;
                c && !m._data(c, 'submitBubbles') && (m.event.add(c, 'submit._submit', function (a) {
                    a._submit_bubble = !0;
                }), m._data(c, 'submitBubbles', !0));
            });
        },
        postDispatch: function (a) {
            a._submit_bubble && (delete a._submit_bubble, this.parentNode && !a.isTrigger && m.event.simulate('submit', this.parentNode, a, !0));
        },
        teardown: function () {
            return m.nodeName(this, 'form') ? !1 : void m.event.remove(this, '._submit');
        }
    }), k.changeBubbles || (m.event.special.change = {
        setup: function () {
            return X.test(this.nodeName) ? (('checkbox' === this.type || 'radio' === this.type) && (m.event.add(this, 'propertychange._change', function (a) {
                'checked' === a.originalEvent.propertyName && (this._just_changed = !0);
            }), m.event.add(this, 'click._change', function (a) {
                this._just_changed && !a.isTrigger && (this._just_changed = !1), m.event.simulate('change', this, a, !0);
            })), !1) : void m.event.add(this, 'beforeactivate._change', function (a) {
                var b = a.target;
                X.test(b.nodeName) && !m._data(b, 'changeBubbles') && (m.event.add(b, 'change._change', function (a) {
                    !this.parentNode || a.isSimulated || a.isTrigger || m.event.simulate('change', this.parentNode, a, !0);
                }), m._data(b, 'changeBubbles', !0));
            });
        },
        handle: function (a) {
            var b = a.target;
            return this !== b || a.isSimulated || a.isTrigger || 'radio' !== b.type && 'checkbox' !== b.type ? a.handleObj.handler.apply(this, arguments) : void 0;
        },
        teardown: function () {
            return m.event.remove(this, '._change'), !X.test(this.nodeName);
        }
    }), k.focusinBubbles || m.each({
        focus: 'focusin',
        blur: 'focusout'
    }, function (a, b) {
        var c = function (a) {
            m.event.simulate(b, a.target, m.event.fix(a), !0);
        };
        m.event.special[b] = {
            setup: function () {
                var d = this.ownerDocument || this, e = m._data(d, b);
                e || d.addEventListener(a, c, !0), m._data(d, b, (e || 0) + 1);
            },
            teardown: function () {
                var d = this.ownerDocument || this, e = m._data(d, b) - 1;
                e ? m._data(d, b, e) : (d.removeEventListener(a, c, !0), m._removeData(d, b));
            }
        };
    }), m.fn.extend({
        on: function (a, b, c, d, e) {
            var f, g;
            if ('object' == typeof a) {
                'string' != typeof b && (c = c || b, b = void 0);
                for (f in a)
                    this.on(f, b, c, a[f], e);
                return this;
            }
            if (null == c && null == d ? (d = b, c = b = void 0) : null == d && ('string' == typeof b ? (d = c, c = void 0) : (d = c, c = b, b = void 0)), d === !1)
                d = ba;
            else if (!d)
                return this;
            return 1 === e && (g = d, d = function (a) {
                return m().off(a), g.apply(this, arguments);
            }, d.guid = g.guid || (g.guid = m.guid++)), this.each(function () {
                m.event.add(this, a, d, c, b);
            });
        },
        one: function (a, b, c, d) {
            return this.on(a, b, c, d, 1);
        },
        off: function (a, b, c) {
            var d, e;
            if (a && a.preventDefault && a.handleObj)
                return d = a.handleObj, m(a.delegateTarget).off(d.namespace ? d.origType + '.' + d.namespace : d.origType, d.selector, d.handler), this;
            if ('object' == typeof a) {
                for (e in a)
                    this.off(e, b, a[e]);
                return this;
            }
            return (b === !1 || 'function' == typeof b) && (c = b, b = void 0), c === !1 && (c = ba), this.each(function () {
                m.event.remove(this, a, c, b);
            });
        },
        trigger: function (a, b) {
            return this.each(function () {
                m.event.trigger(a, b, this);
            });
        },
        triggerHandler: function (a, b) {
            var c = this[0];
            return c ? m.event.trigger(a, b, c, !0) : void 0;
        }
    });
    function da(a) {
        var b = ea.split('|'), c = a.createDocumentFragment();
        if (c.createElement)
            while (b.length)
                c.createElement(b.pop());
        return c;
    }
    var ea = 'abbr|article|aside|audio|bdi|canvas|data|datalist|details|figcaption|figure|footer|header|hgroup|mark|meter|nav|output|progress|section|summary|time|video', fa = / jQuery\d+="(?:null|\d+)"/g, ga = new RegExp('<(?:' + ea + ')[\\s/>]', 'i'), ha = /^\s+/, ia = /<(?!area|br|col|embed|hr|img|input|link|meta|param)(([\w:]+)[^>]*)\/>/gi, ja = /<([\w:]+)/, ka = /<tbody/i, la = /<|&#?\w+;/, ma = /<(?:script|style|link)/i, na = /checked\s*(?:[^=]|=\s*.checked.)/i, oa = /^$|\/(?:java|ecma)script/i, pa = /^true\/(.*)/, qa = /^\s*<!(?:\[CDATA\[|--)|(?:\]\]|--)>\s*$/g, ra = {
            option: [
                1,
                '<select multiple=\'multiple\'>',
                '</select>'
            ],
            legend: [
                1,
                '<fieldset>',
                '</fieldset>'
            ],
            area: [
                1,
                '<map>',
                '</map>'
            ],
            param: [
                1,
                '<object>',
                '</object>'
            ],
            thead: [
                1,
                '<table>',
                '</table>'
            ],
            tr: [
                2,
                '<table><tbody>',
                '</tbody></table>'
            ],
            col: [
                2,
                '<table><tbody></tbody><colgroup>',
                '</colgroup></table>'
            ],
            td: [
                3,
                '<table><tbody><tr>',
                '</tr></tbody></table>'
            ],
            _default: k.htmlSerialize ? [
                0,
                '',
                ''
            ] : [
                1,
                'X<div>',
                '</div>'
            ]
        }, sa = da(y), ta = sa.appendChild(y.createElement('div'));
    ra.optgroup = ra.option, ra.tbody = ra.tfoot = ra.colgroup = ra.caption = ra.thead, ra.th = ra.td;
    function ua(a, b) {
        var c, d, e = 0, f = typeof a.getElementsByTagName !== K ? a.getElementsByTagName(b || '*') : typeof a.querySelectorAll !== K ? a.querySelectorAll(b || '*') : void 0;
        if (!f)
            for (f = [], c = a.childNodes || a; null != (d = c[e]); e++)
                !b || m.nodeName(d, b) ? f.push(d) : m.merge(f, ua(d, b));
        return void 0 === b || b && m.nodeName(a, b) ? m.merge([a], f) : f;
    }
    function va(a) {
        W.test(a.type) && (a.defaultChecked = a.checked);
    }
    function wa(a, b) {
        return m.nodeName(a, 'table') && m.nodeName(11 !== b.nodeType ? b : b.firstChild, 'tr') ? a.getElementsByTagName('tbody')[0] || a.appendChild(a.ownerDocument.createElement('tbody')) : a;
    }
    function xa(a) {
        return a.type = (null !== m.find.attr(a, 'type')) + '/' + a.type, a;
    }
    function ya(a) {
        var b = pa.exec(a.type);
        return b ? a.type = b[1] : a.removeAttribute('type'), a;
    }
    function za(a, b) {
        for (var c, d = 0; null != (c = a[d]); d++)
            m._data(c, 'globalEval', !b || m._data(b[d], 'globalEval'));
    }
    function Aa(a, b) {
        if (1 === b.nodeType && m.hasData(a)) {
            var c, d, e, f = m._data(a), g = m._data(b, f), h = f.events;
            if (h) {
                delete g.handle, g.events = {};
                for (c in h)
                    for (d = 0, e = h[c].length; e > d; d++)
                        m.event.add(b, c, h[c][d]);
            }
            g.data && (g.data = m.extend({}, g.data));
        }
    }
    function Ba(a, b) {
        var c, d, e;
        if (1 === b.nodeType) {
            if (c = b.nodeName.toLowerCase(), !k.noCloneEvent && b[m.expando]) {
                e = m._data(b);
                for (d in e.events)
                    m.removeEvent(b, d, e.handle);
                b.removeAttribute(m.expando);
            }
            'script' === c && b.text !== a.text ? (xa(b).text = a.text, ya(b)) : 'object' === c ? (b.parentNode && (b.outerHTML = a.outerHTML), k.html5Clone && a.innerHTML && !m.trim(b.innerHTML) && (b.innerHTML = a.innerHTML)) : 'input' === c && W.test(a.type) ? (b.defaultChecked = b.checked = a.checked, b.value !== a.value && (b.value = a.value)) : 'option' === c ? b.defaultSelected = b.selected = a.defaultSelected : ('input' === c || 'textarea' === c) && (b.defaultValue = a.defaultValue);
        }
    }
    m.extend({
        clone: function (a, b, c) {
            var d, e, f, g, h, i = m.contains(a.ownerDocument, a);
            if (k.html5Clone || m.isXMLDoc(a) || !ga.test('<' + a.nodeName + '>') ? f = a.cloneNode(!0) : (ta.innerHTML = a.outerHTML, ta.removeChild(f = ta.firstChild)), !(k.noCloneEvent && k.noCloneChecked || 1 !== a.nodeType && 11 !== a.nodeType || m.isXMLDoc(a)))
                for (d = ua(f), h = ua(a), g = 0; null != (e = h[g]); ++g)
                    d[g] && Ba(e, d[g]);
            if (b)
                if (c)
                    for (h = h || ua(a), d = d || ua(f), g = 0; null != (e = h[g]); g++)
                        Aa(e, d[g]);
                else
                    Aa(a, f);
            return d = ua(f, 'script'), d.length > 0 && za(d, !i && ua(a, 'script')), d = h = e = null, f;
        },
        buildFragment: function (a, b, c, d) {
            for (var e, f, g, h, i, j, l, n = a.length, o = da(b), p = [], q = 0; n > q; q++)
                if (f = a[q], f || 0 === f)
                    if ('object' === m.type(f))
                        m.merge(p, f.nodeType ? [f] : f);
                    else if (la.test(f)) {
                        h = h || o.appendChild(b.createElement('div')), i = (ja.exec(f) || [
                            '',
                            ''
                        ])[1].toLowerCase(), l = ra[i] || ra._default, h.innerHTML = l[1] + f.replace(ia, '<$1></$2>') + l[2], e = l[0];
                        while (e--)
                            h = h.lastChild;
                        if (!k.leadingWhitespace && ha.test(f) && p.push(b.createTextNode(ha.exec(f)[0])), !k.tbody) {
                            f = 'table' !== i || ka.test(f) ? '<table>' !== l[1] || ka.test(f) ? 0 : h : h.firstChild, e = f && f.childNodes.length;
                            while (e--)
                                m.nodeName(j = f.childNodes[e], 'tbody') && !j.childNodes.length && f.removeChild(j);
                        }
                        m.merge(p, h.childNodes), h.textContent = '';
                        while (h.firstChild)
                            h.removeChild(h.firstChild);
                        h = o.lastChild;
                    } else
                        p.push(b.createTextNode(f));
            h && o.removeChild(h), k.appendChecked || m.grep(ua(p, 'input'), va), q = 0;
            while (f = p[q++])
                if ((!d || -1 === m.inArray(f, d)) && (g = m.contains(f.ownerDocument, f), h = ua(o.appendChild(f), 'script'), g && za(h), c)) {
                    e = 0;
                    while (f = h[e++])
                        oa.test(f.type || '') && c.push(f);
                }
            return h = null, o;
        },
        cleanData: function (a, b) {
            for (var d, e, f, g, h = 0, i = m.expando, j = m.cache, l = k.deleteExpando, n = m.event.special; null != (d = a[h]); h++)
                if ((b || m.acceptData(d)) && (f = d[i], g = f && j[f])) {
                    if (g.events)
                        for (e in g.events)
                            n[e] ? m.event.remove(d, e) : m.removeEvent(d, e, g.handle);
                    j[f] && (delete j[f], l ? delete d[i] : typeof d.removeAttribute !== K ? d.removeAttribute(i) : d[i] = null, c.push(f));
                }
        }
    }), m.fn.extend({
        text: function (a) {
            return V(this, function (a) {
                return void 0 === a ? m.text(this) : this.empty().append((this[0] && this[0].ownerDocument || y).createTextNode(a));
            }, null, a, arguments.length);
        },
        append: function () {
            return this.domManip(arguments, function (a) {
                if (1 === this.nodeType || 11 === this.nodeType || 9 === this.nodeType) {
                    var b = wa(this, a);
                    b.appendChild(a);
                }
            });
        },
        prepend: function () {
            return this.domManip(arguments, function (a) {
                if (1 === this.nodeType || 11 === this.nodeType || 9 === this.nodeType) {
                    var b = wa(this, a);
                    b.insertBefore(a, b.firstChild);
                }
            });
        },
        before: function () {
            return this.domManip(arguments, function (a) {
                this.parentNode && this.parentNode.insertBefore(a, this);
            });
        },
        after: function () {
            return this.domManip(arguments, function (a) {
                this.parentNode && this.parentNode.insertBefore(a, this.nextSibling);
            });
        },
        remove: function (a, b) {
            for (var c, d = a ? m.filter(a, this) : this, e = 0; null != (c = d[e]); e++)
                b || 1 !== c.nodeType || m.cleanData(ua(c)), c.parentNode && (b && m.contains(c.ownerDocument, c) && za(ua(c, 'script')), c.parentNode.removeChild(c));
            return this;
        },
        empty: function () {
            for (var a, b = 0; null != (a = this[b]); b++) {
                1 === a.nodeType && m.cleanData(ua(a, !1));
                while (a.firstChild)
                    a.removeChild(a.firstChild);
                a.options && m.nodeName(a, 'select') && (a.options.length = 0);
            }
            return this;
        },
        clone: function (a, b) {
            return a = null == a ? !1 : a, b = null == b ? a : b, this.map(function () {
                return m.clone(this, a, b);
            });
        },
        html: function (a) {
            return V(this, function (a) {
                var b = this[0] || {}, c = 0, d = this.length;
                if (void 0 === a)
                    return 1 === b.nodeType ? b.innerHTML.replace(fa, '') : void 0;
                if (!('string' != typeof a || ma.test(a) || !k.htmlSerialize && ga.test(a) || !k.leadingWhitespace && ha.test(a) || ra[(ja.exec(a) || [
                        '',
                        ''
                    ])[1].toLowerCase()])) {
                    a = a.replace(ia, '<$1></$2>');
                    try {
                        for (; d > c; c++)
                            b = this[c] || {}, 1 === b.nodeType && (m.cleanData(ua(b, !1)), b.innerHTML = a);
                        b = 0;
                    } catch (e) {
                    }
                }
                b && this.empty().append(a);
            }, null, a, arguments.length);
        },
        replaceWith: function () {
            var a = arguments[0];
            return this.domManip(arguments, function (b) {
                a = this.parentNode, m.cleanData(ua(this)), a && a.replaceChild(b, this);
            }), a && (a.length || a.nodeType) ? this : this.remove();
        },
        detach: function (a) {
            return this.remove(a, !0);
        },
        domManip: function (a, b) {
            a = e.apply([], a);
            var c, d, f, g, h, i, j = 0, l = this.length, n = this, o = l - 1, p = a[0], q = m.isFunction(p);
            if (q || l > 1 && 'string' == typeof p && !k.checkClone && na.test(p))
                return this.each(function (c) {
                    var d = n.eq(c);
                    q && (a[0] = p.call(this, c, d.html())), d.domManip(a, b);
                });
            if (l && (i = m.buildFragment(a, this[0].ownerDocument, !1, this), c = i.firstChild, 1 === i.childNodes.length && (i = c), c)) {
                for (g = m.map(ua(i, 'script'), xa), f = g.length; l > j; j++)
                    d = i, j !== o && (d = m.clone(d, !0, !0), f && m.merge(g, ua(d, 'script'))), b.call(this[j], d, j);
                if (f)
                    for (h = g[g.length - 1].ownerDocument, m.map(g, ya), j = 0; f > j; j++)
                        d = g[j], oa.test(d.type || '') && !m._data(d, 'globalEval') && m.contains(h, d) && (d.src ? m._evalUrl && m._evalUrl(d.src) : m.globalEval((d.text || d.textContent || d.innerHTML || '').replace(qa, '')));
                i = c = null;
            }
            return this;
        }
    }), m.each({
        appendTo: 'append',
        prependTo: 'prepend',
        insertBefore: 'before',
        insertAfter: 'after',
        replaceAll: 'replaceWith'
    }, function (a, b) {
        m.fn[a] = function (a) {
            for (var c, d = 0, e = [], g = m(a), h = g.length - 1; h >= d; d++)
                c = d === h ? this : this.clone(!0), m(g[d])[b](c), f.apply(e, c.get());
            return this.pushStack(e);
        };
    });
    var Ca, Da = {};
    function Ea(b, c) {
        var d, e = m(c.createElement(b)).appendTo(c.body), f = a.getDefaultComputedStyle && (d = a.getDefaultComputedStyle(e[0])) ? d.display : m.css(e[0], 'display');
        return e.detach(), f;
    }
    function Fa(a) {
        var b = y, c = Da[a];
        return c || (c = Ea(a, b), 'none' !== c && c || (Ca = (Ca || m('<iframe frameborder=\'0\' width=\'0\' height=\'0\'/>')).appendTo(b.documentElement), b = (Ca[0].contentWindow || Ca[0].contentDocument).document, b.write(), b.close(), c = Ea(a, b), Ca.detach()), Da[a] = c), c;
    }
    !function () {
        var a;
        k.shrinkWrapBlocks = function () {
            if (null != a)
                return a;
            a = !1;
            var b, c, d;
            return c = y.getElementsByTagName('body')[0], c && c.style ? (b = y.createElement('div'), d = y.createElement('div'), d.style.cssText = 'position:absolute;border:0;width:0;height:0;top:0;left:-9999px', c.appendChild(d).appendChild(b), typeof b.style.zoom !== K && (b.style.cssText = '-webkit-box-sizing:content-box;-moz-box-sizing:content-box;box-sizing:content-box;display:block;margin:0;border:0;padding:1px;width:1px;zoom:1', b.appendChild(y.createElement('div')).style.width = '5px', a = 3 !== b.offsetWidth), c.removeChild(d), a) : void 0;
        };
    }();
    var Ga = /^margin/, Ha = new RegExp('^(' + S + ')(?!px)[a-z%]+$', 'i'), Ia, Ja, Ka = /^(top|right|bottom|left)$/;
    a.getComputedStyle ? (Ia = function (b) {
        return b.ownerDocument.defaultView.opener ? b.ownerDocument.defaultView.getComputedStyle(b, null) : a.getComputedStyle(b, null);
    }, Ja = function (a, b, c) {
        var d, e, f, g, h = a.style;
        return c = c || Ia(a), g = c ? c.getPropertyValue(b) || c[b] : void 0, c && ('' !== g || m.contains(a.ownerDocument, a) || (g = m.style(a, b)), Ha.test(g) && Ga.test(b) && (d = h.width, e = h.minWidth, f = h.maxWidth, h.minWidth = h.maxWidth = h.width = g, g = c.width, h.width = d, h.minWidth = e, h.maxWidth = f)), void 0 === g ? g : g + '';
    }) : y.documentElement.currentStyle && (Ia = function (a) {
        return a.currentStyle;
    }, Ja = function (a, b, c) {
        var d, e, f, g, h = a.style;
        return c = c || Ia(a), g = c ? c[b] : void 0, null == g && h && h[b] && (g = h[b]), Ha.test(g) && !Ka.test(b) && (d = h.left, e = a.runtimeStyle, f = e && e.left, f && (e.left = a.currentStyle.left), h.left = 'fontSize' === b ? '1em' : g, g = h.pixelLeft + 'px', h.left = d, f && (e.left = f)), void 0 === g ? g : g + '' || 'auto';
    });
    function La(a, b) {
        return {
            get: function () {
                var c = a();
                if (null != c)
                    return c ? void delete this.get : (this.get = b).apply(this, arguments);
            }
        };
    }
    !function () {
        var b, c, d, e, f, g, h;
        if (b = y.createElement('div'), b.innerHTML = '  <link/><table></table><a href=\'/a\'>a</a><input type=\'checkbox\'/>', d = b.getElementsByTagName('a')[0], c = d && d.style) {
            c.cssText = 'float:left;opacity:.5', k.opacity = '0.5' === c.opacity, k.cssFloat = !!c.cssFloat, b.style.backgroundClip = 'content-box', b.cloneNode(!0).style.backgroundClip = '', k.clearCloneStyle = 'content-box' === b.style.backgroundClip, k.boxSizing = '' === c.boxSizing || '' === c.MozBoxSizing || '' === c.WebkitBoxSizing, m.extend(k, {
                reliableHiddenOffsets: function () {
                    return null == g && i(), g;
                },
                boxSizingReliable: function () {
                    return null == f && i(), f;
                },
                pixelPosition: function () {
                    return null == e && i(), e;
                },
                reliableMarginRight: function () {
                    return null == h && i(), h;
                }
            });
            function i() {
                var b, c, d, i;
                c = y.getElementsByTagName('body')[0], c && c.style && (b = y.createElement('div'), d = y.createElement('div'), d.style.cssText = 'position:absolute;border:0;width:0;height:0;top:0;left:-9999px', c.appendChild(d).appendChild(b), b.style.cssText = '-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box;display:block;margin-top:1%;top:1%;border:1px;padding:1px;width:4px;position:absolute', e = f = !1, h = !0, a.getComputedStyle && (e = '1%' !== (a.getComputedStyle(b, null) || {}).top, f = '4px' === (a.getComputedStyle(b, null) || { width: '4px' }).width, i = b.appendChild(y.createElement('div')), i.style.cssText = b.style.cssText = '-webkit-box-sizing:content-box;-moz-box-sizing:content-box;box-sizing:content-box;display:block;margin:0;border:0;padding:0', i.style.marginRight = i.style.width = '0', b.style.width = '1px', h = !parseFloat((a.getComputedStyle(i, null) || {}).marginRight), b.removeChild(i)), b.innerHTML = '<table><tr><td></td><td>t</td></tr></table>', i = b.getElementsByTagName('td'), i[0].style.cssText = 'margin:0;border:0;padding:0;display:none', g = 0 === i[0].offsetHeight, g && (i[0].style.display = '', i[1].style.display = 'none', g = 0 === i[0].offsetHeight), c.removeChild(d));
            }
        }
    }(), m.swap = function (a, b, c, d) {
        var e, f, g = {};
        for (f in b)
            g[f] = a.style[f], a.style[f] = b[f];
        e = c.apply(a, d || []);
        for (f in b)
            a.style[f] = g[f];
        return e;
    };
    var Ma = /alpha\([^)]*\)/i, Na = /opacity\s*=\s*([^)]*)/, Oa = /^(none|table(?!-c[ea]).+)/, Pa = new RegExp('^(' + S + ')(.*)$', 'i'), Qa = new RegExp('^([+-])=(' + S + ')', 'i'), Ra = {
            position: 'absolute',
            visibility: 'hidden',
            display: 'block'
        }, Sa = {
            letterSpacing: '0',
            fontWeight: '400'
        }, Ta = [
            'Webkit',
            'O',
            'Moz',
            'ms'
        ];
    function Ua(a, b) {
        if (b in a)
            return b;
        var c = b.charAt(0).toUpperCase() + b.slice(1), d = b, e = Ta.length;
        while (e--)
            if (b = Ta[e] + c, b in a)
                return b;
        return d;
    }
    function Va(a, b) {
        for (var c, d, e, f = [], g = 0, h = a.length; h > g; g++)
            d = a[g], d.style && (f[g] = m._data(d, 'olddisplay'), c = d.style.display, b ? (f[g] || 'none' !== c || (d.style.display = ''), '' === d.style.display && U(d) && (f[g] = m._data(d, 'olddisplay', Fa(d.nodeName)))) : (e = U(d), (c && 'none' !== c || !e) && m._data(d, 'olddisplay', e ? c : m.css(d, 'display'))));
        for (g = 0; h > g; g++)
            d = a[g], d.style && (b && 'none' !== d.style.display && '' !== d.style.display || (d.style.display = b ? f[g] || '' : 'none'));
        return a;
    }
    function Wa(a, b, c) {
        var d = Pa.exec(b);
        return d ? Math.max(0, d[1] - (c || 0)) + (d[2] || 'px') : b;
    }
    function Xa(a, b, c, d, e) {
        for (var f = c === (d ? 'border' : 'content') ? 4 : 'width' === b ? 1 : 0, g = 0; 4 > f; f += 2)
            'margin' === c && (g += m.css(a, c + T[f], !0, e)), d ? ('content' === c && (g -= m.css(a, 'padding' + T[f], !0, e)), 'margin' !== c && (g -= m.css(a, 'border' + T[f] + 'Width', !0, e))) : (g += m.css(a, 'padding' + T[f], !0, e), 'padding' !== c && (g += m.css(a, 'border' + T[f] + 'Width', !0, e)));
        return g;
    }
    function Ya(a, b, c) {
        var d = !0, e = 'width' === b ? a.offsetWidth : a.offsetHeight, f = Ia(a), g = k.boxSizing && 'border-box' === m.css(a, 'boxSizing', !1, f);
        if (0 >= e || null == e) {
            if (e = Ja(a, b, f), (0 > e || null == e) && (e = a.style[b]), Ha.test(e))
                return e;
            d = g && (k.boxSizingReliable() || e === a.style[b]), e = parseFloat(e) || 0;
        }
        return e + Xa(a, b, c || (g ? 'border' : 'content'), d, f) + 'px';
    }
    m.extend({
        cssHooks: {
            opacity: {
                get: function (a, b) {
                    if (b) {
                        var c = Ja(a, 'opacity');
                        return '' === c ? '1' : c;
                    }
                }
            }
        },
        cssNumber: {
            columnCount: !0,
            fillOpacity: !0,
            flexGrow: !0,
            flexShrink: !0,
            fontWeight: !0,
            lineHeight: !0,
            opacity: !0,
            order: !0,
            orphans: !0,
            widows: !0,
            zIndex: !0,
            zoom: !0
        },
        cssProps: { 'float': k.cssFloat ? 'cssFloat' : 'styleFloat' },
        style: function (a, b, c, d) {
            if (a && 3 !== a.nodeType && 8 !== a.nodeType && a.style) {
                var e, f, g, h = m.camelCase(b), i = a.style;
                if (b = m.cssProps[h] || (m.cssProps[h] = Ua(i, h)), g = m.cssHooks[b] || m.cssHooks[h], void 0 === c)
                    return g && 'get' in g && void 0 !== (e = g.get(a, !1, d)) ? e : i[b];
                if (f = typeof c, 'string' === f && (e = Qa.exec(c)) && (c = (e[1] + 1) * e[2] + parseFloat(m.css(a, b)), f = 'number'), null != c && c === c && ('number' !== f || m.cssNumber[h] || (c += 'px'), k.clearCloneStyle || '' !== c || 0 !== b.indexOf('background') || (i[b] = 'inherit'), !(g && 'set' in g && void 0 === (c = g.set(a, c, d)))))
                    try {
                        i[b] = c;
                    } catch (j) {
                    }
            }
        },
        css: function (a, b, c, d) {
            var e, f, g, h = m.camelCase(b);
            return b = m.cssProps[h] || (m.cssProps[h] = Ua(a.style, h)), g = m.cssHooks[b] || m.cssHooks[h], g && 'get' in g && (f = g.get(a, !0, c)), void 0 === f && (f = Ja(a, b, d)), 'normal' === f && b in Sa && (f = Sa[b]), '' === c || c ? (e = parseFloat(f), c === !0 || m.isNumeric(e) ? e || 0 : f) : f;
        }
    }), m.each([
        'height',
        'width'
    ], function (a, b) {
        m.cssHooks[b] = {
            get: function (a, c, d) {
                return c ? Oa.test(m.css(a, 'display')) && 0 === a.offsetWidth ? m.swap(a, Ra, function () {
                    return Ya(a, b, d);
                }) : Ya(a, b, d) : void 0;
            },
            set: function (a, c, d) {
                var e = d && Ia(a);
                return Wa(a, c, d ? Xa(a, b, d, k.boxSizing && 'border-box' === m.css(a, 'boxSizing', !1, e), e) : 0);
            }
        };
    }), k.opacity || (m.cssHooks.opacity = {
        get: function (a, b) {
            return Na.test((b && a.currentStyle ? a.currentStyle.filter : a.style.filter) || '') ? 0.01 * parseFloat(RegExp.$1) + '' : b ? '1' : '';
        },
        set: function (a, b) {
            var c = a.style, d = a.currentStyle, e = m.isNumeric(b) ? 'alpha(opacity=' + 100 * b + ')' : '', f = d && d.filter || c.filter || '';
            c.zoom = 1, (b >= 1 || '' === b) && '' === m.trim(f.replace(Ma, '')) && c.removeAttribute && (c.removeAttribute('filter'), '' === b || d && !d.filter) || (c.filter = Ma.test(f) ? f.replace(Ma, e) : f + ' ' + e);
        }
    }), m.cssHooks.marginRight = La(k.reliableMarginRight, function (a, b) {
        return b ? m.swap(a, { display: 'inline-block' }, Ja, [
            a,
            'marginRight'
        ]) : void 0;
    }), m.each({
        margin: '',
        padding: '',
        border: 'Width'
    }, function (a, b) {
        m.cssHooks[a + b] = {
            expand: function (c) {
                for (var d = 0, e = {}, f = 'string' == typeof c ? c.split(' ') : [c]; 4 > d; d++)
                    e[a + T[d] + b] = f[d] || f[d - 2] || f[0];
                return e;
            }
        }, Ga.test(a) || (m.cssHooks[a + b].set = Wa);
    }), m.fn.extend({
        css: function (a, b) {
            return V(this, function (a, b, c) {
                var d, e, f = {}, g = 0;
                if (m.isArray(b)) {
                    for (d = Ia(a), e = b.length; e > g; g++)
                        f[b[g]] = m.css(a, b[g], !1, d);
                    return f;
                }
                return void 0 !== c ? m.style(a, b, c) : m.css(a, b);
            }, a, b, arguments.length > 1);
        },
        show: function () {
            return Va(this, !0);
        },
        hide: function () {
            return Va(this);
        },
        toggle: function (a) {
            return 'boolean' == typeof a ? a ? this.show() : this.hide() : this.each(function () {
                U(this) ? m(this).show() : m(this).hide();
            });
        }
    });
    function Za(a, b, c, d, e) {
        return new Za.prototype.init(a, b, c, d, e);
    }
    m.Tween = Za, Za.prototype = {
        constructor: Za,
        init: function (a, b, c, d, e, f) {
            this.elem = a, this.prop = c, this.easing = e || 'swing', this.options = b, this.start = this.now = this.cur(), this.end = d, this.unit = f || (m.cssNumber[c] ? '' : 'px');
        },
        cur: function () {
            var a = Za.propHooks[this.prop];
            return a && a.get ? a.get(this) : Za.propHooks._default.get(this);
        },
        run: function (a) {
            var b, c = Za.propHooks[this.prop];
            return this.options.duration ? this.pos = b = m.easing[this.easing](a, this.options.duration * a, 0, 1, this.options.duration) : this.pos = b = a, this.now = (this.end - this.start) * b + this.start, this.options.step && this.options.step.call(this.elem, this.now, this), c && c.set ? c.set(this) : Za.propHooks._default.set(this), this;
        }
    }, Za.prototype.init.prototype = Za.prototype, Za.propHooks = {
        _default: {
            get: function (a) {
                var b;
                return null == a.elem[a.prop] || a.elem.style && null != a.elem.style[a.prop] ? (b = m.css(a.elem, a.prop, ''), b && 'auto' !== b ? b : 0) : a.elem[a.prop];
            },
            set: function (a) {
                m.fx.step[a.prop] ? m.fx.step[a.prop](a) : a.elem.style && (null != a.elem.style[m.cssProps[a.prop]] || m.cssHooks[a.prop]) ? m.style(a.elem, a.prop, a.now + a.unit) : a.elem[a.prop] = a.now;
            }
        }
    }, Za.propHooks.scrollTop = Za.propHooks.scrollLeft = {
        set: function (a) {
            a.elem.nodeType && a.elem.parentNode && (a.elem[a.prop] = a.now);
        }
    }, m.easing = {
        linear: function (a) {
            return a;
        },
        swing: function (a) {
            return 0.5 - Math.cos(a * Math.PI) / 2;
        }
    }, m.fx = Za.prototype.init, m.fx.step = {};
    var $a, _a, ab = /^(?:toggle|show|hide)$/, bb = new RegExp('^(?:([+-])=|)(' + S + ')([a-z%]*)$', 'i'), cb = /queueHooks$/, db = [ib], eb = {
            '*': [function (a, b) {
                    var c = this.createTween(a, b), d = c.cur(), e = bb.exec(b), f = e && e[3] || (m.cssNumber[a] ? '' : 'px'), g = (m.cssNumber[a] || 'px' !== f && +d) && bb.exec(m.css(c.elem, a)), h = 1, i = 20;
                    if (g && g[3] !== f) {
                        f = f || g[3], e = e || [], g = +d || 1;
                        do
                            h = h || '.5', g /= h, m.style(c.elem, a, g + f);
                        while (h !== (h = c.cur() / d) && 1 !== h && --i);
                    }
                    return e && (g = c.start = +g || +d || 0, c.unit = f, c.end = e[1] ? g + (e[1] + 1) * e[2] : +e[2]), c;
                }]
        };
    function fb() {
        return setTimeout(function () {
            $a = void 0;
        }), $a = m.now();
    }
    function gb(a, b) {
        var c, d = { height: a }, e = 0;
        for (b = b ? 1 : 0; 4 > e; e += 2 - b)
            c = T[e], d['margin' + c] = d['padding' + c] = a;
        return b && (d.opacity = d.width = a), d;
    }
    function hb(a, b, c) {
        for (var d, e = (eb[b] || []).concat(eb['*']), f = 0, g = e.length; g > f; f++)
            if (d = e[f].call(c, b, a))
                return d;
    }
    function ib(a, b, c) {
        var d, e, f, g, h, i, j, l, n = this, o = {}, p = a.style, q = a.nodeType && U(a), r = m._data(a, 'fxshow');
        c.queue || (h = m._queueHooks(a, 'fx'), null == h.unqueued && (h.unqueued = 0, i = h.empty.fire, h.empty.fire = function () {
            h.unqueued || i();
        }), h.unqueued++, n.always(function () {
            n.always(function () {
                h.unqueued--, m.queue(a, 'fx').length || h.empty.fire();
            });
        })), 1 === a.nodeType && ('height' in b || 'width' in b) && (c.overflow = [
            p.overflow,
            p.overflowX,
            p.overflowY
        ], j = m.css(a, 'display'), l = 'none' === j ? m._data(a, 'olddisplay') || Fa(a.nodeName) : j, 'inline' === l && 'none' === m.css(a, 'float') && (k.inlineBlockNeedsLayout && 'inline' !== Fa(a.nodeName) ? p.zoom = 1 : p.display = 'inline-block')), c.overflow && (p.overflow = 'hidden', k.shrinkWrapBlocks() || n.always(function () {
            p.overflow = c.overflow[0], p.overflowX = c.overflow[1], p.overflowY = c.overflow[2];
        }));
        for (d in b)
            if (e = b[d], ab.exec(e)) {
                if (delete b[d], f = f || 'toggle' === e, e === (q ? 'hide' : 'show')) {
                    if ('show' !== e || !r || void 0 === r[d])
                        continue;
                    q = !0;
                }
                o[d] = r && r[d] || m.style(a, d);
            } else
                j = void 0;
        if (m.isEmptyObject(o))
            'inline' === ('none' === j ? Fa(a.nodeName) : j) && (p.display = j);
        else {
            r ? 'hidden' in r && (q = r.hidden) : r = m._data(a, 'fxshow', {}), f && (r.hidden = !q), q ? m(a).show() : n.done(function () {
                m(a).hide();
            }), n.done(function () {
                var b;
                m._removeData(a, 'fxshow');
                for (b in o)
                    m.style(a, b, o[b]);
            });
            for (d in o)
                g = hb(q ? r[d] : 0, d, n), d in r || (r[d] = g.start, q && (g.end = g.start, g.start = 'width' === d || 'height' === d ? 1 : 0));
        }
    }
    function jb(a, b) {
        var c, d, e, f, g;
        for (c in a)
            if (d = m.camelCase(c), e = b[d], f = a[c], m.isArray(f) && (e = f[1], f = a[c] = f[0]), c !== d && (a[d] = f, delete a[c]), g = m.cssHooks[d], g && 'expand' in g) {
                f = g.expand(f), delete a[d];
                for (c in f)
                    c in a || (a[c] = f[c], b[c] = e);
            } else
                b[d] = e;
    }
    function kb(a, b, c) {
        var d, e, f = 0, g = db.length, h = m.Deferred().always(function () {
                delete i.elem;
            }), i = function () {
                if (e)
                    return !1;
                for (var b = $a || fb(), c = Math.max(0, j.startTime + j.duration - b), d = c / j.duration || 0, f = 1 - d, g = 0, i = j.tweens.length; i > g; g++)
                    j.tweens[g].run(f);
                return h.notifyWith(a, [
                    j,
                    f,
                    c
                ]), 1 > f && i ? c : (h.resolveWith(a, [j]), !1);
            }, j = h.promise({
                elem: a,
                props: m.extend({}, b),
                opts: m.extend(!0, { specialEasing: {} }, c),
                originalProperties: b,
                originalOptions: c,
                startTime: $a || fb(),
                duration: c.duration,
                tweens: [],
                createTween: function (b, c) {
                    var d = m.Tween(a, j.opts, b, c, j.opts.specialEasing[b] || j.opts.easing);
                    return j.tweens.push(d), d;
                },
                stop: function (b) {
                    var c = 0, d = b ? j.tweens.length : 0;
                    if (e)
                        return this;
                    for (e = !0; d > c; c++)
                        j.tweens[c].run(1);
                    return b ? h.resolveWith(a, [
                        j,
                        b
                    ]) : h.rejectWith(a, [
                        j,
                        b
                    ]), this;
                }
            }), k = j.props;
        for (jb(k, j.opts.specialEasing); g > f; f++)
            if (d = db[f].call(j, a, k, j.opts))
                return d;
        return m.map(k, hb, j), m.isFunction(j.opts.start) && j.opts.start.call(a, j), m.fx.timer(m.extend(i, {
            elem: a,
            anim: j,
            queue: j.opts.queue
        })), j.progress(j.opts.progress).done(j.opts.done, j.opts.complete).fail(j.opts.fail).always(j.opts.always);
    }
    m.Animation = m.extend(kb, {
        tweener: function (a, b) {
            m.isFunction(a) ? (b = a, a = ['*']) : a = a.split(' ');
            for (var c, d = 0, e = a.length; e > d; d++)
                c = a[d], eb[c] = eb[c] || [], eb[c].unshift(b);
        },
        prefilter: function (a, b) {
            b ? db.unshift(a) : db.push(a);
        }
    }), m.speed = function (a, b, c) {
        var d = a && 'object' == typeof a ? m.extend({}, a) : {
            complete: c || !c && b || m.isFunction(a) && a,
            duration: a,
            easing: c && b || b && !m.isFunction(b) && b
        };
        return d.duration = m.fx.off ? 0 : 'number' == typeof d.duration ? d.duration : d.duration in m.fx.speeds ? m.fx.speeds[d.duration] : m.fx.speeds._default, (null == d.queue || d.queue === !0) && (d.queue = 'fx'), d.old = d.complete, d.complete = function () {
            m.isFunction(d.old) && d.old.call(this), d.queue && m.dequeue(this, d.queue);
        }, d;
    }, m.fn.extend({
        fadeTo: function (a, b, c, d) {
            return this.filter(U).css('opacity', 0).show().end().animate({ opacity: b }, a, c, d);
        },
        animate: function (a, b, c, d) {
            var e = m.isEmptyObject(a), f = m.speed(b, c, d), g = function () {
                    var b = kb(this, m.extend({}, a), f);
                    (e || m._data(this, 'finish')) && b.stop(!0);
                };
            return g.finish = g, e || f.queue === !1 ? this.each(g) : this.queue(f.queue, g);
        },
        stop: function (a, b, c) {
            var d = function (a) {
                var b = a.stop;
                delete a.stop, b(c);
            };
            return 'string' != typeof a && (c = b, b = a, a = void 0), b && a !== !1 && this.queue(a || 'fx', []), this.each(function () {
                var b = !0, e = null != a && a + 'queueHooks', f = m.timers, g = m._data(this);
                if (e)
                    g[e] && g[e].stop && d(g[e]);
                else
                    for (e in g)
                        g[e] && g[e].stop && cb.test(e) && d(g[e]);
                for (e = f.length; e--;)
                    f[e].elem !== this || null != a && f[e].queue !== a || (f[e].anim.stop(c), b = !1, f.splice(e, 1));
                (b || !c) && m.dequeue(this, a);
            });
        },
        finish: function (a) {
            return a !== !1 && (a = a || 'fx'), this.each(function () {
                var b, c = m._data(this), d = c[a + 'queue'], e = c[a + 'queueHooks'], f = m.timers, g = d ? d.length : 0;
                for (c.finish = !0, m.queue(this, a, []), e && e.stop && e.stop.call(this, !0), b = f.length; b--;)
                    f[b].elem === this && f[b].queue === a && (f[b].anim.stop(!0), f.splice(b, 1));
                for (b = 0; g > b; b++)
                    d[b] && d[b].finish && d[b].finish.call(this);
                delete c.finish;
            });
        }
    }), m.each([
        'toggle',
        'show',
        'hide'
    ], function (a, b) {
        var c = m.fn[b];
        m.fn[b] = function (a, d, e) {
            return null == a || 'boolean' == typeof a ? c.apply(this, arguments) : this.animate(gb(b, !0), a, d, e);
        };
    }), m.each({
        slideDown: gb('show'),
        slideUp: gb('hide'),
        slideToggle: gb('toggle'),
        fadeIn: { opacity: 'show' },
        fadeOut: { opacity: 'hide' },
        fadeToggle: { opacity: 'toggle' }
    }, function (a, b) {
        m.fn[a] = function (a, c, d) {
            return this.animate(b, a, c, d);
        };
    }), m.timers = [], m.fx.tick = function () {
        var a, b = m.timers, c = 0;
        for ($a = m.now(); c < b.length; c++)
            a = b[c], a() || b[c] !== a || b.splice(c--, 1);
        b.length || m.fx.stop(), $a = void 0;
    }, m.fx.timer = function (a) {
        m.timers.push(a), a() ? m.fx.start() : m.timers.pop();
    }, m.fx.interval = 13, m.fx.start = function () {
        _a || (_a = setInterval(m.fx.tick, m.fx.interval));
    }, m.fx.stop = function () {
        clearInterval(_a), _a = null;
    }, m.fx.speeds = {
        slow: 600,
        fast: 200,
        _default: 400
    }, m.fn.delay = function (a, b) {
        return a = m.fx ? m.fx.speeds[a] || a : a, b = b || 'fx', this.queue(b, function (b, c) {
            var d = setTimeout(b, a);
            c.stop = function () {
                clearTimeout(d);
            };
        });
    }, function () {
        var a, b, c, d, e;
        b = y.createElement('div'), b.setAttribute('className', 't'), b.innerHTML = '  <link/><table></table><a href=\'/a\'>a</a><input type=\'checkbox\'/>', d = b.getElementsByTagName('a')[0], c = y.createElement('select'), e = c.appendChild(y.createElement('option')), a = b.getElementsByTagName('input')[0], d.style.cssText = 'top:1px', k.getSetAttribute = 't' !== b.className, k.style = /top/.test(d.getAttribute('style')), k.hrefNormalized = '/a' === d.getAttribute('href'), k.checkOn = !!a.value, k.optSelected = e.selected, k.enctype = !!y.createElement('form').enctype, c.disabled = !0, k.optDisabled = !e.disabled, a = y.createElement('input'), a.setAttribute('value', ''), k.input = '' === a.getAttribute('value'), a.value = 't', a.setAttribute('type', 'radio'), k.radioValue = 't' === a.value;
    }();
    var lb = /\r/g;
    m.fn.extend({
        val: function (a) {
            var b, c, d, e = this[0];
            {
                if (arguments.length)
                    return d = m.isFunction(a), this.each(function (c) {
                        var e;
                        1 === this.nodeType && (e = d ? a.call(this, c, m(this).val()) : a, null == e ? e = '' : 'number' == typeof e ? e += '' : m.isArray(e) && (e = m.map(e, function (a) {
                            return null == a ? '' : a + '';
                        })), b = m.valHooks[this.type] || m.valHooks[this.nodeName.toLowerCase()], b && 'set' in b && void 0 !== b.set(this, e, 'value') || (this.value = e));
                    });
                if (e)
                    return b = m.valHooks[e.type] || m.valHooks[e.nodeName.toLowerCase()], b && 'get' in b && void 0 !== (c = b.get(e, 'value')) ? c : (c = e.value, 'string' == typeof c ? c.replace(lb, '') : null == c ? '' : c);
            }
        }
    }), m.extend({
        valHooks: {
            option: {
                get: function (a) {
                    var b = m.find.attr(a, 'value');
                    return null != b ? b : m.trim(m.text(a));
                }
            },
            select: {
                get: function (a) {
                    for (var b, c, d = a.options, e = a.selectedIndex, f = 'select-one' === a.type || 0 > e, g = f ? null : [], h = f ? e + 1 : d.length, i = 0 > e ? h : f ? e : 0; h > i; i++)
                        if (c = d[i], !(!c.selected && i !== e || (k.optDisabled ? c.disabled : null !== c.getAttribute('disabled')) || c.parentNode.disabled && m.nodeName(c.parentNode, 'optgroup'))) {
                            if (b = m(c).val(), f)
                                return b;
                            g.push(b);
                        }
                    return g;
                },
                set: function (a, b) {
                    var c, d, e = a.options, f = m.makeArray(b), g = e.length;
                    while (g--)
                        if (d = e[g], m.inArray(m.valHooks.option.get(d), f) >= 0)
                            try {
                                d.selected = c = !0;
                            } catch (h) {
                                d.scrollHeight;
                            }
                        else
                            d.selected = !1;
                    return c || (a.selectedIndex = -1), e;
                }
            }
        }
    }), m.each([
        'radio',
        'checkbox'
    ], function () {
        m.valHooks[this] = {
            set: function (a, b) {
                return m.isArray(b) ? a.checked = m.inArray(m(a).val(), b) >= 0 : void 0;
            }
        }, k.checkOn || (m.valHooks[this].get = function (a) {
            return null === a.getAttribute('value') ? 'on' : a.value;
        });
    });
    var mb, nb, ob = m.expr.attrHandle, pb = /^(?:checked|selected)$/i, qb = k.getSetAttribute, rb = k.input;
    m.fn.extend({
        attr: function (a, b) {
            return V(this, m.attr, a, b, arguments.length > 1);
        },
        removeAttr: function (a) {
            return this.each(function () {
                m.removeAttr(this, a);
            });
        }
    }), m.extend({
        attr: function (a, b, c) {
            var d, e, f = a.nodeType;
            if (a && 3 !== f && 8 !== f && 2 !== f)
                return typeof a.getAttribute === K ? m.prop(a, b, c) : (1 === f && m.isXMLDoc(a) || (b = b.toLowerCase(), d = m.attrHooks[b] || (m.expr.match.bool.test(b) ? nb : mb)), void 0 === c ? d && 'get' in d && null !== (e = d.get(a, b)) ? e : (e = m.find.attr(a, b), null == e ? void 0 : e) : null !== c ? d && 'set' in d && void 0 !== (e = d.set(a, c, b)) ? e : (a.setAttribute(b, c + ''), c) : void m.removeAttr(a, b));
        },
        removeAttr: function (a, b) {
            var c, d, e = 0, f = b && b.match(E);
            if (f && 1 === a.nodeType)
                while (c = f[e++])
                    d = m.propFix[c] || c, m.expr.match.bool.test(c) ? rb && qb || !pb.test(c) ? a[d] = !1 : a[m.camelCase('default-' + c)] = a[d] = !1 : m.attr(a, c, ''), a.removeAttribute(qb ? c : d);
        },
        attrHooks: {
            type: {
                set: function (a, b) {
                    if (!k.radioValue && 'radio' === b && m.nodeName(a, 'input')) {
                        var c = a.value;
                        return a.setAttribute('type', b), c && (a.value = c), b;
                    }
                }
            }
        }
    }), nb = {
        set: function (a, b, c) {
            return b === !1 ? m.removeAttr(a, c) : rb && qb || !pb.test(c) ? a.setAttribute(!qb && m.propFix[c] || c, c) : a[m.camelCase('default-' + c)] = a[c] = !0, c;
        }
    }, m.each(m.expr.match.bool.source.match(/\w+/g), function (a, b) {
        var c = ob[b] || m.find.attr;
        ob[b] = rb && qb || !pb.test(b) ? function (a, b, d) {
            var e, f;
            return d || (f = ob[b], ob[b] = e, e = null != c(a, b, d) ? b.toLowerCase() : null, ob[b] = f), e;
        } : function (a, b, c) {
            return c ? void 0 : a[m.camelCase('default-' + b)] ? b.toLowerCase() : null;
        };
    }), rb && qb || (m.attrHooks.value = {
        set: function (a, b, c) {
            return m.nodeName(a, 'input') ? void (a.defaultValue = b) : mb && mb.set(a, b, c);
        }
    }), qb || (mb = {
        set: function (a, b, c) {
            var d = a.getAttributeNode(c);
            return d || a.setAttributeNode(d = a.ownerDocument.createAttribute(c)), d.value = b += '', 'value' === c || b === a.getAttribute(c) ? b : void 0;
        }
    }, ob.id = ob.name = ob.coords = function (a, b, c) {
        var d;
        return c ? void 0 : (d = a.getAttributeNode(b)) && '' !== d.value ? d.value : null;
    }, m.valHooks.button = {
        get: function (a, b) {
            var c = a.getAttributeNode(b);
            return c && c.specified ? c.value : void 0;
        },
        set: mb.set
    }, m.attrHooks.contenteditable = {
        set: function (a, b, c) {
            mb.set(a, '' === b ? !1 : b, c);
        }
    }, m.each([
        'width',
        'height'
    ], function (a, b) {
        m.attrHooks[b] = {
            set: function (a, c) {
                return '' === c ? (a.setAttribute(b, 'auto'), c) : void 0;
            }
        };
    })), k.style || (m.attrHooks.style = {
        get: function (a) {
            return a.style.cssText || void 0;
        },
        set: function (a, b) {
            return a.style.cssText = b + '';
        }
    });
    var sb = /^(?:input|select|textarea|button|object)$/i, tb = /^(?:a|area)$/i;
    m.fn.extend({
        prop: function (a, b) {
            return V(this, m.prop, a, b, arguments.length > 1);
        },
        removeProp: function (a) {
            return a = m.propFix[a] || a, this.each(function () {
                try {
                    this[a] = void 0, delete this[a];
                } catch (b) {
                }
            });
        }
    }), m.extend({
        propFix: {
            'for': 'htmlFor',
            'class': 'className'
        },
        prop: function (a, b, c) {
            var d, e, f, g = a.nodeType;
            if (a && 3 !== g && 8 !== g && 2 !== g)
                return f = 1 !== g || !m.isXMLDoc(a), f && (b = m.propFix[b] || b, e = m.propHooks[b]), void 0 !== c ? e && 'set' in e && void 0 !== (d = e.set(a, c, b)) ? d : a[b] = c : e && 'get' in e && null !== (d = e.get(a, b)) ? d : a[b];
        },
        propHooks: {
            tabIndex: {
                get: function (a) {
                    var b = m.find.attr(a, 'tabindex');
                    return b ? parseInt(b, 10) : sb.test(a.nodeName) || tb.test(a.nodeName) && a.href ? 0 : -1;
                }
            }
        }
    }), k.hrefNormalized || m.each([
        'href',
        'src'
    ], function (a, b) {
        m.propHooks[b] = {
            get: function (a) {
                return a.getAttribute(b, 4);
            }
        };
    }), k.optSelected || (m.propHooks.selected = {
        get: function (a) {
            var b = a.parentNode;
            return b && (b.selectedIndex, b.parentNode && b.parentNode.selectedIndex), null;
        }
    }), m.each([
        'tabIndex',
        'readOnly',
        'maxLength',
        'cellSpacing',
        'cellPadding',
        'rowSpan',
        'colSpan',
        'useMap',
        'frameBorder',
        'contentEditable'
    ], function () {
        m.propFix[this.toLowerCase()] = this;
    }), k.enctype || (m.propFix.enctype = 'encoding');
    var ub = /[\t\r\n\f]/g;
    m.fn.extend({
        addClass: function (a) {
            var b, c, d, e, f, g, h = 0, i = this.length, j = 'string' == typeof a && a;
            if (m.isFunction(a))
                return this.each(function (b) {
                    m(this).addClass(a.call(this, b, this.className));
                });
            if (j)
                for (b = (a || '').match(E) || []; i > h; h++)
                    if (c = this[h], d = 1 === c.nodeType && (c.className ? (' ' + c.className + ' ').replace(ub, ' ') : ' ')) {
                        f = 0;
                        while (e = b[f++])
                            d.indexOf(' ' + e + ' ') < 0 && (d += e + ' ');
                        g = m.trim(d), c.className !== g && (c.className = g);
                    }
            return this;
        },
        removeClass: function (a) {
            var b, c, d, e, f, g, h = 0, i = this.length, j = 0 === arguments.length || 'string' == typeof a && a;
            if (m.isFunction(a))
                return this.each(function (b) {
                    m(this).removeClass(a.call(this, b, this.className));
                });
            if (j)
                for (b = (a || '').match(E) || []; i > h; h++)
                    if (c = this[h], d = 1 === c.nodeType && (c.className ? (' ' + c.className + ' ').replace(ub, ' ') : '')) {
                        f = 0;
                        while (e = b[f++])
                            while (d.indexOf(' ' + e + ' ') >= 0)
                                d = d.replace(' ' + e + ' ', ' ');
                        g = a ? m.trim(d) : '', c.className !== g && (c.className = g);
                    }
            return this;
        },
        toggleClass: function (a, b) {
            var c = typeof a;
            return 'boolean' == typeof b && 'string' === c ? b ? this.addClass(a) : this.removeClass(a) : this.each(m.isFunction(a) ? function (c) {
                m(this).toggleClass(a.call(this, c, this.className, b), b);
            } : function () {
                if ('string' === c) {
                    var b, d = 0, e = m(this), f = a.match(E) || [];
                    while (b = f[d++])
                        e.hasClass(b) ? e.removeClass(b) : e.addClass(b);
                } else
                    (c === K || 'boolean' === c) && (this.className && m._data(this, '__className__', this.className), this.className = this.className || a === !1 ? '' : m._data(this, '__className__') || '');
            });
        },
        hasClass: function (a) {
            for (var b = ' ' + a + ' ', c = 0, d = this.length; d > c; c++)
                if (1 === this[c].nodeType && (' ' + this[c].className + ' ').replace(ub, ' ').indexOf(b) >= 0)
                    return !0;
            return !1;
        }
    }), m.each('blur focus focusin focusout load resize scroll unload click dblclick mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave change select submit keydown keypress keyup error contextmenu'.split(' '), function (a, b) {
        m.fn[b] = function (a, c) {
            return arguments.length > 0 ? this.on(b, null, a, c) : this.trigger(b);
        };
    }), m.fn.extend({
        hover: function (a, b) {
            return this.mouseenter(a).mouseleave(b || a);
        },
        bind: function (a, b, c) {
            return this.on(a, null, b, c);
        },
        unbind: function (a, b) {
            return this.off(a, null, b);
        },
        delegate: function (a, b, c, d) {
            return this.on(b, a, c, d);
        },
        undelegate: function (a, b, c) {
            return 1 === arguments.length ? this.off(a, '**') : this.off(b, a || '**', c);
        }
    });
    var vb = m.now(), wb = /\?/, xb = /(,)|(\[|{)|(}|])|"(?:[^"\\\r\n]|\\["\\\/bfnrt]|\\u[\da-fA-F]{4})*"\s*:?|true|false|null|-?(?!0\d)\d+(?:\.\d+|)(?:[eE][+-]?\d+|)/g;
    m.parseJSON = function (b) {
        if (a.JSON && a.JSON.parse)
            return a.JSON.parse(b + '');
        var c, d = null, e = m.trim(b + '');
        return e && !m.trim(e.replace(xb, function (a, b, e, f) {
            return c && b && (d = 0), 0 === d ? a : (c = e || b, d += !f - !e, '');
        })) ? Function('return ' + e)() : m.error('Invalid JSON: ' + b);
    }, m.parseXML = function (b) {
        var c, d;
        if (!b || 'string' != typeof b)
            return null;
        try {
            a.DOMParser ? (d = new DOMParser(), c = d.parseFromString(b, 'text/xml')) : (c = new ActiveXObject('Microsoft.XMLDOM'), c.async = 'false', c.loadXML(b));
        } catch (e) {
            c = void 0;
        }
        return c && c.documentElement && !c.getElementsByTagName('parsererror').length || m.error('Invalid XML: ' + b), c;
    };
    var yb, zb, Ab = /#.*$/, Bb = /([?&])_=[^&]*/, Cb = /^(.*?):[ \t]*([^\r\n]*)\r?$/gm, Db = /^(?:about|app|app-storage|.+-extension|file|res|widget):$/, Eb = /^(?:GET|HEAD)$/, Fb = /^\/\//, Gb = /^([\w.+-]+:)(?:\/\/(?:[^\/?#]*@|)([^\/?#:]*)(?::(\d+)|)|)/, Hb = {}, Ib = {}, Jb = '*/'.concat('*');
    try {
        zb = location.href;
    } catch (Kb) {
        zb = y.createElement('a'), zb.href = '', zb = zb.href;
    }
    yb = Gb.exec(zb.toLowerCase()) || [];
    function Lb(a) {
        return function (b, c) {
            'string' != typeof b && (c = b, b = '*');
            var d, e = 0, f = b.toLowerCase().match(E) || [];
            if (m.isFunction(c))
                while (d = f[e++])
                    '+' === d.charAt(0) ? (d = d.slice(1) || '*', (a[d] = a[d] || []).unshift(c)) : (a[d] = a[d] || []).push(c);
        };
    }
    function Mb(a, b, c, d) {
        var e = {}, f = a === Ib;
        function g(h) {
            var i;
            return e[h] = !0, m.each(a[h] || [], function (a, h) {
                var j = h(b, c, d);
                return 'string' != typeof j || f || e[j] ? f ? !(i = j) : void 0 : (b.dataTypes.unshift(j), g(j), !1);
            }), i;
        }
        return g(b.dataTypes[0]) || !e['*'] && g('*');
    }
    function Nb(a, b) {
        var c, d, e = m.ajaxSettings.flatOptions || {};
        for (d in b)
            void 0 !== b[d] && ((e[d] ? a : c || (c = {}))[d] = b[d]);
        return c && m.extend(!0, a, c), a;
    }
    function Ob(a, b, c) {
        var d, e, f, g, h = a.contents, i = a.dataTypes;
        while ('*' === i[0])
            i.shift(), void 0 === e && (e = a.mimeType || b.getResponseHeader('Content-Type'));
        if (e)
            for (g in h)
                if (h[g] && h[g].test(e)) {
                    i.unshift(g);
                    break;
                }
        if (i[0] in c)
            f = i[0];
        else {
            for (g in c) {
                if (!i[0] || a.converters[g + ' ' + i[0]]) {
                    f = g;
                    break;
                }
                d || (d = g);
            }
            f = f || d;
        }
        return f ? (f !== i[0] && i.unshift(f), c[f]) : void 0;
    }
    function Pb(a, b, c, d) {
        var e, f, g, h, i, j = {}, k = a.dataTypes.slice();
        if (k[1])
            for (g in a.converters)
                j[g.toLowerCase()] = a.converters[g];
        f = k.shift();
        while (f)
            if (a.responseFields[f] && (c[a.responseFields[f]] = b), !i && d && a.dataFilter && (b = a.dataFilter(b, a.dataType)), i = f, f = k.shift())
                if ('*' === f)
                    f = i;
                else if ('*' !== i && i !== f) {
                    if (g = j[i + ' ' + f] || j['* ' + f], !g)
                        for (e in j)
                            if (h = e.split(' '), h[1] === f && (g = j[i + ' ' + h[0]] || j['* ' + h[0]])) {
                                g === !0 ? g = j[e] : j[e] !== !0 && (f = h[0], k.unshift(h[1]));
                                break;
                            }
                    if (g !== !0)
                        if (g && a['throws'])
                            b = g(b);
                        else
                            try {
                                b = g(b);
                            } catch (l) {
                                return {
                                    state: 'parsererror',
                                    error: g ? l : 'No conversion from ' + i + ' to ' + f
                                };
                            }
                }
        return {
            state: 'success',
            data: b
        };
    }
    m.extend({
        active: 0,
        lastModified: {},
        etag: {},
        ajaxSettings: {
            url: zb,
            type: 'GET',
            isLocal: Db.test(yb[1]),
            global: !0,
            processData: !0,
            async: !0,
            contentType: 'application/x-www-form-urlencoded; charset=UTF-8',
            accepts: {
                '*': Jb,
                text: 'text/plain',
                html: 'text/html',
                xml: 'application/xml, text/xml',
                json: 'application/json, text/javascript'
            },
            contents: {
                xml: /xml/,
                html: /html/,
                json: /json/
            },
            responseFields: {
                xml: 'responseXML',
                text: 'responseText',
                json: 'responseJSON'
            },
            converters: {
                '* text': String,
                'text html': !0,
                'text json': m.parseJSON,
                'text xml': m.parseXML
            },
            flatOptions: {
                url: !0,
                context: !0
            }
        },
        ajaxSetup: function (a, b) {
            return b ? Nb(Nb(a, m.ajaxSettings), b) : Nb(m.ajaxSettings, a);
        },
        ajaxPrefilter: Lb(Hb),
        ajaxTransport: Lb(Ib),
        ajax: function (a, b) {
            'object' == typeof a && (b = a, a = void 0), b = b || {};
            var c, d, e, f, g, h, i, j, k = m.ajaxSetup({}, b), l = k.context || k, n = k.context && (l.nodeType || l.jquery) ? m(l) : m.event, o = m.Deferred(), p = m.Callbacks('once memory'), q = k.statusCode || {}, r = {}, s = {}, t = 0, u = 'canceled', v = {
                    readyState: 0,
                    getResponseHeader: function (a) {
                        var b;
                        if (2 === t) {
                            if (!j) {
                                j = {};
                                while (b = Cb.exec(f))
                                    j[b[1].toLowerCase()] = b[2];
                            }
                            b = j[a.toLowerCase()];
                        }
                        return null == b ? null : b;
                    },
                    getAllResponseHeaders: function () {
                        return 2 === t ? f : null;
                    },
                    setRequestHeader: function (a, b) {
                        var c = a.toLowerCase();
                        return t || (a = s[c] = s[c] || a, r[a] = b), this;
                    },
                    overrideMimeType: function (a) {
                        return t || (k.mimeType = a), this;
                    },
                    statusCode: function (a) {
                        var b;
                        if (a)
                            if (2 > t)
                                for (b in a)
                                    q[b] = [
                                        q[b],
                                        a[b]
                                    ];
                            else
                                v.always(a[v.status]);
                        return this;
                    },
                    abort: function (a) {
                        var b = a || u;
                        return i && i.abort(b), x(0, b), this;
                    }
                };
            if (o.promise(v).complete = p.add, v.success = v.done, v.error = v.fail, k.url = ((a || k.url || zb) + '').replace(Ab, '').replace(Fb, yb[1] + '//'), k.type = b.method || b.type || k.method || k.type, k.dataTypes = m.trim(k.dataType || '*').toLowerCase().match(E) || [''], null == k.crossDomain && (c = Gb.exec(k.url.toLowerCase()), k.crossDomain = !(!c || c[1] === yb[1] && c[2] === yb[2] && (c[3] || ('http:' === c[1] ? '80' : '443')) === (yb[3] || ('http:' === yb[1] ? '80' : '443')))), k.data && k.processData && 'string' != typeof k.data && (k.data = m.param(k.data, k.traditional)), Mb(Hb, k, b, v), 2 === t)
                return v;
            h = m.event && k.global, h && 0 === m.active++ && m.event.trigger('ajaxStart'), k.type = k.type.toUpperCase(), k.hasContent = !Eb.test(k.type), e = k.url, k.hasContent || (k.data && (e = k.url += (wb.test(e) ? '&' : '?') + k.data, delete k.data), k.cache === !1 && (k.url = Bb.test(e) ? e.replace(Bb, '$1_=' + vb++) : e + (wb.test(e) ? '&' : '?') + '_=' + vb++)), k.ifModified && (m.lastModified[e] && v.setRequestHeader('If-Modified-Since', m.lastModified[e]), m.etag[e] && v.setRequestHeader('If-None-Match', m.etag[e])), (k.data && k.hasContent && k.contentType !== !1 || b.contentType) && v.setRequestHeader('Content-Type', k.contentType), v.setRequestHeader('Accept', k.dataTypes[0] && k.accepts[k.dataTypes[0]] ? k.accepts[k.dataTypes[0]] + ('*' !== k.dataTypes[0] ? ', ' + Jb + '; q=0.01' : '') : k.accepts['*']);
            for (d in k.headers)
                v.setRequestHeader(d, k.headers[d]);
            if (k.beforeSend && (k.beforeSend.call(l, v, k) === !1 || 2 === t))
                return v.abort();
            u = 'abort';
            for (d in {
                    success: 1,
                    error: 1,
                    complete: 1
                })
                v[d](k[d]);
            if (i = Mb(Ib, k, b, v)) {
                v.readyState = 1, h && n.trigger('ajaxSend', [
                    v,
                    k
                ]), k.async && k.timeout > 0 && (g = setTimeout(function () {
                    v.abort('timeout');
                }, k.timeout));
                try {
                    t = 1, i.send(r, x);
                } catch (w) {
                    if (!(2 > t))
                        throw w;
                    x(-1, w);
                }
            } else
                x(-1, 'No Transport');
            function x(a, b, c, d) {
                var j, r, s, u, w, x = b;
                2 !== t && (t = 2, g && clearTimeout(g), i = void 0, f = d || '', v.readyState = a > 0 ? 4 : 0, j = a >= 200 && 300 > a || 304 === a, c && (u = Ob(k, v, c)), u = Pb(k, u, v, j), j ? (k.ifModified && (w = v.getResponseHeader('Last-Modified'), w && (m.lastModified[e] = w), w = v.getResponseHeader('etag'), w && (m.etag[e] = w)), 204 === a || 'HEAD' === k.type ? x = 'nocontent' : 304 === a ? x = 'notmodified' : (x = u.state, r = u.data, s = u.error, j = !s)) : (s = x, (a || !x) && (x = 'error', 0 > a && (a = 0))), v.status = a, v.statusText = (b || x) + '', j ? o.resolveWith(l, [
                    r,
                    x,
                    v
                ]) : o.rejectWith(l, [
                    v,
                    x,
                    s
                ]), v.statusCode(q), q = void 0, h && n.trigger(j ? 'ajaxSuccess' : 'ajaxError', [
                    v,
                    k,
                    j ? r : s
                ]), p.fireWith(l, [
                    v,
                    x
                ]), h && (n.trigger('ajaxComplete', [
                    v,
                    k
                ]), --m.active || m.event.trigger('ajaxStop')));
            }
            return v;
        },
        getJSON: function (a, b, c) {
            return m.get(a, b, c, 'json');
        },
        getScript: function (a, b) {
            return m.get(a, void 0, b, 'script');
        }
    }), m.each([
        'get',
        'post'
    ], function (a, b) {
        m[b] = function (a, c, d, e) {
            return m.isFunction(c) && (e = e || d, d = c, c = void 0), m.ajax({
                url: a,
                type: b,
                dataType: e,
                data: c,
                success: d
            });
        };
    }), m._evalUrl = function (a) {
        return m.ajax({
            url: a,
            type: 'GET',
            dataType: 'script',
            async: !1,
            global: !1,
            'throws': !0
        });
    }, m.fn.extend({
        wrapAll: function (a) {
            if (m.isFunction(a))
                return this.each(function (b) {
                    m(this).wrapAll(a.call(this, b));
                });
            if (this[0]) {
                var b = m(a, this[0].ownerDocument).eq(0).clone(!0);
                this[0].parentNode && b.insertBefore(this[0]), b.map(function () {
                    var a = this;
                    while (a.firstChild && 1 === a.firstChild.nodeType)
                        a = a.firstChild;
                    return a;
                }).append(this);
            }
            return this;
        },
        wrapInner: function (a) {
            return this.each(m.isFunction(a) ? function (b) {
                m(this).wrapInner(a.call(this, b));
            } : function () {
                var b = m(this), c = b.contents();
                c.length ? c.wrapAll(a) : b.append(a);
            });
        },
        wrap: function (a) {
            var b = m.isFunction(a);
            return this.each(function (c) {
                m(this).wrapAll(b ? a.call(this, c) : a);
            });
        },
        unwrap: function () {
            return this.parent().each(function () {
                m.nodeName(this, 'body') || m(this).replaceWith(this.childNodes);
            }).end();
        }
    }), m.expr.filters.hidden = function (a) {
        return a.offsetWidth <= 0 && a.offsetHeight <= 0 || !k.reliableHiddenOffsets() && 'none' === (a.style && a.style.display || m.css(a, 'display'));
    }, m.expr.filters.visible = function (a) {
        return !m.expr.filters.hidden(a);
    };
    var Qb = /%20/g, Rb = /\[\]$/, Sb = /\r?\n/g, Tb = /^(?:submit|button|image|reset|file)$/i, Ub = /^(?:input|select|textarea|keygen)/i;
    function Vb(a, b, c, d) {
        var e;
        if (m.isArray(b))
            m.each(b, function (b, e) {
                c || Rb.test(a) ? d(a, e) : Vb(a + '[' + ('object' == typeof e ? b : '') + ']', e, c, d);
            });
        else if (c || 'object' !== m.type(b))
            d(a, b);
        else
            for (e in b)
                Vb(a + '[' + e + ']', b[e], c, d);
    }
    m.param = function (a, b) {
        var c, d = [], e = function (a, b) {
                b = m.isFunction(b) ? b() : null == b ? '' : b, d[d.length] = encodeURIComponent(a) + '=' + encodeURIComponent(b);
            };
        if (void 0 === b && (b = m.ajaxSettings && m.ajaxSettings.traditional), m.isArray(a) || a.jquery && !m.isPlainObject(a))
            m.each(a, function () {
                e(this.name, this.value);
            });
        else
            for (c in a)
                Vb(c, a[c], b, e);
        return d.join('&').replace(Qb, '+');
    }, m.fn.extend({
        serialize: function () {
            return m.param(this.serializeArray());
        },
        serializeArray: function () {
            return this.map(function () {
                var a = m.prop(this, 'elements');
                return a ? m.makeArray(a) : this;
            }).filter(function () {
                var a = this.type;
                return this.name && !m(this).is(':disabled') && Ub.test(this.nodeName) && !Tb.test(a) && (this.checked || !W.test(a));
            }).map(function (a, b) {
                var c = m(this).val();
                return null == c ? null : m.isArray(c) ? m.map(c, function (a) {
                    return {
                        name: b.name,
                        value: a.replace(Sb, '\r\n')
                    };
                }) : {
                    name: b.name,
                    value: c.replace(Sb, '\r\n')
                };
            }).get();
        }
    }), m.ajaxSettings.xhr = void 0 !== a.ActiveXObject ? function () {
        return !this.isLocal && /^(get|post|head|put|delete|options)$/i.test(this.type) && Zb() || $b();
    } : Zb;
    var Wb = 0, Xb = {}, Yb = m.ajaxSettings.xhr();
    a.attachEvent && a.attachEvent('onunload', function () {
        for (var a in Xb)
            Xb[a](void 0, !0);
    }), k.cors = !!Yb && 'withCredentials' in Yb, Yb = k.ajax = !!Yb, Yb && m.ajaxTransport(function (a) {
        if (!a.crossDomain || k.cors) {
            var b;
            return {
                send: function (c, d) {
                    var e, f = a.xhr(), g = ++Wb;
                    if (f.open(a.type, a.url, a.async, a.username, a.password), a.xhrFields)
                        for (e in a.xhrFields)
                            f[e] = a.xhrFields[e];
                    a.mimeType && f.overrideMimeType && f.overrideMimeType(a.mimeType), a.crossDomain || c['X-Requested-With'] || (c['X-Requested-With'] = 'XMLHttpRequest');
                    for (e in c)
                        void 0 !== c[e] && f.setRequestHeader(e, c[e] + '');
                    f.send(a.hasContent && a.data || null), b = function (c, e) {
                        var h, i, j;
                        if (b && (e || 4 === f.readyState))
                            if (delete Xb[g], b = void 0, f.onreadystatechange = m.noop, e)
                                4 !== f.readyState && f.abort();
                            else {
                                j = {}, h = f.status, 'string' == typeof f.responseText && (j.text = f.responseText);
                                try {
                                    i = f.statusText;
                                } catch (k) {
                                    i = '';
                                }
                                h || !a.isLocal || a.crossDomain ? 1223 === h && (h = 204) : h = j.text ? 200 : 404;
                            }
                        j && d(h, i, j, f.getAllResponseHeaders());
                    }, a.async ? 4 === f.readyState ? setTimeout(b) : f.onreadystatechange = Xb[g] = b : b();
                },
                abort: function () {
                    b && b(void 0, !0);
                }
            };
        }
    });
    function Zb() {
        try {
            return new a.XMLHttpRequest();
        } catch (b) {
        }
    }
    function $b() {
        try {
            return new a.ActiveXObject('Microsoft.XMLHTTP');
        } catch (b) {
        }
    }
    m.ajaxSetup({
        accepts: { script: 'text/javascript, application/javascript, application/ecmascript, application/x-ecmascript' },
        contents: { script: /(?:java|ecma)script/ },
        converters: {
            'text script': function (a) {
                return m.globalEval(a), a;
            }
        }
    }), m.ajaxPrefilter('script', function (a) {
        void 0 === a.cache && (a.cache = !1), a.crossDomain && (a.type = 'GET', a.global = !1);
    }), m.ajaxTransport('script', function (a) {
        if (a.crossDomain) {
            var b, c = y.head || m('head')[0] || y.documentElement;
            return {
                send: function (d, e) {
                    b = y.createElement('script'), b.async = !0, a.scriptCharset && (b.charset = a.scriptCharset), b.src = a.url, b.onload = b.onreadystatechange = function (a, c) {
                        (c || !b.readyState || /loaded|complete/.test(b.readyState)) && (b.onload = b.onreadystatechange = null, b.parentNode && b.parentNode.removeChild(b), b = null, c || e(200, 'success'));
                    }, c.insertBefore(b, c.firstChild);
                },
                abort: function () {
                    b && b.onload(void 0, !0);
                }
            };
        }
    });
    var _b = [], ac = /(=)\?(?=&|$)|\?\?/;
    m.ajaxSetup({
        jsonp: 'callback',
        jsonpCallback: function () {
            var a = _b.pop() || m.expando + '_' + vb++;
            return this[a] = !0, a;
        }
    }), m.ajaxPrefilter('json jsonp', function (b, c, d) {
        var e, f, g, h = b.jsonp !== !1 && (ac.test(b.url) ? 'url' : 'string' == typeof b.data && !(b.contentType || '').indexOf('application/x-www-form-urlencoded') && ac.test(b.data) && 'data');
        return h || 'jsonp' === b.dataTypes[0] ? (e = b.jsonpCallback = m.isFunction(b.jsonpCallback) ? b.jsonpCallback() : b.jsonpCallback, h ? b[h] = b[h].replace(ac, '$1' + e) : b.jsonp !== !1 && (b.url += (wb.test(b.url) ? '&' : '?') + b.jsonp + '=' + e), b.converters['script json'] = function () {
            return g || m.error(e + ' was not called'), g[0];
        }, b.dataTypes[0] = 'json', f = a[e], a[e] = function () {
            g = arguments;
        }, d.always(function () {
            a[e] = f, b[e] && (b.jsonpCallback = c.jsonpCallback, _b.push(e)), g && m.isFunction(f) && f(g[0]), g = f = void 0;
        }), 'script') : void 0;
    }), m.parseHTML = function (a, b, c) {
        if (!a || 'string' != typeof a)
            return null;
        'boolean' == typeof b && (c = b, b = !1), b = b || y;
        var d = u.exec(a), e = !c && [];
        return d ? [b.createElement(d[1])] : (d = m.buildFragment([a], b, e), e && e.length && m(e).remove(), m.merge([], d.childNodes));
    };
    var bc = m.fn.load;
    m.fn.load = function (a, b, c) {
        if ('string' != typeof a && bc)
            return bc.apply(this, arguments);
        var d, e, f, g = this, h = a.indexOf(' ');
        return h >= 0 && (d = m.trim(a.slice(h, a.length)), a = a.slice(0, h)), m.isFunction(b) ? (c = b, b = void 0) : b && 'object' == typeof b && (f = 'POST'), g.length > 0 && m.ajax({
            url: a,
            type: f,
            dataType: 'html',
            data: b
        }).done(function (a) {
            e = arguments, g.html(d ? m('<div>').append(m.parseHTML(a)).find(d) : a);
        }).complete(c && function (a, b) {
            g.each(c, e || [
                a.responseText,
                b,
                a
            ]);
        }), this;
    }, m.each([
        'ajaxStart',
        'ajaxStop',
        'ajaxComplete',
        'ajaxError',
        'ajaxSuccess',
        'ajaxSend'
    ], function (a, b) {
        m.fn[b] = function (a) {
            return this.on(b, a);
        };
    }), m.expr.filters.animated = function (a) {
        return m.grep(m.timers, function (b) {
            return a === b.elem;
        }).length;
    };
    var cc = a.document.documentElement;
    function dc(a) {
        return m.isWindow(a) ? a : 9 === a.nodeType ? a.defaultView || a.parentWindow : !1;
    }
    m.offset = {
        setOffset: function (a, b, c) {
            var d, e, f, g, h, i, j, k = m.css(a, 'position'), l = m(a), n = {};
            'static' === k && (a.style.position = 'relative'), h = l.offset(), f = m.css(a, 'top'), i = m.css(a, 'left'), j = ('absolute' === k || 'fixed' === k) && m.inArray('auto', [
                f,
                i
            ]) > -1, j ? (d = l.position(), g = d.top, e = d.left) : (g = parseFloat(f) || 0, e = parseFloat(i) || 0), m.isFunction(b) && (b = b.call(a, c, h)), null != b.top && (n.top = b.top - h.top + g), null != b.left && (n.left = b.left - h.left + e), 'using' in b ? b.using.call(a, n) : l.css(n);
        }
    }, m.fn.extend({
        offset: function (a) {
            if (arguments.length)
                return void 0 === a ? this : this.each(function (b) {
                    m.offset.setOffset(this, a, b);
                });
            var b, c, d = {
                    top: 0,
                    left: 0
                }, e = this[0], f = e && e.ownerDocument;
            if (f)
                return b = f.documentElement, m.contains(b, e) ? (typeof e.getBoundingClientRect !== K && (d = e.getBoundingClientRect()), c = dc(f), {
                    top: d.top + (c.pageYOffset || b.scrollTop) - (b.clientTop || 0),
                    left: d.left + (c.pageXOffset || b.scrollLeft) - (b.clientLeft || 0)
                }) : d;
        },
        position: function () {
            if (this[0]) {
                var a, b, c = {
                        top: 0,
                        left: 0
                    }, d = this[0];
                return 'fixed' === m.css(d, 'position') ? b = d.getBoundingClientRect() : (a = this.offsetParent(), b = this.offset(), m.nodeName(a[0], 'html') || (c = a.offset()), c.top += m.css(a[0], 'borderTopWidth', !0), c.left += m.css(a[0], 'borderLeftWidth', !0)), {
                    top: b.top - c.top - m.css(d, 'marginTop', !0),
                    left: b.left - c.left - m.css(d, 'marginLeft', !0)
                };
            }
        },
        offsetParent: function () {
            return this.map(function () {
                var a = this.offsetParent || cc;
                while (a && !m.nodeName(a, 'html') && 'static' === m.css(a, 'position'))
                    a = a.offsetParent;
                return a || cc;
            });
        }
    }), m.each({
        scrollLeft: 'pageXOffset',
        scrollTop: 'pageYOffset'
    }, function (a, b) {
        var c = /Y/.test(b);
        m.fn[a] = function (d) {
            return V(this, function (a, d, e) {
                var f = dc(a);
                return void 0 === e ? f ? b in f ? f[b] : f.document.documentElement[d] : a[d] : void (f ? f.scrollTo(c ? m(f).scrollLeft() : e, c ? e : m(f).scrollTop()) : a[d] = e);
            }, a, d, arguments.length, null);
        };
    }), m.each([
        'top',
        'left'
    ], function (a, b) {
        m.cssHooks[b] = La(k.pixelPosition, function (a, c) {
            return c ? (c = Ja(a, b), Ha.test(c) ? m(a).position()[b] + 'px' : c) : void 0;
        });
    }), m.each({
        Height: 'height',
        Width: 'width'
    }, function (a, b) {
        m.each({
            padding: 'inner' + a,
            content: b,
            '': 'outer' + a
        }, function (c, d) {
            m.fn[d] = function (d, e) {
                var f = arguments.length && (c || 'boolean' != typeof d), g = c || (d === !0 || e === !0 ? 'margin' : 'border');
                return V(this, function (b, c, d) {
                    var e;
                    return m.isWindow(b) ? b.document.documentElement['client' + a] : 9 === b.nodeType ? (e = b.documentElement, Math.max(b.body['scroll' + a], e['scroll' + a], b.body['offset' + a], e['offset' + a], e['client' + a])) : void 0 === d ? m.css(b, c, g) : m.style(b, c, d, g);
                }, b, f ? d : void 0, f, null);
            };
        });
    }), m.fn.size = function () {
        return this.length;
    }, m.fn.andSelf = m.fn.addBack, 'function' == typeof define && define.amd && define('jquery', [], function () {
        return m;
    });
    var ec = a.jQuery, fc = a.$;
    return m.noConflict = function (b) {
        return a.$ === m && (a.$ = fc), b && a.jQuery === m && (a.jQuery = ec), m;
    }, typeof b === K && (a.jQuery = a.$ = m), m;
});
(function (factory) {
    if (typeof define === 'function' && define.amd) {
        define('common/setting', [], factory);
    } else {
        window.commonsetting = factory();
    }
}(function () {
    var u = /MSIE (\d*).0|Chrome|Firefox/i.exec(window.navigator.userAgent);
    return {
        layerSetting: {
            type: 0,
            debug: true
        },
        LabelSetting: {
            check: function (node) {
                return this.getNode(node) !== undefined;
            },
            get: function (node) {
                node = this.getNode(node);
                if (node.nodeValue && !/^\s*$/.test(node.nodeValue))
                    return node.nodeValue;
                else if (!node.nodeValue && node.nodeName == 'SPAN')
                    return node.innerHTML;
                else
                    return '';
            },
            getNode: function (node) {
                if (node === undefined)
                    return undefined;
                else if (node.nodeValue && !/^\s*$/.test(node.nodeValue) || !node.nodeValue && node.nodeName == 'SPAN')
                    return node;
                else
                    return node.nextSibling && (node.nextSibling.nodeName == 'SPAN' || node.nextSibling.nodeName == '#text') ? arguments.callee(node.nextSibling) : undefined;
            }
        },
        Browser: function () {
            var userAgent = navigator.userAgent;
            var isOpera = userAgent.indexOf('Opera') > -1;
            var isIE = userAgent.indexOf('compatible') > -1 && userAgent.indexOf('MSIE') > -1 && !isOpera || userAgent.indexOf('Trident') > -1 && userAgent.indexOf('rv:') > -1;
            var isFF = userAgent.indexOf('Firefox') > -1;
            var isSafari = userAgent.indexOf('Safari') > -1 && userAgent.indexOf('Chrome') == -1 && userAgent.indexOf('Edge') == -1;
            var isChrome = userAgent.indexOf('Chrome') > -1 && userAgent.indexOf('Edge') == -1;
            var isEdge = userAgent.indexOf('Edge') > -1;
            if (isIE) {
                /MSIE (\d+\.\d+);|rv:(\d+\.\d+)/.test(userAgent);
                var IEVersion = parseInt(RegExp.$1 || RegExp.$2);
                if (IEVersion)
                    return 'IE' + IEVersion;
                else
                    return '';
            }
            if (isFF)
                return 'FF';
            if (isOpera)
                return 'Opera';
            if (isSafari)
                return 'Safari';
            if (isChrome)
                return 'Chrome';
            if (isEdge)
                return 'Edge';
        },
        Navigator: {
            LowIEOrNoIE: function () {
                return u !== null && ~~u[1] < 8;
            }(),
            IsIE8: function () {
                return u === null ? false : ~~u[1] == 8;
            }(),
            IsBackCompat: document.compatMode == 'BackCompat'
        }
    };
}));
define('Core', [], function () {
    var core = function () {
        this.versions = '1.0';
    };
    var de = [
            'hasOwnProperty',
            'isPrototypeOf',
            'propertyIsEnumerable',
            'toLocaleString',
            'toString',
            'valueOf'
        ], except = function (k) {
            for (var i = 0; i < de.length; i++) {
                if (de[i] === k)
                    return false;
            }
            return true;
        };
    core.prototype = {
        constructor: core,
        extend: function (o, b, inner) {
            b = b || this;
            for (var k in o) {
                if (o.hasOwnProperty(k)) {
                    var obj = o[k], fn = null;
                    if (!except(k))
                        continue;
                    if (!inner && typeof b[k] == 'function' && typeof obj == 'function')
                        fn = b[k];
                    b[k] = o[k];
                    if (fn)
                        b[k].fn = fn;
                }
            }
            return b;
        }
    };
    core.classes = {};
    return function () {
        var c = new core();
        c.sup = core;
        return c;
    };
});
define('Class', [], function () {
    var ClassLibrary = {
        Classes: {},
        _callParent: function () {
            return arguments.callee.caller && arguments.callee.caller.fn ? arguments.callee.caller.fn.apply(this, arguments) : null;
        },
        _isDontEnum: function () {
            for (var key in { constructor: 1 })
                if (key == 'constructor')
                    return false;
            return true;
        },
        _extend: function (b, e, isRecursion) {
            b = b || {};
            for (var k in e) {
                var current = e[k];
                var ctype = Object.prototype.toString.apply(current);
                if (ctype == '[object Function]') {
                    var fn;
                    if (Object.prototype.toString.apply(b[k]) == '[object Function]')
                        fn = b[k];
                    b[k] = current;
                    if (fn)
                        b[k].fn = fn;
                } else if (ctype == '[object Object]') {
                    if (!b[k])
                        b[k] = {};
                    arguments.callee(b[k], e[k], true);
                } else
                    b[k] = current;
            }
            if (!isRecursion && ClassLibrary._isDontEnum() && b.constructor) {
                var constructor = b.constructor;
                b.constructor = e.constructor;
                b.constructor.fn = constructor;
            }
        },
        Class: function (sub, method, sup, area) {
            sup = sup || Object;
            area = area || ClassLibrary.Classes;
            var name;
            var space = sub.split('.');
            space.reverse();
            sub = space.shift();
            while ((name = space.pop()) != null) {
                if (!area[name])
                    area[name] = {};
                area = area[name];
            }
            var subclassProto = Object.create ? Object.create(sup.prototype) : function () {
                var Super = function () {
                };
                Super.prototype = sup.prototype;
                return new Super();
            }();
            ClassLibrary._extend(subclassProto, method);
            sub = area[sub] = subclassProto.constructor;
            sub.prototype = subclassProto;
            sub.prototype.constructor = sub;
            sub.prototype.callParent = ClassLibrary._callParent;
            return sub;
        }
    };
    window.ClassLibrary = ClassLibrary;
    return ClassLibrary.Class;
});
define('Guid', [], function () {
    function Guid(g) {
        var arr = new Array();
        if (typeof g == 'string') {
            InitByString(arr, g);
        } else {
            InitByOther(arr);
        }
        this.Equals = function (o) {
            if (o && o.IsGuid) {
                return this.ToString() == o.ToString();
            } else {
                return false;
            }
        };
        this.IsGuid = function () {
        };
        this.ToString = function (format) {
            if (typeof format == 'string') {
                if (format == 'N' || format == 'D' || format == 'B' || format == 'P') {
                    return ToStringWithFormat(arr, format);
                } else {
                    return ToStringWithFormat(arr, 'D');
                }
            } else {
                return ToStringWithFormat(arr, 'D');
            }
        };
        function InitByString(arr, g) {
            g = g.replace(/\{|\(|\)|\}|-/g, '');
            g = g.toLowerCase();
            if (g.length != 32 || g.search(/[^0-9,a-f]/i) != -1) {
                InitByOther(arr);
            } else {
                for (var i = 0; i < g.length; i++) {
                    arr.push(g[i]);
                }
            }
        }
        function InitByOther(arr) {
            var i = 32;
            while (i--) {
                arr.push('0');
            }
        }
        function ToStringWithFormat(arr, format) {
            switch (format) {
            case 'N':
                return arr.toString().replace(/,/g, '');
            case 'D':
                var str = arr.slice(0, 8) + '-' + arr.slice(8, 12) + '-' + arr.slice(12, 16) + '-' + arr.slice(16, 20) + '-' + arr.slice(20, 32);
                str = str.replace(/,/g, '');
                return str;
            case 'B':
                var str = ToStringWithFormat(arr, 'D');
                str = '{' + str + '}';
                return str;
            case 'P':
                var str = ToStringWithFormat(arr, 'D');
                str = '(' + str + ')';
                return str;
            default:
                return new Guid();
            }
        }
    }
    Guid.Empty = new Guid();
    Guid.NewGuid = function () {
        var g = '';
        var i = 32;
        while (i--) {
            g += Math.floor(Math.random() * 16).toString(16);
        }
        return new Guid(g);
    };
    return Guid;
});
define('comsys/base/Base', [
    'jquery',
    'Core',
    'Class',
    'Guid'
], function ($, Core, Class, Guid) {
    var ClassName = 'Controll.Base';
    return Class(ClassName, {
        constructor: function (args) {
            args = args || {};
            this.callParent(args);
            this.setting = {};
            if (args.setting)
                this.setting = $.extend({}, args.setting);
            this.classids = Guid.NewGuid().ToString('D');
        },
        initialize: function () {
            return this;
        }
    }, Core);
});
define('comsys/layout/TextCalulate', ['jquery'], function () {
    var TextCalulate = {
        init: function () {
            if (this.$Container)
                return;
            this.$Container = $(document.createElement('DIV'));
            this.$InnerContainer = $(document.createElement('DIV'));
            this.$Container.css({
                width: 0,
                height: 0,
                position: 'relative',
                background: 'green',
                overFlow: 'hidden'
            });
            this.$InnerContainer.css({
                position: 'absolute',
                background: 'brown',
                left: 1,
                top: 1,
                whiteSpace: 'nowrap'
            });
            this.$Container.append(this.$InnerContainer);
            $(document.body).append(this.$Container);
        },
        getOption: function (html, style) {
            this.init();
            style = style || {};
            var $span = $(document.createElement('SPAN')).css(style).html(html);
            this.$InnerContainer.append($span);
            var result = {
                width: $span.width() + 2,
                height: $span.height()
            };
            $span.remove();
            return result;
        },
        getWidth: function (html, style) {
            this.init();
            style = style || {};
            var $span = $(document.createElement('SPAN')).css(style).html(html);
            this.$InnerContainer.append($span);
            var result = $span.width();
            $span.remove();
            return result + 2;
        }
    };
    return TextCalulate;
});
define('comsys/layout/MaskLayer', [
    'jquery',
    'comsys/base/Base',
    'comsys/layout/TextCalulate'
], function ($, Base, TextCalulate) {
    var ClassName = 'MaskLayer';
    var MaskLayer = function (opt, ft) {
        opt = opt || { type: 0 };
        this.c = null;
        this.t = null;
        this.w = null;
        this.m = null;
        this.f = null;
        this.b = null;
        this.classids = ClassName;
        this.font = ft || {
            'fontFamily': '宋体,Lucida Grande, Lucida Sans, Arial, sans-serif',
            'fontSize': '14px'
        };
        this.options = {
            loading: opt.loading || MaskLayer.LOADING[typeof opt.type == 'number' ? opt.type % MaskLayer.LOADING.length : 0].loading,
            width: opt.width || MaskLayer.LOADING[typeof opt.type == 'number' ? opt.type % MaskLayer.LOADING.length : 0].width,
            height: opt.height || MaskLayer.LOADING[typeof opt.type == 'number' ? opt.type % MaskLayer.LOADING.length : 0].height,
            color: 'black',
            defaultText: typeof opt.defaultText == 'string' ? opt.defaultText : MaskLayer.LOADING[typeof opt.type == 'number' ? opt.type % MaskLayer.LOADING.length : 0].defaultText
        };
        this.status = false;
        this.debug = opt.debug || false;
        return this.init();
    };
    MaskLayer.LOADING = [
        {
            loading: 'data:image/gif;base64,R0lGODlhIAAgALMAAP///7Ozs/v7+9bW1uHh4fLy8rq6uoGBgTQ0NAEBARsbG8TExJeXl/39/VRUVAAAACH/C05FVFNDQVBFMi4wAwEAAAAh+QQFBQAAACwAAAAAIAAgAAAE5xDISSlLrOrNp0pKNRCdFhxVolJLEJQUoSgOpSYT4RowNSsvyW1icA16k8MMMRkCBjskBTFDAZyuAEkqCfxIQ2hgQRFvAQEEIjNxVDW6XNE4YagRjuBCwe60smQUDnd4Rz1ZAQZnFAGDd0hihh12CEE9kjAEVlycXIg7BAsMB6SlnJ87paqbSKiKoqusnbMdmDC2tXQlkUhziYtyWTxIfy6BE8WJt5YEvpJivxNaGmLHT0VnOgGYf0dZXS7APdpB309RnHOG5gDqXGLDaC457D1zZ/V/nmOM82XiHQjYKhKP1oZmADdEAAAh+QQFBQAAACwAAAAAGAAXAAAEchDISasKNeuJFKoHs4mUYlJIkmjIV54Soypsa0wmLSnqoTEtBw52mG0AjhYpBxioEqRNy8V0qFzNw+GGwlJki4lBqx1IBgjMkRIghwjrzcDti2/Gh7D9qN774wQGAYOEfwCChIV/gYmDho+QkZKTR3p7EQAh+QQFBQAAACwBAAAAHQAOAAAEchDISWdANesNHHJZwE2DUSEo5SjKKB2HOKGYFLD1CB/DnEoIlkti2PlyuKGEATMBaAACSyGbEDYD4zN1YIEmh0SCQQgYehNmTNNaKsQJXmBuuEYPi9ECAU/UFnNzeUp9VBQEBoFOLmFxWHNoQw6RWEocEQAh+QQFBQAAACwHAAAAGQARAAAEaRDICdZZNOvNDsvfBhBDdpwZgohBgE3nQaki0AYEjEqOGmqDlkEnAzBUjhrA0CoBYhLVSkm4SaAAWkahCFAWTU0A4RxzFWJnzXFWJJWb9pTihRu5dvghl+/7NQmBggo/fYKHCX8AiAmEEQAh+QQFBQAAACwOAAAAEgAYAAAEZXCwAaq9ODAMDOUAI17McYDhWA3mCYpb1RooXBktmsbt944BU6zCQCBQiwPB4jAihiCK86irTB20qvWp7Xq/FYV4TNWNz4oqWoEIgL0HX/eQSLi69boCikTkE2VVDAp5d1p0CW4RACH5BAUFAAAALA4AAAASAB4AAASAkBgCqr3YBIMXvkEIMsxXhcFFpiZqBaTXisBClibgAnd+ijYGq2I4HAamwXBgNHJ8BEbzgPNNjz7LwpnFDLvgLGJMdnw/5DRCrHaE3xbKm6FQwOt1xDnpwCvcJgcJMgEIeCYOCQlrF4YmBIoJVV2CCXZvCooHbwGRcAiKcmFUJhEAIfkEBQUAAAAsDwABABEAHwAABHsQyAkGoRivELInnOFlBjeM1BCiFBdcbMUtKQdTN0CUJru5NJQrYMh5VIFTTKJcOj2HqJQRhEqvqGuU+uw6AwgEwxkOO55lxIihoDjKY8pBoThPxmpAYi+hKzoeewkTdHkZghMIdCOIhIuHfBMOjxiNLR4KCW1ODAlxSxEAIfkEBQUAAAAsCAAOABgAEgAABGwQyEkrCDgbYvvMoOF5ILaNaIoGKroch9hacD3MFMHUBzMHiBtgwJMBFolDB4GoGGBCACKRcAAUWAmzOWJQExysQsJgWj0KqvKalTiYPhp1LBFTtp10Is6mT5gdVFx1bRN8FTsVCAqDOB9+KhEAIfkEBQUAAAAsAgASAB0ADgAABHgQyEmrBePS4bQdQZBdR5IcHmWEgUFQgWKaKbWwwSIhc4LonsXhBSCsQoOSScGQDJiWwOHQnAxWBIYJNXEoFCiEWDI9jCzESey7GwMM5doEwW4jJoypQQ743u1WcTV0CgFzbhJ5XClfHYd/EwZnHoYVDgiOfHKQNREAIfkEBQUAAAAsAAAPABkAEQAABGeQqUQruDjrW3vaYCZ5X2ie6EkcKaooTAsi7ytnTq046BBsNcTvItz4AotMwKZBIC6H6CVAJaCcT0CUBTgaTg5nTCu9GKiDEMPJg5YBBOpwlnVzLwtqyKnZagZWahoMB2M3GgsHSRsRACH5BAUFAAAALAEACAARABgAAARcMKR0gL34npkUyyCAcAmyhBijkGi2UW02VHFt33iu7yiDIDaD4/erEYGDlu/nuBAOJ9Dvc2EcDgFAYIuaXS3bbOh6MIC5IAP5Eh5fk2exC4tpgwZyiyFgvhEMBBEAIfkEBQUAAAAsAAACAA4AHQAABHMQyAnYoViSlFDGXBJ808Ep5KRwV8qEg+pRCOeoioKMwJK0Ekcu54h9AoghKgXIMZgAApQZcCCu2Ax2O6NUud2pmJcyHA4L0uDM/ljYDCnGfGakJQE5YH0wUBYBAUYfBIFkHwaBgxkDgX5lgXpHAXcpBIsRADs=',
            height: 32,
            width: 32,
            defaultText: '正在加载'
        },
        {
            loading: 'data:image/gif;base64,R0lGODlhvgAOAOYAAP///8nJyQEaS5OTk4qOknNycyB05zWU6CqC6DiW5g1RwgQtgQg9ihho3hxu0ESe+GOo5Fqx+HDK+G7D+HDK9TOM7ojN74+vzgszbGrF9DOO6AtIqWe99zSO6FOs9xtZkS+I2tTU1BlqzoXL7kGa9hRIc2ar5KWkpLy7vFel66bD1QUoYRdo3il53MTExI/N+2K67Clxs5GbpDuJtgc7ikaZ6onV+JuirRlgqzCJ7YmKiz6X9mfD9i6G65vX9gg7lhJdyKje90RRYpOSkrbj+MrJyZubm4qOkZWUlAEZRoqPkgEUPMnIyAIeVI2RlWFhYQEaSkN9oZKVl5STk8zLy83NzQEWRFVgbQIbTbKysmbC7wMeSbCytD2T6jOB6juO6n3N+E6s4DON7jeV53Cw53eUv0qP5lWZ7a2trkuZ3h92xRNb0TFlmHDC6z+Z5l+l4mWs7YKjy4nA7QQxhwg5fnu9+Vy26UKf0n7A+mqx8AAAAAAAAAAAAAAAAAAAAAAAACH/C05FVFNDQVBFMi4wAwEAAAAh+QQEAAAAACwAAAAAvgAOAAAH/4AAACFGQ0MDiImKi4yNjo+QkZKTlJWWl5iNSEZoVYIAOk8FOkcEpqeoqaqrrK2ur7CxsrO0tbarSk5SUygAJ08XQT4WxMXGFiYQysvMECYjx8fJzc3P0dHT1MvW18bZ2s7Q3cXf2tzjyODb4ujl1NYjbWFcIQUyREFg+vv7GRkJAAMKDCihoMGDEgYqBEihocOHDhcqhEixocSBFSleFJgR4saAHR9+ZOhQy50oKAqoCGIDTMZ/I3l0hPlRZkiaG23OHJlA50uePivivBiU4lCJPrXM+JBypQ2EBjMcmEq1KlUeUKNa3ToVa1atXK16/SpBatiqY7+aPduVbMG1bP/TZoV7Vi6MGSWa+gAzoa/fCRw6dNBAeHDhwR04/F0cGDHhx4cVL2ZsWLBgDZcJS57sNzDkw5gHb+YM2PBn0xpGc/aMOvRl1ZM9Y4aMGvbdvCpfcIjAu7cHBMCDCw/uobdx3r+HK0dQ/Pjx5MuFN3fuO/rw6dQjQLfOPHt17sCxU99uXTzvFDFwq8Dj4YF79yQMyJ9Pf/6O9/jh198v/37+/PHxV59//70XoID2FYjfgQgaQKCCDCL4YIERCjjhe13EgEFKF+RRgxgVhJhDAyQ2wEKJKDbQQwUgghiiiCmeGGMPYrjIYog1VjDiiTKmSCKNNr5444glsiBjjyri+GLujizu6COKLAB545JNPomkijm62CKMVqK44pZCtvDBCijoEEcNLTigpggKtOnmm26KoOacdLIJ550KyEnnng7YieebevI5p59/thmooH0WCiiigyoaJ6NrOmoooyLgQIcVLmRxAxAbMMAADQuEKuqootLg6amogkrqqguYiuqrn7K6qquwnqqqrKXWmiquo9KqKwO85vqrp8GG6iusdGBghRAhAIDCDRg0gYUA1FZr7bXYZqvtttx26+234IYr7rjkZgtFEktc4cInIbjgAhMBxCvvvPTWa++9+Oar77789uvvvwAHbG8RRVDRLACBAAAh+QQEAAAAACwBAAIAvAAKAAAH/4BPF3JkJhAQJiMWi4yNi4aHkZKIio6NkJOSiZaWmJmHm5yXn5qVoo+kkaGnFp6fq6eukW9pIGgycim6uhS9vr++CcLDxMPAx8XJwsfMysnMyM7E0MDS09TB1svYvdpjalEXeSluwjzcGdrm1Onq59jt2u/s6gkZ6PXz0PHW+sz8ysZomPFBXI0xB3hIWMiwoYQMByJKnChRoUOGEClqTHjRYcaNEy12XPgRZESRI0uaRNlRJUiWF11utDOjxAU4NTpwmMCzp88JHDpo6EBUg9GjQnf+7BnUqFCiT6EqXcq0qFOhQ7NOpQoU69WrSblW9XrUqdGtVINCzYr0rFieTf+9WpUKo+aFFF88RNjLt28EDwgCCx4sWK9fvoAJK0Zg+DDixYobO/4LmbBkx4krB758OLNmzn49V9abIkaJOGdSPFjNuvUDEgZiy54te4fr1rBp6zZg+zbu3bp7+16dG3jt4ayLG+eNnPjy482VG+/dJQaGODjFiKlQQTt37TkasGhAXnx58ix6bOfe/Xv48/DRq2/vvfv29+fHw+/Bnn5//PqVFyB/69n3n4AInsdfewba916A+ZFHIIP9ifFghAqy18IHK8RRQwsOhCiiiCIoYOKJKJ4owogslpjiiwqsyGKLML4o44wk1pjijTg64KKOJvKI449ACjkjkTreKAJCDnRscQMQGzAg5ZRS0rDAlVhmiSUNVHZppZZgLsBll2SGCeaYZFJpppZopsnAl2te2WaacMY5J5l1rtkmHRhsIUQgACH5BAQAAAAALAEAAgC8AAoAAAf/gE8qcmQmEIeIiCYjFo2Oj42GiZMQi5CQkpSKjJeYmomWnY+Zn6GikZ+bp46kmqanhm9pIGgycikpCbq7vBS+v8C/vMO9wcHEyMbKyMTKxszDzsfQu9LA1NXWwrpjamwXeSlu0DzaGdi65c7n6OrS7Nju6+gJ8srw1PbG+OTmvGMacJQAV2PMgYMID/KQwLChQwkZEkpMuPBhw4gTJ1a0eDGjRo4OMXpEuBGkyJEHSnI8OVKlRZYHQODAcAFOjQ4dNGjImZPDhJ9Ag07ggBPnzpw7dXbwKRQo0aRGdR5d2lToU6RTjVKt6hSrV6RbuQ4FK7WoUaZiryY9ChUtV6I8/4/KpJniC4K7eBF4iMC3r98IHvIKzrv3b9/AgwcXNnw4sWLGfhE7xrsYsuTJeiE3xny3MuPLeVvMjHPGi4HTqHc8WM269QMSqGPLNqDaNWvYs2fXtn07t27erXH7Tg2893DixV8fR15c+OwGG1bEMdOigXXrPcRU0F6h+/btOa6LH9+gh3ftYtJXCD+eRQP37st3T89dvRj24lnEfy+/vvr57O1HXnncnefdevxdF99+5m2HnoH4kQdff/VB2J517gHxQxNltLCGAiAqIIIDJJZoogMihKjiiiKeaGKKLLI4oosvxigjjTXaqOKMOKKo4449kgjjjy0GOaSN0W1xwz0GP8yxwAI0MCDllFQyQMOTWGaZZZRVTnmllmBC2WWVX4a55ZhVmqkll2haqeaZbbr55pNsolmmmitsIUQgACH5BAQAAAAALAEAAgC8AAoAAAf/gE8qQT4WhhYmEIqLjBAmI4eRkomNjY+Sk5WWkJiZmouXnZGUn46cooakn6GoiKWKrJIjbWFcN0QUubkJvL2+vbrBwhS/xbzDwsbFyMPKv8zJzsDQutLT1MTWCdhad2yDNmAUGdoJPNjk2ufM6dbr0O3S7+zl88jxzvbD+Mr6wjA4SoCTkOGAwYMID/KQwLChQ4IJIxpc+LBhQYkJKVa0iDHjRocXO078yFHkSJIQTR7Q+DEDCBwYVPgAw6GDhps2b+K0yWGCz59AJ9TMSdSm0Z5Bfw7FqVNDh6cdkCZV+tSp0ao5pU4VmtNqUZ5bqRJ1uvOm1qlDr1bVGTWsz5ov/2O+4ICgrt27dj1E2Mu3bwQPeAPX1euXL2DBeAkXNow48eK+hxsPfsxY8mTKfy1fpny4BUwVdbwYGE269OgdD1KrXv2AhOnXp1mvdg3bNGrZs2vbxp1bN+nbvFv7/h08Ne3hwHkfb7BhxQUzLRpIny6dhfQeFcRUyK69e4Uc1BtYp24d+3bu28WAtz4+fHnt6c+nBx9++ngW2MXozy7/e/X61OXXnX7wqQdgfT3Ax9+C/rnX3nX87VeggdMB8UMTZbSwhgIcduihCA6EKOKIDojg4YkfkjiiiSiiCKKKK7boIowxypgijSGyaCOHL+Ko44490vijAs1ZccMGP8yxwDeSTC5JAwNQRiklAzQ0aWWTT04ZZZVXXpmlllt26SWYU4pp5Zdkcmmmk2SGuSabbVJ55QpWCBEIADs=',
            height: 14,
            width: 190,
            defaultText: '正在加载'
        }
    ];
    MaskLayer.prototype = {
        constructor: MaskLayer,
        init: function () {
            var me = this;
            var u = /MSIE (\d*).0/i.exec(window.navigator.appVersion);
            me.LowIE = u != null && ~~u[1] < 8;
            if ($('#' + this.classids).length !== 0) {
                return $('#' + this.classids).data(ClassName);
            } else {
                me.layoutCount = 0;
                me.b = $(document.createElement('div'));
                me.c = $(document.createElement('div'));
                me.t = $(document.createElement('div'));
                me.w = $(document.createElement('span'));
                me.m = $(document.createElement('img'));
                me.f = $(document.createElement('iframe'));
                me.l = $('<div class="progress"><span class="green bar" style="width: 0%;"><span class="txt">0%</span></span></div>').css({
                    position: 'absolute',
                    left: '50%',
                    top: '40%'
                });
                me.bar = me.l.find('.bar');
                me.txt = me.l.find('.txt');
                me.b.css({
                    position: 'absolute',
                    left: '50%',
                    top: '40%',
                    marginTop: -5,
                    background: 'white',
                    borderRadius: '4px',
                    boxShadow: '1px 1px 3px black',
                    filter: 'progid:DXImageTransform.Microsoft.Shadow(Strength=3, Direction=135, color=black)'
                });
                if (me.LowIE)
                    me.c.css({
                        width: '100%',
                        height: '100%',
                        display: 'none',
                        position: 'absolute',
                        left: 0,
                        top: 0,
                        zIndex: 950
                    });
                else
                    me.c.css({
                        width: '100%',
                        height: '100%',
                        display: 'none',
                        position: 'fixed',
                        left: 0,
                        top: 0,
                        zIndex: 950
                    });
                me.t.css({
                    width: '100%',
                    height: '100%',
                    filter: 'alpha(opacity=20)',
                    opacity: 0.2,
                    position: 'absolute',
                    background: me.options.color,
                    left: 0,
                    top: 0
                });
                me.w.css({
                    position: 'absolute',
                    left: '50%',
                    top: '40%',
                    marginTop: me.options.height + 5
                }).css(me.font);
                me.m.css({
                    position: 'absolute',
                    left: '50%',
                    top: '40%',
                    marginLeft: -me.options.width / 2 - 2
                }).attr({
                    src: me.options.loading,
                    width: me.options.width,
                    height: me.options.height
                });
                me.f.css({
                    width: '100%',
                    height: '100%',
                    overflow: 'hidden',
                    position: 'absolute',
                    zIndex: '-2',
                    filter: 'progid:DXImageTransform.Microsoft.Alpha(opacity=0)',
                    opacity: 0,
                    left: 0,
                    top: 0
                }).attr({
                    frameborder: 0,
                    scrolling: 'no'
                });
                me.c.append(me.t);
                me.c.append(me.f);
                me.c.append(me.b);
                me.c.append(me.l);
                me.c.append(me.m);
                me.c.append(me.w);
                me.c.attr('id', this.classids);
                $(document.body).append(me.c);
                me.c.bind('mousewheel', function () {
                    return false;
                });
                me.c.data(ClassName, this);
            }
            return this;
        },
        bind: function (mousewheel) {
            mousewheel = mousewheel || function () {
                return false;
            };
            this.onmousewheel = document.body.onmousewheel;
            document.body.onmousewheel = mousewheel;
        },
        unbind: function () {
            document.body.onmousewheel = this.onmousewheel;
        },
        mask: function (mousewheel) {
            this.status = true;
            var me = this;
            if (++me.layoutCount !== 1)
                return;
            if (me.LowIE) {
                if (me.c.attr('scroll-bind') !== 'true') {
                    document.body.onscroll = function () {
                        me.c.css({ top: document.body.scrollTop });
                    };
                    me.c.attr('scroll-bind', 'true');
                }
                ;
                $(document.body).css({ overFlow: 'hidden' });
            }
            me.l.hide();
            me.m.hide();
            me.b.hide();
            me.w.hide();
            me.c.show(mousewheel);
            this.bind();
        },
        setprogress: function (percent, src, delay, completeTxt, errorTxt, width, height) {
            var timeoutID = null, me = this, delay = delay || 500, temp = percent, disposeSrc = function (s) {
                    return s + (s.indexOf('?') > -1 ? '&' : '?') + 'cache=' + new Date().getTime();
                }, success = function (p) {
                    if (typeof (1 * p) == 'number') {
                        me.bar.css({ width: p + '%' });
                        me.txt.html(p + '%');
                        if (p == 100 || p == '100') {
                            me.setTxt('<b style=\'color:green\'>' + completeTxt + '</b>', width, height);
                            window.setTimeout(function () {
                                me.deferred.resolve('success');
                                me.hide('fast');
                            }, 500);
                            window.clearTimeout(timeoutID);
                        } else
                            timeoutID = window.setTimeout(progress, delay);
                    } else
                        me.setTxt('<b style=\'color:red\'>' + errorTxt + '</b>', width, height);
                }, error = function () {
                    me.setTxt('<b style=\'color:red\'>' + errorTxt + '</b>', width, height);
                    window.setTimeout(function () {
                        me.deferred.resolve('success');
                        me.hide('fast');
                    }, 1000);
                    window.clearTimeout(timeoutID);
                }, progress = function () {
                    if (me.debug) {
                        window.setTimeout(function () {
                            temp += 10;
                            me.bar.css({ width: temp + '%' });
                            me.txt.html(temp + '%');
                            if (temp == 100 || temp == '100') {
                                me.setTxt('<b style=\'color:green\'>' + completeTxt + '</b>', width, height);
                                window.setTimeout(function () {
                                    me.deferred.resolve('success');
                                    me.hide('fast');
                                }, 500);
                                window.clearTimeout(timeoutID);
                            } else
                                timeoutID = window.setTimeout(progress, delay);
                        }, delay);
                    } else {
                        $.ajax({
                            type: 'GET',
                            url: disposeSrc(src),
                            success: success,
                            error: error
                        });
                    }
                };
            me.bar.css({ width: temp + '%' });
            me.txt.html(temp + '%');
            timeoutID = window.setTimeout(progress, delay);
        },
        upload: function (setting) {
            this.deferred = new $.Deferred();
            this.deferred.promise(this);
            setting = setting || {};
            var me = this;
            this.status = true;
            if (++me.layoutCount !== 1)
                return;
            if (me.LowIE) {
                if (me.c.attr('scroll-bind') != 'true') {
                    document.body.onscroll = function () {
                        me.c.css({ top: document.body.scrollTop });
                    };
                    me.c.attr('scroll-bind', 'true');
                }
                ;
                $(document.body).css({ overFlow: 'hidden' });
            }
            var progressingTxt = setting.txt || '正在上传';
            var completeTxt = setting.complete || '上传成功';
            var error = setting.complete || '服务器错误';
            var width = setting.width || 400, height = setting.height || 20;
            me.w.css({ marginTop: height + 5 });
            me.l.css({
                marginLeft: -width / 2 - 2,
                width: width,
                height: height
            });
            me.m.hide();
            me.l.show();
            me.b.show();
            me.w.show();
            me.setTxt(progressingTxt, width, height);
            $(me.c).css({ top: me.LowIE ? document.body.scrollTop : 0 }).show();
            this.bind();
            this.setprogress(0, setting.src, setting.delay, completeTxt, error, width, height);
            return this;
        },
        setTxt: function (txt, width, height) {
            var me = this;
            me.w.html(txt);
            var opt = TextCalulate.getOption(txt, me.font);
            me.w.css({ marginLeft: -opt.width / 2 });
            me.b.css({
                width: opt.width < width + 10 ? width + 10 : opt.width + 10,
                height: opt.height + height + 15,
                marginLeft: -(opt.width < width + 10 ? width : opt.width) / 2 - 7
            });
        },
        show: function (txt, setting) {
            var me = this;
            this.status = true;
            if (++me.layoutCount !== 1)
                return;
            if (me.LowIE) {
                if (me.c.attr('scroll-bind') != 'true') {
                    document.body.onscroll = function () {
                        me.c.css({ top: document.body.scrollTop });
                    };
                    me.c.attr('scroll-bind', 'true');
                }
                ;
                $(document.body).css({ overFlow: 'hidden' });
            }
            txt = txt || (setting ? MaskLayer.LOADING[setting.type].defaultText : me.options.defaultText);
            var width = setting ? MaskLayer.LOADING[setting.type].width : me.options.width, height = setting ? MaskLayer.LOADING[setting.type].height : me.options.height, src = setting ? MaskLayer.LOADING[setting.type].loading : me.options.loading;
            me.w.css({ marginTop: height + 5 });
            me.m.css({ marginLeft: -width / 2 - 2 }).attr({
                src: src,
                width: width,
                height: height
            });
            me.l.hide();
            me.m.show();
            me.b.show();
            me.w.show();
            if (txt) {
                me.w.html(txt);
                var opt = TextCalulate.getOption(txt, me.font);
                me.w.css({ marginLeft: -opt.width / 2 });
                me.b.css({
                    width: opt.width < width + 10 ? width + 10 : opt.width + 10,
                    height: opt.height + height + 15,
                    marginLeft: -(opt.width < width + 10 ? width : opt.width) / 2 - 7
                });
                $(me.c).css({ top: me.LowIE ? document.body.scrollTop : 0 }).show();
            } else {
                me.b.css({
                    width: width + 10,
                    height: height + 10,
                    marginLeft: -width / 2 - 7
                });
                $(me.c).show();
            }
            this.bind();
        },
        hide: function (animate) {
            var me = this;
            if (--me.layoutCount !== 0)
                return;
            this.status = false;
            if (animate)
                $(me.c).fadeOut(animate);
            else
                $(me.c).hide();
            if (me.LowIE) {
                $(document.body).css({ overFlow: 'auto' });
            }
            this.unbind();
        },
        forcehide: function (animate) {
            this.status = false;
            if (animate)
                $(me.c).fadeOut(animate);
            else
                $(me.c).hide();
            if (me.LowIE) {
                $(document.body).css({ overFlow: 'auto' });
            }
            this.unbind();
        }
    };
    return MaskLayer;
});
define('TPLEngine', [], function () {
    var TPLEngine;
    TPLEngine = {
        render: function (tpl, data) {
            return this.draw(tpl, data);
        },
        drawlayout: function (tpl, data) {
            var reg = /@\{layout:([\s\S]*?)\}@/g, regRender = /@\{layout\}@/, match;
            if (match = reg.exec(tpl)) {
                var code = 'var r=[];\n';
                var param = match[1].split(',');
                code += 'r.push(TPLEngine.draw(' + param[0] + ',' + param[1] + '));\n';
                code += 'return r.join("");';
                var part = new Function('TPLEngine', code.replace(/[\r\t\n]/g, '')).apply(data, [TPLEngine]);
                return part.replace(regRender, tpl.slice(match[0].length));
            }
            return false;
        },
        draw: function (tpl, data, $parent) {
            $parent = $parent || data;
            var content = tpl;
            (content = this.drawlayout(content, data)) !== false ? tpl = content : undefined;
            var reg = /<%([\s\S]*?)%>|@\{section:([\s\S]*?)\}@/g, regOut = /^\s*=\s*([\s\S]*)$/, code = 'var r=[];\n', cursor = 0, match, e, line;
            var add = function (match, js) {
                var section = match[1] === undefined || match[1] === '';
                line = typeof match == 'string' ? match : section ? match[2] : match[1];
                if (js) {
                    if (section) {
                        var param = line.split(',');
                        var item = param.shift();
                        var param = param.join(',');
                        code += 'this.$parent=$parent;r.push(TPLEngine.draw(' + item + ',' + param + ',this));\n';
                    } else {
                        if ((e = regOut.exec(line)) == null) {
                            code += line + '\n';
                        } else {
                            code += 'r.push(' + e[1] + ');\n';
                        }
                    }
                } else {
                    if (line != '')
                        code += 'r.push("' + line.replace(/"/g, '\\"') + '");\n';
                }
                return add;
            };
            while (match = reg.exec(tpl)) {
                add(tpl.slice(cursor, match.index))(match, true);
                cursor = match.index + match[0].length;
            }
            add(tpl.substr(cursor, tpl.length - cursor));
            code += 'return r.join("");';
            return new Function('$parent', 'TPLEngine', code.replace(/[\r\t\n]/g, '')).apply(data, [
                $parent,
                TPLEngine
            ]);
        }
    };
    return TPLEngine;
});
(function (factory) {
    if (typeof define === 'function' && define.amd) {
        define('libs/jquery-ui/ui/core', ['jquery'], factory);
    } else {
        factory(jQuery);
    }
}(function ($) {
    $.ui = $.ui || {};
    $.extend($.ui, {
        version: '1.11.4',
        keyCode: {
            BACKSPACE: 8,
            COMMA: 188,
            DELETE: 46,
            DOWN: 40,
            END: 35,
            ENTER: 13,
            ESCAPE: 27,
            HOME: 36,
            LEFT: 37,
            PAGE_DOWN: 34,
            PAGE_UP: 33,
            PERIOD: 190,
            RIGHT: 39,
            SPACE: 32,
            TAB: 9,
            UP: 38
        }
    });
    $.fn.extend({
        scrollParent: function (includeHidden) {
            var position = this.css('position'), excludeStaticParent = position === 'absolute', overflowRegex = includeHidden ? /(auto|scroll|hidden)/ : /(auto|scroll)/, scrollParent = this.parents().filter(function () {
                    var parent = $(this);
                    if (excludeStaticParent && parent.css('position') === 'static') {
                        return false;
                    }
                    return overflowRegex.test(parent.css('overflow') + parent.css('overflow-y') + parent.css('overflow-x'));
                }).eq(0);
            return position === 'fixed' || !scrollParent.length ? $(this[0].ownerDocument || document) : scrollParent;
        },
        uniqueId: function () {
            var uuid = 0;
            return function () {
                return this.each(function () {
                    if (!this.id) {
                        this.id = 'ui-id-' + ++uuid;
                    }
                });
            };
        }(),
        removeUniqueId: function () {
            return this.each(function () {
                if (/^ui-id-\d+$/.test(this.id)) {
                    $(this).removeAttr('id');
                }
            });
        }
    });
    function focusable(element, isTabIndexNotNaN) {
        var map, mapName, img, nodeName = element.nodeName.toLowerCase();
        if ('area' === nodeName) {
            map = element.parentNode;
            mapName = map.name;
            if (!element.href || !mapName || map.nodeName.toLowerCase() !== 'map') {
                return false;
            }
            img = $('img[usemap=\'#' + mapName + '\']')[0];
            return !!img && visible(img);
        }
        return (/^(input|select|textarea|button|object)$/.test(nodeName) ? !element.disabled : 'a' === nodeName ? element.href || isTabIndexNotNaN : isTabIndexNotNaN) && visible(element);
    }
    function visible(element) {
        return $.expr.filters.visible(element) && !$(element).parents().addBack().filter(function () {
            return $.css(this, 'visibility') === 'hidden';
        }).length;
    }
    $.extend($.expr[':'], {
        data: $.expr.createPseudo ? $.expr.createPseudo(function (dataName) {
            return function (elem) {
                return !!$.data(elem, dataName);
            };
        }) : function (elem, i, match) {
            return !!$.data(elem, match[3]);
        },
        focusable: function (element) {
            return focusable(element, !isNaN($.attr(element, 'tabindex')));
        },
        tabbable: function (element) {
            var tabIndex = $.attr(element, 'tabindex'), isTabIndexNaN = isNaN(tabIndex);
            return (isTabIndexNaN || tabIndex >= 0) && focusable(element, !isTabIndexNaN);
        }
    });
    if (!$('<a>').outerWidth(1).jquery) {
        $.each([
            'Width',
            'Height'
        ], function (i, name) {
            var side = name === 'Width' ? [
                    'Left',
                    'Right'
                ] : [
                    'Top',
                    'Bottom'
                ], type = name.toLowerCase(), orig = {
                    innerWidth: $.fn.innerWidth,
                    innerHeight: $.fn.innerHeight,
                    outerWidth: $.fn.outerWidth,
                    outerHeight: $.fn.outerHeight
                };
            function reduce(elem, size, border, margin) {
                $.each(side, function () {
                    size -= parseFloat($.css(elem, 'padding' + this)) || 0;
                    if (border) {
                        size -= parseFloat($.css(elem, 'border' + this + 'Width')) || 0;
                    }
                    if (margin) {
                        size -= parseFloat($.css(elem, 'margin' + this)) || 0;
                    }
                });
                return size;
            }
            $.fn['inner' + name] = function (size) {
                if (size === undefined) {
                    return orig['inner' + name].call(this);
                }
                return this.each(function () {
                    $(this).css(type, reduce(this, size) + 'px');
                });
            };
            $.fn['outer' + name] = function (size, margin) {
                if (typeof size !== 'number') {
                    return orig['outer' + name].call(this, size);
                }
                return this.each(function () {
                    $(this).css(type, reduce(this, size, true, margin) + 'px');
                });
            };
        });
    }
    if (!$.fn.addBack) {
        $.fn.addBack = function (selector) {
            return this.add(selector == null ? this.prevObject : this.prevObject.filter(selector));
        };
    }
    if ($('<a>').data('a-b', 'a').removeData('a-b').data('a-b')) {
        $.fn.removeData = function (removeData) {
            return function (key) {
                if (arguments.length) {
                    return removeData.call(this, $.camelCase(key));
                } else {
                    return removeData.call(this);
                }
            };
        }($.fn.removeData);
    }
    $.ui.ie = !!/msie [\w.]+/.exec(navigator.userAgent.toLowerCase());
    $.fn.extend({
        focus: function (orig) {
            return function (delay, fn) {
                return typeof delay === 'number' ? this.each(function () {
                    var elem = this;
                    setTimeout(function () {
                        $(elem).focus();
                        if (fn) {
                            fn.call(elem);
                        }
                    }, delay);
                }) : orig.apply(this, arguments);
            };
        }($.fn.focus),
        disableSelection: function () {
            var eventType = 'onselectstart' in document.createElement('div') ? 'selectstart' : 'mousedown';
            return function () {
                return this.bind(eventType + '.ui-disableSelection', function (event) {
                    event.preventDefault();
                });
            };
        }(),
        enableSelection: function () {
            return this.unbind('.ui-disableSelection');
        },
        zIndex: function (zIndex) {
            if (zIndex !== undefined) {
                return this.css('zIndex', zIndex);
            }
            if (this.length) {
                var elem = $(this[0]), position, value;
                while (elem.length && elem[0] !== document) {
                    position = elem.css('position');
                    if (position === 'absolute' || position === 'relative' || position === 'fixed') {
                        value = parseInt(elem.css('zIndex'), 10);
                        if (!isNaN(value) && value !== 0) {
                            return value;
                        }
                    }
                    elem = elem.parent();
                }
            }
            return 0;
        }
    });
    $.ui.plugin = {
        add: function (module, option, set) {
            var i, proto = $.ui[module].prototype;
            for (i in set) {
                proto.plugins[i] = proto.plugins[i] || [];
                proto.plugins[i].push([
                    option,
                    set[i]
                ]);
            }
        },
        call: function (instance, name, args, allowDisconnected) {
            var i, set = instance.plugins[name];
            if (!set) {
                return;
            }
            if (!allowDisconnected && (!instance.element[0].parentNode || instance.element[0].parentNode.nodeType === 11)) {
                return;
            }
            for (i = 0; i < set.length; i++) {
                if (instance.options[set[i][0]]) {
                    set[i][1].apply(instance.element, args);
                }
            }
        }
    };
}));
(function (factory) {
    if (typeof define === 'function' && define.amd) {
        define('libs/jquery-ui/ui/widget', ['jquery'], factory);
    } else {
        factory(jQuery);
    }
}(function ($) {
    var widget_uuid = 0, widget_slice = Array.prototype.slice;
    $.cleanData = function (orig) {
        return function (elems) {
            var events, elem, i;
            for (i = 0; (elem = elems[i]) != null; i++) {
                try {
                    events = $._data(elem, 'events');
                    if (events && events.remove) {
                        $(elem).triggerHandler('remove');
                    }
                } catch (e) {
                }
            }
            orig(elems);
        };
    }($.cleanData);
    $.widget = function (name, base, prototype) {
        var fullName, existingConstructor, constructor, basePrototype, proxiedPrototype = {}, namespace = name.split('.')[0];
        name = name.split('.')[1];
        fullName = namespace + '-' + name;
        if (!prototype) {
            prototype = base;
            base = $.Widget;
        }
        $.expr[':'][fullName.toLowerCase()] = function (elem) {
            return !!$.data(elem, fullName);
        };
        $[namespace] = $[namespace] || {};
        existingConstructor = $[namespace][name];
        constructor = $[namespace][name] = function (options, element) {
            if (!this._createWidget) {
                return new constructor(options, element);
            }
            if (arguments.length) {
                this._createWidget(options, element);
            }
        };
        $.extend(constructor, existingConstructor, {
            version: prototype.version,
            _proto: $.extend({}, prototype),
            _childConstructors: []
        });
        basePrototype = new base();
        basePrototype.options = $.widget.extend({}, basePrototype.options);
        $.each(prototype, function (prop, value) {
            if (!$.isFunction(value)) {
                proxiedPrototype[prop] = value;
                return;
            }
            proxiedPrototype[prop] = function () {
                var _super = function () {
                        return base.prototype[prop].apply(this, arguments);
                    }, _superApply = function (args) {
                        return base.prototype[prop].apply(this, args);
                    };
                return function () {
                    var __super = this._super, __superApply = this._superApply, returnValue;
                    this._super = _super;
                    this._superApply = _superApply;
                    returnValue = value.apply(this, arguments);
                    this._super = __super;
                    this._superApply = __superApply;
                    return returnValue;
                };
            }();
        });
        constructor.prototype = $.widget.extend(basePrototype, { widgetEventPrefix: existingConstructor ? basePrototype.widgetEventPrefix || name : name }, proxiedPrototype, {
            constructor: constructor,
            namespace: namespace,
            widgetName: name,
            widgetFullName: fullName
        });
        if (existingConstructor) {
            $.each(existingConstructor._childConstructors, function (i, child) {
                var childPrototype = child.prototype;
                $.widget(childPrototype.namespace + '.' + childPrototype.widgetName, constructor, child._proto);
            });
            delete existingConstructor._childConstructors;
        } else {
            base._childConstructors.push(constructor);
        }
        $.widget.bridge(name, constructor);
        return constructor;
    };
    $.widget.extend = function (target) {
        var input = widget_slice.call(arguments, 1), inputIndex = 0, inputLength = input.length, key, value;
        for (; inputIndex < inputLength; inputIndex++) {
            for (key in input[inputIndex]) {
                value = input[inputIndex][key];
                if (input[inputIndex].hasOwnProperty(key) && value !== undefined) {
                    if ($.isPlainObject(value)) {
                        target[key] = $.isPlainObject(target[key]) ? $.widget.extend({}, target[key], value) : $.widget.extend({}, value);
                    } else {
                        target[key] = value;
                    }
                }
            }
        }
        return target;
    };
    $.widget.bridge = function (name, object) {
        var fullName = object.prototype.widgetFullName || name;
        $.fn[name] = function (options) {
            var isMethodCall = typeof options === 'string', args = widget_slice.call(arguments, 1), returnValue = this;
            if (isMethodCall) {
                this.each(function () {
                    var methodValue, instance = $.data(this, fullName);
                    if (options === 'instance') {
                        returnValue = instance;
                        return false;
                    }
                    if (!instance) {
                        return $.error('cannot call methods on ' + name + ' prior to initialization; ' + 'attempted to call method \'' + options + '\'');
                    }
                    if (!$.isFunction(instance[options]) || options.charAt(0) === '_') {
                        return $.error('no such method \'' + options + '\' for ' + name + ' widget instance');
                    }
                    methodValue = instance[options].apply(instance, args);
                    if (methodValue !== instance && methodValue !== undefined) {
                        returnValue = methodValue && methodValue.jquery ? returnValue.pushStack(methodValue.get()) : methodValue;
                        return false;
                    }
                });
            } else {
                if (args.length) {
                    options = $.widget.extend.apply(null, [options].concat(args));
                }
                this.each(function () {
                    var instance = $.data(this, fullName);
                    if (instance) {
                        instance.option(options || {});
                        if (instance._init) {
                            instance._init();
                        }
                    } else {
                        $.data(this, fullName, new object(options, this));
                    }
                });
            }
            return returnValue;
        };
    };
    $.Widget = function () {
    };
    $.Widget._childConstructors = [];
    $.Widget.prototype = {
        widgetName: 'widget',
        widgetEventPrefix: '',
        defaultElement: '<div>',
        options: {
            disabled: false,
            create: null
        },
        _createWidget: function (options, element) {
            element = $(element || this.defaultElement || this)[0];
            this.element = $(element);
            this.uuid = widget_uuid++;
            this.eventNamespace = '.' + this.widgetName + this.uuid;
            this.bindings = $();
            this.hoverable = $();
            this.focusable = $();
            if (element !== this) {
                $.data(element, this.widgetFullName, this);
                this._on(true, this.element, {
                    remove: function (event) {
                        if (event.target === element) {
                            this.destroy();
                        }
                    }
                });
                this.document = $(element.style ? element.ownerDocument : element.document || element);
                this.window = $(this.document[0].defaultView || this.document[0].parentWindow);
            }
            this.options = $.widget.extend({}, this.options, this._getCreateOptions(), options);
            this._create();
            this._trigger('create', null, this._getCreateEventData());
            this._init();
        },
        _getCreateOptions: $.noop,
        _getCreateEventData: $.noop,
        _create: $.noop,
        _init: $.noop,
        destroy: function () {
            this._destroy();
            this.element.unbind(this.eventNamespace).removeData(this.widgetFullName).removeData($.camelCase(this.widgetFullName));
            this.widget().unbind(this.eventNamespace).removeAttr('aria-disabled').removeClass(this.widgetFullName + '-disabled ' + 'ui-state-disabled');
            this.bindings.unbind(this.eventNamespace);
            this.hoverable.removeClass('ui-state-hover');
            this.focusable.removeClass('ui-state-focus');
        },
        _destroy: $.noop,
        widget: function () {
            return this.element;
        },
        option: function (key, value) {
            var options = key, parts, curOption, i;
            if (arguments.length === 0) {
                return $.widget.extend({}, this.options);
            }
            if (typeof key === 'string') {
                options = {};
                parts = key.split('.');
                key = parts.shift();
                if (parts.length) {
                    curOption = options[key] = $.widget.extend({}, this.options[key]);
                    for (i = 0; i < parts.length - 1; i++) {
                        curOption[parts[i]] = curOption[parts[i]] || {};
                        curOption = curOption[parts[i]];
                    }
                    key = parts.pop();
                    if (arguments.length === 1) {
                        return curOption[key] === undefined ? null : curOption[key];
                    }
                    curOption[key] = value;
                } else {
                    if (arguments.length === 1) {
                        return this.options[key] === undefined ? null : this.options[key];
                    }
                    options[key] = value;
                }
            }
            this._setOptions(options);
            return this;
        },
        _setOptions: function (options) {
            var key;
            for (key in options) {
                this._setOption(key, options[key]);
            }
            return this;
        },
        _setOption: function (key, value) {
            this.options[key] = value;
            if (key === 'disabled') {
                this.widget().toggleClass(this.widgetFullName + '-disabled', !!value);
                if (value) {
                    this.hoverable.removeClass('ui-state-hover');
                    this.focusable.removeClass('ui-state-focus');
                }
            }
            return this;
        },
        enable: function () {
            return this._setOptions({ disabled: false });
        },
        disable: function () {
            return this._setOptions({ disabled: true });
        },
        _on: function (suppressDisabledCheck, element, handlers) {
            var delegateElement, instance = this;
            if (typeof suppressDisabledCheck !== 'boolean') {
                handlers = element;
                element = suppressDisabledCheck;
                suppressDisabledCheck = false;
            }
            if (!handlers) {
                handlers = element;
                element = this.element;
                delegateElement = this.widget();
            } else {
                element = delegateElement = $(element);
                this.bindings = this.bindings.add(element);
            }
            $.each(handlers, function (event, handler) {
                function handlerProxy() {
                    if (!suppressDisabledCheck && (instance.options.disabled === true || $(this).hasClass('ui-state-disabled'))) {
                        return;
                    }
                    return (typeof handler === 'string' ? instance[handler] : handler).apply(instance, arguments);
                }
                if (typeof handler !== 'string') {
                    handlerProxy.guid = handler.guid = handler.guid || handlerProxy.guid || $.guid++;
                }
                var match = event.match(/^([\w:-]*)\s*(.*)$/), eventName = match[1] + instance.eventNamespace, selector = match[2];
                if (selector) {
                    delegateElement.delegate(selector, eventName, handlerProxy);
                } else {
                    element.bind(eventName, handlerProxy);
                }
            });
        },
        _off: function (element, eventName) {
            eventName = (eventName || '').split(' ').join(this.eventNamespace + ' ') + this.eventNamespace;
            element.unbind(eventName).undelegate(eventName);
            this.bindings = $(this.bindings.not(element).get());
            this.focusable = $(this.focusable.not(element).get());
            this.hoverable = $(this.hoverable.not(element).get());
        },
        _delay: function (handler, delay) {
            function handlerProxy() {
                return (typeof handler === 'string' ? instance[handler] : handler).apply(instance, arguments);
            }
            var instance = this;
            return setTimeout(handlerProxy, delay || 0);
        },
        _hoverable: function (element) {
            this.hoverable = this.hoverable.add(element);
            this._on(element, {
                mouseenter: function (event) {
                    $(event.currentTarget).addClass('ui-state-hover');
                },
                mouseleave: function (event) {
                    $(event.currentTarget).removeClass('ui-state-hover');
                }
            });
        },
        _focusable: function (element) {
            this.focusable = this.focusable.add(element);
            this._on(element, {
                focusin: function (event) {
                    $(event.currentTarget).addClass('ui-state-focus');
                },
                focusout: function (event) {
                    $(event.currentTarget).removeClass('ui-state-focus');
                }
            });
        },
        _trigger: function (type, event, data) {
            var prop, orig, callback = this.options[type];
            data = data || {};
            event = $.Event(event);
            event.type = (type === this.widgetEventPrefix ? type : this.widgetEventPrefix + type).toLowerCase();
            event.target = this.element[0];
            orig = event.originalEvent;
            if (orig) {
                for (prop in orig) {
                    if (!(prop in event)) {
                        event[prop] = orig[prop];
                    }
                }
            }
            this.element.trigger(event, data);
            return !($.isFunction(callback) && callback.apply(this.element[0], [event].concat(data)) === false || event.isDefaultPrevented());
        }
    };
    $.each({
        show: 'fadeIn',
        hide: 'fadeOut'
    }, function (method, defaultEffect) {
        $.Widget.prototype['_' + method] = function (element, options, callback) {
            if (typeof options === 'string') {
                options = { effect: options };
            }
            var hasOptions, effectName = !options ? method : options === true || typeof options === 'number' ? defaultEffect : options.effect || defaultEffect;
            options = options || {};
            if (typeof options === 'number') {
                options = { duration: options };
            }
            hasOptions = !$.isEmptyObject(options);
            options.complete = callback;
            if (options.delay) {
                element.delay(options.delay);
            }
            if (hasOptions && $.effects && $.effects.effect[effectName]) {
                element[method](options);
            } else if (effectName !== method && element[effectName]) {
                element[effectName](options.duration, options.easing, callback);
            } else {
                element.queue(function (next) {
                    $(this)[method]();
                    if (callback) {
                        callback.call(element[0]);
                    }
                    next();
                });
            }
        };
    });
    return $.widget;
}));
(function (factory) {
    if (typeof define === 'function' && define.amd) {
        define('libs/jquery-ui/ui/mouse', [
            'jquery',
            'libs/jquery-ui/ui/widget'
        ], factory);
    } else {
        factory(jQuery);
    }
}(function ($) {
    var mouseHandled = false;
    $(document).mouseup(function () {
        mouseHandled = false;
    });
    return $.widget('ui.mouse', {
        version: '1.11.4',
        options: {
            cancel: 'input,textarea,button,select,option',
            distance: 1,
            delay: 0
        },
        _mouseInit: function () {
            var that = this;
            this.element.bind('mousedown.' + this.widgetName, function (event) {
                return that._mouseDown(event);
            }).bind('click.' + this.widgetName, function (event) {
                if (true === $.data(event.target, that.widgetName + '.preventClickEvent')) {
                    $.removeData(event.target, that.widgetName + '.preventClickEvent');
                    event.stopImmediatePropagation();
                    return false;
                }
            });
            this.started = false;
        },
        _mouseDestroy: function () {
            this.element.unbind('.' + this.widgetName);
            if (this._mouseMoveDelegate) {
                this.document.unbind('mousemove.' + this.widgetName, this._mouseMoveDelegate).unbind('mouseup.' + this.widgetName, this._mouseUpDelegate);
            }
        },
        _mouseDown: function (event) {
            if (mouseHandled) {
                return;
            }
            this._mouseMoved = false;
            this._mouseStarted && this._mouseUp(event);
            this._mouseDownEvent = event;
            var that = this, btnIsLeft = event.which === 1, elIsCancel = typeof this.options.cancel === 'string' && event.target.nodeName ? $(event.target).closest(this.options.cancel).length : false;
            if (!btnIsLeft || elIsCancel || !this._mouseCapture(event)) {
                return true;
            }
            this.mouseDelayMet = !this.options.delay;
            if (!this.mouseDelayMet) {
                this._mouseDelayTimer = setTimeout(function () {
                    that.mouseDelayMet = true;
                }, this.options.delay);
            }
            if (this._mouseDistanceMet(event) && this._mouseDelayMet(event)) {
                this._mouseStarted = this._mouseStart(event) !== false;
                if (!this._mouseStarted) {
                    event.preventDefault();
                    return true;
                }
            }
            if (true === $.data(event.target, this.widgetName + '.preventClickEvent')) {
                $.removeData(event.target, this.widgetName + '.preventClickEvent');
            }
            this._mouseMoveDelegate = function (event) {
                return that._mouseMove(event);
            };
            this._mouseUpDelegate = function (event) {
                return that._mouseUp(event);
            };
            this.document.bind('mousemove.' + this.widgetName, this._mouseMoveDelegate).bind('mouseup.' + this.widgetName, this._mouseUpDelegate);
            event.preventDefault();
            mouseHandled = true;
            return true;
        },
        _mouseMove: function (event) {
            if (this._mouseMoved) {
                if ($.ui.ie && (!document.documentMode || document.documentMode < 9) && !event.button) {
                    return this._mouseUp(event);
                } else if (!event.which) {
                    return this._mouseUp(event);
                }
            }
            if (event.which || event.button) {
                this._mouseMoved = true;
            }
            if (this._mouseStarted) {
                this._mouseDrag(event);
                return event.preventDefault();
            }
            if (this._mouseDistanceMet(event) && this._mouseDelayMet(event)) {
                this._mouseStarted = this._mouseStart(this._mouseDownEvent, event) !== false;
                this._mouseStarted ? this._mouseDrag(event) : this._mouseUp(event);
            }
            return !this._mouseStarted;
        },
        _mouseUp: function (event) {
            this.document.unbind('mousemove.' + this.widgetName, this._mouseMoveDelegate).unbind('mouseup.' + this.widgetName, this._mouseUpDelegate);
            if (this._mouseStarted) {
                this._mouseStarted = false;
                if (event.target === this._mouseDownEvent.target) {
                    $.data(event.target, this.widgetName + '.preventClickEvent', true);
                }
                this._mouseStop(event);
            }
            mouseHandled = false;
            return false;
        },
        _mouseDistanceMet: function (event) {
            return Math.max(Math.abs(this._mouseDownEvent.pageX - event.pageX), Math.abs(this._mouseDownEvent.pageY - event.pageY)) >= this.options.distance;
        },
        _mouseDelayMet: function () {
            return this.mouseDelayMet;
        },
        _mouseStart: function () {
        },
        _mouseDrag: function () {
        },
        _mouseStop: function () {
        },
        _mouseCapture: function () {
            return true;
        }
    });
}));
(function (factory) {
    if (typeof define === 'function' && define.amd) {
        define('libs/jquery-ui/ui/draggable', [
            'jquery',
            'libs/jquery-ui/ui/core',
            'libs/jquery-ui/ui/mouse',
            'libs/jquery-ui/ui/widget'
        ], factory);
    } else {
        factory(jQuery);
    }
}(function ($) {
    $.widget('ui.draggable', $.ui.mouse, {
        version: '1.11.4',
        widgetEventPrefix: 'drag',
        options: {
            addClasses: true,
            appendTo: 'parent',
            axis: false,
            connectToSortable: false,
            containment: false,
            cursor: 'auto',
            cursorAt: false,
            grid: false,
            handle: false,
            helper: 'original',
            iframeFix: false,
            opacity: false,
            refreshPositions: false,
            revert: false,
            revertDuration: 500,
            scope: 'default',
            scroll: true,
            scrollSensitivity: 20,
            scrollSpeed: 20,
            snap: false,
            snapMode: 'both',
            snapTolerance: 20,
            stack: false,
            zIndex: false,
            drag: null,
            start: null,
            stop: null
        },
        _create: function () {
            if (this.options.helper === 'original') {
                this._setPositionRelative();
            }
            if (this.options.addClasses) {
                this.element.addClass('ui-draggable');
            }
            if (this.options.disabled) {
                this.element.addClass('ui-draggable-disabled');
            }
            this._setHandleClassName();
            this._mouseInit();
        },
        _setOption: function (key, value) {
            this._super(key, value);
            if (key === 'handle') {
                this._removeHandleClassName();
                this._setHandleClassName();
            }
        },
        _destroy: function () {
            if ((this.helper || this.element).is('.ui-draggable-dragging')) {
                this.destroyOnClear = true;
                return;
            }
            this.element.removeClass('ui-draggable ui-draggable-dragging ui-draggable-disabled');
            this._removeHandleClassName();
            this._mouseDestroy();
        },
        _mouseCapture: function (event) {
            var o = this.options;
            this._blurActiveElement(event);
            if (this.helper || o.disabled || $(event.target).closest('.ui-resizable-handle').length > 0) {
                return false;
            }
            this.handle = this._getHandle(event);
            if (!this.handle) {
                return false;
            }
            this._blockFrames(o.iframeFix === true ? 'iframe' : o.iframeFix);
            return true;
        },
        _blockFrames: function (selector) {
            this.iframeBlocks = this.document.find(selector).map(function () {
                var iframe = $(this);
                return $('<div>').css('position', 'absolute').appendTo(iframe.parent()).outerWidth(iframe.outerWidth()).outerHeight(iframe.outerHeight()).offset(iframe.offset())[0];
            });
        },
        _unblockFrames: function () {
            if (this.iframeBlocks) {
                this.iframeBlocks.remove();
                delete this.iframeBlocks;
            }
        },
        _blurActiveElement: function (event) {
            var document = this.document[0];
            if (!this.handleElement.is(event.target)) {
                return;
            }
            try {
                if (document.activeElement && document.activeElement.nodeName.toLowerCase() !== 'body') {
                    $(document.activeElement).blur();
                }
            } catch (error) {
            }
        },
        _mouseStart: function (event) {
            var o = this.options;
            this.helper = this._createHelper(event);
            this.helper.addClass('ui-draggable-dragging');
            this._cacheHelperProportions();
            if ($.ui.ddmanager) {
                $.ui.ddmanager.current = this;
            }
            this._cacheMargins();
            this.cssPosition = this.helper.css('position');
            this.scrollParent = this.helper.scrollParent(true);
            this.offsetParent = this.helper.offsetParent();
            this.hasFixedAncestor = this.helper.parents().filter(function () {
                return $(this).css('position') === 'fixed';
            }).length > 0;
            this.positionAbs = this.element.offset();
            this._refreshOffsets(event);
            this.originalPosition = this.position = this._generatePosition(event, false);
            this.originalPageX = event.pageX;
            this.originalPageY = event.pageY;
            o.cursorAt && this._adjustOffsetFromHelper(o.cursorAt);
            this._setContainment();
            if (this._trigger('start', event) === false) {
                this._clear();
                return false;
            }
            this._cacheHelperProportions();
            if ($.ui.ddmanager && !o.dropBehaviour) {
                $.ui.ddmanager.prepareOffsets(this, event);
            }
            this._normalizeRightBottom();
            this._mouseDrag(event, true);
            if ($.ui.ddmanager) {
                $.ui.ddmanager.dragStart(this, event);
            }
            return true;
        },
        _refreshOffsets: function (event) {
            this.offset = {
                top: this.positionAbs.top - this.margins.top,
                left: this.positionAbs.left - this.margins.left,
                scroll: false,
                parent: this._getParentOffset(),
                relative: this._getRelativeOffset()
            };
            this.offset.click = {
                left: event.pageX - this.offset.left,
                top: event.pageY - this.offset.top
            };
        },
        _mouseDrag: function (event, noPropagation) {
            if (this.hasFixedAncestor) {
                this.offset.parent = this._getParentOffset();
            }
            this.position = this._generatePosition(event, true);
            this.positionAbs = this._convertPositionTo('absolute');
            if (!noPropagation) {
                var ui = this._uiHash();
                if (this._trigger('drag', event, ui) === false) {
                    this._mouseUp({});
                    return false;
                }
                this.position = ui.position;
            }
            this.helper[0].style.left = this.position.left + 'px';
            this.helper[0].style.top = this.position.top + 'px';
            if ($.ui.ddmanager) {
                $.ui.ddmanager.drag(this, event);
            }
            return false;
        },
        _mouseStop: function (event) {
            var that = this, dropped = false;
            if ($.ui.ddmanager && !this.options.dropBehaviour) {
                dropped = $.ui.ddmanager.drop(this, event);
            }
            if (this.dropped) {
                dropped = this.dropped;
                this.dropped = false;
            }
            if (this.options.revert === 'invalid' && !dropped || this.options.revert === 'valid' && dropped || this.options.revert === true || $.isFunction(this.options.revert) && this.options.revert.call(this.element, dropped)) {
                $(this.helper).animate(this.originalPosition, parseInt(this.options.revertDuration, 10), function () {
                    if (that._trigger('stop', event) !== false) {
                        that._clear();
                    }
                });
            } else {
                if (this._trigger('stop', event) !== false) {
                    this._clear();
                }
            }
            return false;
        },
        _mouseUp: function (event) {
            this._unblockFrames();
            if ($.ui.ddmanager) {
                $.ui.ddmanager.dragStop(this, event);
            }
            if (this.handleElement.is(event.target)) {
                this.element.focus();
            }
            return $.ui.mouse.prototype._mouseUp.call(this, event);
        },
        cancel: function () {
            if (this.helper.is('.ui-draggable-dragging')) {
                this._mouseUp({});
            } else {
                this._clear();
            }
            return this;
        },
        _getHandle: function (event) {
            return this.options.handle ? !!$(event.target).closest(this.element.find(this.options.handle)).length : true;
        },
        _setHandleClassName: function () {
            this.handleElement = this.options.handle ? this.element.find(this.options.handle) : this.element;
            this.handleElement.addClass('ui-draggable-handle');
        },
        _removeHandleClassName: function () {
            this.handleElement.removeClass('ui-draggable-handle');
        },
        _createHelper: function (event) {
            var o = this.options, helperIsFunction = $.isFunction(o.helper), helper = helperIsFunction ? $(o.helper.apply(this.element[0], [event])) : o.helper === 'clone' ? this.element.clone().removeAttr('id') : this.element;
            if (!helper.parents('body').length) {
                helper.appendTo(o.appendTo === 'parent' ? this.element[0].parentNode : o.appendTo);
            }
            if (helperIsFunction && helper[0] === this.element[0]) {
                this._setPositionRelative();
            }
            if (helper[0] !== this.element[0] && !/(fixed|absolute)/.test(helper.css('position'))) {
                helper.css('position', 'absolute');
            }
            return helper;
        },
        _setPositionRelative: function () {
            if (!/^(?:r|a|f)/.test(this.element.css('position'))) {
                this.element[0].style.position = 'relative';
            }
        },
        _adjustOffsetFromHelper: function (obj) {
            if (typeof obj === 'string') {
                obj = obj.split(' ');
            }
            if ($.isArray(obj)) {
                obj = {
                    left: +obj[0],
                    top: +obj[1] || 0
                };
            }
            if ('left' in obj) {
                this.offset.click.left = obj.left + this.margins.left;
            }
            if ('right' in obj) {
                this.offset.click.left = this.helperProportions.width - obj.right + this.margins.left;
            }
            if ('top' in obj) {
                this.offset.click.top = obj.top + this.margins.top;
            }
            if ('bottom' in obj) {
                this.offset.click.top = this.helperProportions.height - obj.bottom + this.margins.top;
            }
        },
        _isRootNode: function (element) {
            return /(html|body)/i.test(element.tagName) || element === this.document[0];
        },
        _getParentOffset: function () {
            var po = this.offsetParent.offset(), document = this.document[0];
            if (this.cssPosition === 'absolute' && this.scrollParent[0] !== document && $.contains(this.scrollParent[0], this.offsetParent[0])) {
                po.left += this.scrollParent.scrollLeft();
                po.top += this.scrollParent.scrollTop();
            }
            if (this._isRootNode(this.offsetParent[0])) {
                po = {
                    top: 0,
                    left: 0
                };
            }
            return {
                top: po.top + (parseInt(this.offsetParent.css('borderTopWidth'), 10) || 0),
                left: po.left + (parseInt(this.offsetParent.css('borderLeftWidth'), 10) || 0)
            };
        },
        _getRelativeOffset: function () {
            if (this.cssPosition !== 'relative') {
                return {
                    top: 0,
                    left: 0
                };
            }
            var p = this.element.position(), scrollIsRootNode = this._isRootNode(this.scrollParent[0]);
            return {
                top: p.top - (parseInt(this.helper.css('top'), 10) || 0) + (!scrollIsRootNode ? this.scrollParent.scrollTop() : 0),
                left: p.left - (parseInt(this.helper.css('left'), 10) || 0) + (!scrollIsRootNode ? this.scrollParent.scrollLeft() : 0)
            };
        },
        _cacheMargins: function () {
            this.margins = {
                left: parseInt(this.element.css('marginLeft'), 10) || 0,
                top: parseInt(this.element.css('marginTop'), 10) || 0,
                right: parseInt(this.element.css('marginRight'), 10) || 0,
                bottom: parseInt(this.element.css('marginBottom'), 10) || 0
            };
        },
        _cacheHelperProportions: function () {
            this.helperProportions = {
                width: this.helper.outerWidth(),
                height: this.helper.outerHeight()
            };
        },
        _setContainment: function () {
            var isUserScrollable, c, ce, o = this.options, document = this.document[0];
            this.relativeContainer = null;
            if (!o.containment) {
                this.containment = null;
                return;
            }
            if (o.containment === 'window') {
                this.containment = [
                    $(window).scrollLeft() - this.offset.relative.left - this.offset.parent.left,
                    $(window).scrollTop() - this.offset.relative.top - this.offset.parent.top,
                    $(window).scrollLeft() + $(window).width() - this.helperProportions.width - this.margins.left,
                    $(window).scrollTop() + ($(window).height() || document.body.parentNode.scrollHeight) - this.helperProportions.height - this.margins.top
                ];
                return;
            }
            if (o.containment === 'document') {
                this.containment = [
                    0,
                    0,
                    $(document).width() - this.helperProportions.width - this.margins.left,
                    ($(document).height() || document.body.parentNode.scrollHeight) - this.helperProportions.height - this.margins.top
                ];
                return;
            }
            if (o.containment.constructor === Array) {
                this.containment = o.containment;
                return;
            }
            if (o.containment === 'parent') {
                o.containment = this.helper[0].parentNode;
            }
            c = $(o.containment);
            ce = c[0];
            if (!ce) {
                return;
            }
            isUserScrollable = /(scroll|auto)/.test(c.css('overflow'));
            this.containment = [
                (parseInt(c.css('borderLeftWidth'), 10) || 0) + (parseInt(c.css('paddingLeft'), 10) || 0),
                (parseInt(c.css('borderTopWidth'), 10) || 0) + (parseInt(c.css('paddingTop'), 10) || 0),
                (isUserScrollable ? Math.max(ce.scrollWidth, ce.offsetWidth) : ce.offsetWidth) - (parseInt(c.css('borderRightWidth'), 10) || 0) - (parseInt(c.css('paddingRight'), 10) || 0) - this.helperProportions.width - this.margins.left - this.margins.right,
                (isUserScrollable ? Math.max(ce.scrollHeight, ce.offsetHeight) : ce.offsetHeight) - (parseInt(c.css('borderBottomWidth'), 10) || 0) - (parseInt(c.css('paddingBottom'), 10) || 0) - this.helperProportions.height - this.margins.top - this.margins.bottom
            ];
            this.relativeContainer = c;
        },
        _convertPositionTo: function (d, pos) {
            if (!pos) {
                pos = this.position;
            }
            var mod = d === 'absolute' ? 1 : -1, scrollIsRootNode = this._isRootNode(this.scrollParent[0]);
            return {
                top: pos.top + this.offset.relative.top * mod + this.offset.parent.top * mod - (this.cssPosition === 'fixed' ? -this.offset.scroll.top : scrollIsRootNode ? 0 : this.offset.scroll.top) * mod,
                left: pos.left + this.offset.relative.left * mod + this.offset.parent.left * mod - (this.cssPosition === 'fixed' ? -this.offset.scroll.left : scrollIsRootNode ? 0 : this.offset.scroll.left) * mod
            };
        },
        _generatePosition: function (event, constrainPosition) {
            var containment, co, top, left, o = this.options, scrollIsRootNode = this._isRootNode(this.scrollParent[0]), pageX = event.pageX, pageY = event.pageY;
            if (!scrollIsRootNode || !this.offset.scroll) {
                this.offset.scroll = {
                    top: this.scrollParent.scrollTop(),
                    left: this.scrollParent.scrollLeft()
                };
            }
            if (constrainPosition) {
                if (this.containment) {
                    if (this.relativeContainer) {
                        co = this.relativeContainer.offset();
                        containment = [
                            this.containment[0] + co.left,
                            this.containment[1] + co.top,
                            this.containment[2] + co.left,
                            this.containment[3] + co.top
                        ];
                    } else {
                        containment = this.containment;
                    }
                    if (event.pageX - this.offset.click.left < containment[0]) {
                        pageX = containment[0] + this.offset.click.left;
                    }
                    if (event.pageY - this.offset.click.top < containment[1]) {
                        pageY = containment[1] + this.offset.click.top;
                    }
                    if (event.pageX - this.offset.click.left > containment[2]) {
                        pageX = containment[2] + this.offset.click.left;
                    }
                    if (event.pageY - this.offset.click.top > containment[3]) {
                        pageY = containment[3] + this.offset.click.top;
                    }
                }
                if (o.grid) {
                    top = o.grid[1] ? this.originalPageY + Math.round((pageY - this.originalPageY) / o.grid[1]) * o.grid[1] : this.originalPageY;
                    pageY = containment ? top - this.offset.click.top >= containment[1] || top - this.offset.click.top > containment[3] ? top : top - this.offset.click.top >= containment[1] ? top - o.grid[1] : top + o.grid[1] : top;
                    left = o.grid[0] ? this.originalPageX + Math.round((pageX - this.originalPageX) / o.grid[0]) * o.grid[0] : this.originalPageX;
                    pageX = containment ? left - this.offset.click.left >= containment[0] || left - this.offset.click.left > containment[2] ? left : left - this.offset.click.left >= containment[0] ? left - o.grid[0] : left + o.grid[0] : left;
                }
                if (o.axis === 'y') {
                    pageX = this.originalPageX;
                }
                if (o.axis === 'x') {
                    pageY = this.originalPageY;
                }
            }
            return {
                top: pageY - this.offset.click.top - this.offset.relative.top - this.offset.parent.top + (this.cssPosition === 'fixed' ? -this.offset.scroll.top : scrollIsRootNode ? 0 : this.offset.scroll.top),
                left: pageX - this.offset.click.left - this.offset.relative.left - this.offset.parent.left + (this.cssPosition === 'fixed' ? -this.offset.scroll.left : scrollIsRootNode ? 0 : this.offset.scroll.left)
            };
        },
        _clear: function () {
            this.helper.removeClass('ui-draggable-dragging');
            if (this.helper[0] !== this.element[0] && !this.cancelHelperRemoval) {
                this.helper.remove();
            }
            this.helper = null;
            this.cancelHelperRemoval = false;
            if (this.destroyOnClear) {
                this.destroy();
            }
        },
        _normalizeRightBottom: function () {
            if (this.options.axis !== 'y' && this.helper.css('right') !== 'auto') {
                this.helper.width(this.helper.width());
                this.helper.css('right', 'auto');
            }
            if (this.options.axis !== 'x' && this.helper.css('bottom') !== 'auto') {
                this.helper.height(this.helper.height());
                this.helper.css('bottom', 'auto');
            }
        },
        _trigger: function (type, event, ui) {
            ui = ui || this._uiHash();
            $.ui.plugin.call(this, type, [
                event,
                ui,
                this
            ], true);
            if (/^(drag|start|stop)/.test(type)) {
                this.positionAbs = this._convertPositionTo('absolute');
                ui.offset = this.positionAbs;
            }
            return $.Widget.prototype._trigger.call(this, type, event, ui);
        },
        plugins: {},
        _uiHash: function () {
            return {
                helper: this.helper,
                position: this.position,
                originalPosition: this.originalPosition,
                offset: this.positionAbs
            };
        }
    });
    $.ui.plugin.add('draggable', 'connectToSortable', {
        start: function (event, ui, draggable) {
            var uiSortable = $.extend({}, ui, { item: draggable.element });
            draggable.sortables = [];
            $(draggable.options.connectToSortable).each(function () {
                var sortable = $(this).sortable('instance');
                if (sortable && !sortable.options.disabled) {
                    draggable.sortables.push(sortable);
                    sortable.refreshPositions();
                    sortable._trigger('activate', event, uiSortable);
                }
            });
        },
        stop: function (event, ui, draggable) {
            var uiSortable = $.extend({}, ui, { item: draggable.element });
            draggable.cancelHelperRemoval = false;
            $.each(draggable.sortables, function () {
                var sortable = this;
                if (sortable.isOver) {
                    sortable.isOver = 0;
                    draggable.cancelHelperRemoval = true;
                    sortable.cancelHelperRemoval = false;
                    sortable._storedCSS = {
                        position: sortable.placeholder.css('position'),
                        top: sortable.placeholder.css('top'),
                        left: sortable.placeholder.css('left')
                    };
                    sortable._mouseStop(event);
                    sortable.options.helper = sortable.options._helper;
                } else {
                    sortable.cancelHelperRemoval = true;
                    sortable._trigger('deactivate', event, uiSortable);
                }
            });
        },
        drag: function (event, ui, draggable) {
            $.each(draggable.sortables, function () {
                var innermostIntersecting = false, sortable = this;
                sortable.positionAbs = draggable.positionAbs;
                sortable.helperProportions = draggable.helperProportions;
                sortable.offset.click = draggable.offset.click;
                if (sortable._intersectsWith(sortable.containerCache)) {
                    innermostIntersecting = true;
                    $.each(draggable.sortables, function () {
                        this.positionAbs = draggable.positionAbs;
                        this.helperProportions = draggable.helperProportions;
                        this.offset.click = draggable.offset.click;
                        if (this !== sortable && this._intersectsWith(this.containerCache) && $.contains(sortable.element[0], this.element[0])) {
                            innermostIntersecting = false;
                        }
                        return innermostIntersecting;
                    });
                }
                if (innermostIntersecting) {
                    if (!sortable.isOver) {
                        sortable.isOver = 1;
                        draggable._parent = ui.helper.parent();
                        sortable.currentItem = ui.helper.appendTo(sortable.element).data('ui-sortable-item', true);
                        sortable.options._helper = sortable.options.helper;
                        sortable.options.helper = function () {
                            return ui.helper[0];
                        };
                        event.target = sortable.currentItem[0];
                        sortable._mouseCapture(event, true);
                        sortable._mouseStart(event, true, true);
                        sortable.offset.click.top = draggable.offset.click.top;
                        sortable.offset.click.left = draggable.offset.click.left;
                        sortable.offset.parent.left -= draggable.offset.parent.left - sortable.offset.parent.left;
                        sortable.offset.parent.top -= draggable.offset.parent.top - sortable.offset.parent.top;
                        draggable._trigger('toSortable', event);
                        draggable.dropped = sortable.element;
                        $.each(draggable.sortables, function () {
                            this.refreshPositions();
                        });
                        draggable.currentItem = draggable.element;
                        sortable.fromOutside = draggable;
                    }
                    if (sortable.currentItem) {
                        sortable._mouseDrag(event);
                        ui.position = sortable.position;
                    }
                } else {
                    if (sortable.isOver) {
                        sortable.isOver = 0;
                        sortable.cancelHelperRemoval = true;
                        sortable.options._revert = sortable.options.revert;
                        sortable.options.revert = false;
                        sortable._trigger('out', event, sortable._uiHash(sortable));
                        sortable._mouseStop(event, true);
                        sortable.options.revert = sortable.options._revert;
                        sortable.options.helper = sortable.options._helper;
                        if (sortable.placeholder) {
                            sortable.placeholder.remove();
                        }
                        ui.helper.appendTo(draggable._parent);
                        draggable._refreshOffsets(event);
                        ui.position = draggable._generatePosition(event, true);
                        draggable._trigger('fromSortable', event);
                        draggable.dropped = false;
                        $.each(draggable.sortables, function () {
                            this.refreshPositions();
                        });
                    }
                }
            });
        }
    });
    $.ui.plugin.add('draggable', 'cursor', {
        start: function (event, ui, instance) {
            var t = $('body'), o = instance.options;
            if (t.css('cursor')) {
                o._cursor = t.css('cursor');
            }
            t.css('cursor', o.cursor);
        },
        stop: function (event, ui, instance) {
            var o = instance.options;
            if (o._cursor) {
                $('body').css('cursor', o._cursor);
            }
        }
    });
    $.ui.plugin.add('draggable', 'opacity', {
        start: function (event, ui, instance) {
            var t = $(ui.helper), o = instance.options;
            if (t.css('opacity')) {
                o._opacity = t.css('opacity');
            }
            t.css('opacity', o.opacity);
        },
        stop: function (event, ui, instance) {
            var o = instance.options;
            if (o._opacity) {
                $(ui.helper).css('opacity', o._opacity);
            }
        }
    });
    $.ui.plugin.add('draggable', 'scroll', {
        start: function (event, ui, i) {
            if (!i.scrollParentNotHidden) {
                i.scrollParentNotHidden = i.helper.scrollParent(false);
            }
            if (i.scrollParentNotHidden[0] !== i.document[0] && i.scrollParentNotHidden[0].tagName !== 'HTML') {
                i.overflowOffset = i.scrollParentNotHidden.offset();
            }
        },
        drag: function (event, ui, i) {
            var o = i.options, scrolled = false, scrollParent = i.scrollParentNotHidden[0], document = i.document[0];
            if (scrollParent !== document && scrollParent.tagName !== 'HTML') {
                if (!o.axis || o.axis !== 'x') {
                    if (i.overflowOffset.top + scrollParent.offsetHeight - event.pageY < o.scrollSensitivity) {
                        scrollParent.scrollTop = scrolled = scrollParent.scrollTop + o.scrollSpeed;
                    } else if (event.pageY - i.overflowOffset.top < o.scrollSensitivity) {
                        scrollParent.scrollTop = scrolled = scrollParent.scrollTop - o.scrollSpeed;
                    }
                }
                if (!o.axis || o.axis !== 'y') {
                    if (i.overflowOffset.left + scrollParent.offsetWidth - event.pageX < o.scrollSensitivity) {
                        scrollParent.scrollLeft = scrolled = scrollParent.scrollLeft + o.scrollSpeed;
                    } else if (event.pageX - i.overflowOffset.left < o.scrollSensitivity) {
                        scrollParent.scrollLeft = scrolled = scrollParent.scrollLeft - o.scrollSpeed;
                    }
                }
            } else {
                if (!o.axis || o.axis !== 'x') {
                    if (event.pageY - $(document).scrollTop() < o.scrollSensitivity) {
                        scrolled = $(document).scrollTop($(document).scrollTop() - o.scrollSpeed);
                    } else if ($(window).height() - (event.pageY - $(document).scrollTop()) < o.scrollSensitivity) {
                        scrolled = $(document).scrollTop($(document).scrollTop() + o.scrollSpeed);
                    }
                }
                if (!o.axis || o.axis !== 'y') {
                    if (event.pageX - $(document).scrollLeft() < o.scrollSensitivity) {
                        scrolled = $(document).scrollLeft($(document).scrollLeft() - o.scrollSpeed);
                    } else if ($(window).width() - (event.pageX - $(document).scrollLeft()) < o.scrollSensitivity) {
                        scrolled = $(document).scrollLeft($(document).scrollLeft() + o.scrollSpeed);
                    }
                }
            }
            if (scrolled !== false && $.ui.ddmanager && !o.dropBehaviour) {
                $.ui.ddmanager.prepareOffsets(i, event);
            }
        }
    });
    $.ui.plugin.add('draggable', 'snap', {
        start: function (event, ui, i) {
            var o = i.options;
            i.snapElements = [];
            $(o.snap.constructor !== String ? o.snap.items || ':data(ui-draggable)' : o.snap).each(function () {
                var $t = $(this), $o = $t.offset();
                if (this !== i.element[0]) {
                    i.snapElements.push({
                        item: this,
                        width: $t.outerWidth(),
                        height: $t.outerHeight(),
                        top: $o.top,
                        left: $o.left
                    });
                }
            });
        },
        drag: function (event, ui, inst) {
            var ts, bs, ls, rs, l, r, t, b, i, first, o = inst.options, d = o.snapTolerance, x1 = ui.offset.left, x2 = x1 + inst.helperProportions.width, y1 = ui.offset.top, y2 = y1 + inst.helperProportions.height;
            for (i = inst.snapElements.length - 1; i >= 0; i--) {
                l = inst.snapElements[i].left - inst.margins.left;
                r = l + inst.snapElements[i].width;
                t = inst.snapElements[i].top - inst.margins.top;
                b = t + inst.snapElements[i].height;
                if (x2 < l - d || x1 > r + d || y2 < t - d || y1 > b + d || !$.contains(inst.snapElements[i].item.ownerDocument, inst.snapElements[i].item)) {
                    if (inst.snapElements[i].snapping) {
                        inst.options.snap.release && inst.options.snap.release.call(inst.element, event, $.extend(inst._uiHash(), { snapItem: inst.snapElements[i].item }));
                    }
                    inst.snapElements[i].snapping = false;
                    continue;
                }
                if (o.snapMode !== 'inner') {
                    ts = Math.abs(t - y2) <= d;
                    bs = Math.abs(b - y1) <= d;
                    ls = Math.abs(l - x2) <= d;
                    rs = Math.abs(r - x1) <= d;
                    if (ts) {
                        ui.position.top = inst._convertPositionTo('relative', {
                            top: t - inst.helperProportions.height,
                            left: 0
                        }).top;
                    }
                    if (bs) {
                        ui.position.top = inst._convertPositionTo('relative', {
                            top: b,
                            left: 0
                        }).top;
                    }
                    if (ls) {
                        ui.position.left = inst._convertPositionTo('relative', {
                            top: 0,
                            left: l - inst.helperProportions.width
                        }).left;
                    }
                    if (rs) {
                        ui.position.left = inst._convertPositionTo('relative', {
                            top: 0,
                            left: r
                        }).left;
                    }
                }
                first = ts || bs || ls || rs;
                if (o.snapMode !== 'outer') {
                    ts = Math.abs(t - y1) <= d;
                    bs = Math.abs(b - y2) <= d;
                    ls = Math.abs(l - x1) <= d;
                    rs = Math.abs(r - x2) <= d;
                    if (ts) {
                        ui.position.top = inst._convertPositionTo('relative', {
                            top: t,
                            left: 0
                        }).top;
                    }
                    if (bs) {
                        ui.position.top = inst._convertPositionTo('relative', {
                            top: b - inst.helperProportions.height,
                            left: 0
                        }).top;
                    }
                    if (ls) {
                        ui.position.left = inst._convertPositionTo('relative', {
                            top: 0,
                            left: l
                        }).left;
                    }
                    if (rs) {
                        ui.position.left = inst._convertPositionTo('relative', {
                            top: 0,
                            left: r - inst.helperProportions.width
                        }).left;
                    }
                }
                if (!inst.snapElements[i].snapping && (ts || bs || ls || rs || first)) {
                    inst.options.snap.snap && inst.options.snap.snap.call(inst.element, event, $.extend(inst._uiHash(), { snapItem: inst.snapElements[i].item }));
                }
                inst.snapElements[i].snapping = ts || bs || ls || rs || first;
            }
        }
    });
    $.ui.plugin.add('draggable', 'stack', {
        start: function (event, ui, instance) {
            var min, o = instance.options, group = $.makeArray($(o.stack)).sort(function (a, b) {
                    return (parseInt($(a).css('zIndex'), 10) || 0) - (parseInt($(b).css('zIndex'), 10) || 0);
                });
            if (!group.length) {
                return;
            }
            min = parseInt($(group[0]).css('zIndex'), 10) || 0;
            $(group).each(function (i) {
                $(this).css('zIndex', min + i);
            });
            this.css('zIndex', min + group.length);
        }
    });
    $.ui.plugin.add('draggable', 'zIndex', {
        start: function (event, ui, instance) {
            var t = $(ui.helper), o = instance.options;
            if (t.css('zIndex')) {
                o._zIndex = t.css('zIndex');
            }
            t.css('zIndex', o.zIndex);
        },
        stop: function (event, ui, instance) {
            var o = instance.options;
            if (o._zIndex) {
                $(ui.helper).css('zIndex', o._zIndex);
            }
        }
    });
    return $.ui.draggable;
}));
define('comsys/base/Window', [
    'jquery',
    'Class',
    'TPLEngine',
    'comsys/base/Base',
    'comsys/layout/MaskLayer',
    'libs/jquery-ui/ui/draggable',
    'common/setting'
], function ($, Class, TPLEngine, Base, MaskLayer, draggable, CommonSetting) {
    var ClassName = 'Control.Window';
    var layer = new MaskLayer(CommonSetting.layerSetting);
    var Window = Class(ClassName, {
        constructor: function (args) {
            this.callParent(args);
            this.$BoxBaseEl = $(TPLEngine.render(this.TPL.main, this));
            this.$BoxBaseAppend = $(this.setting.append || document.body);
            this.$BoxBaseHead = this.$BoxBaseEl.find('.comsys-box-head');
            this.$BoxBaseTitle = this.$BoxBaseEl.find('.comsys-box-title');
            this.$BoxBaseClose = this.$BoxBaseEl.find('.comsys-box-close');
            this.$BoxBaseContent = this.$BoxBaseEl.find('.comsys-box-content');
            this.$BoxBaseFrame = this.$BoxBaseEl.find('iframe');
            this.windowLoadType = null;
            this.deferred = new $.Deferred();
            this.setting.titleHeight = 45;
            this.setting.borderWidth = 0;
            this.setting.callback = function () {
            };
            this.status = false;
            this.setting.dragoption = {
                cancel: '.comsys-box-content,iframe',
                containment: 'window',
                addClasses: false,
                iframeFix: this.$BoxBaseFrame,
                scroll: true,
                drag: function (event, ui) {
                    if (ui.position.top < 0) {
                        ui.helper.css({ top: 0 });
                        return false;
                    }
                }
            };
        },
        TPL: { main: '<div id=\'<%=this.classids%>\' class=\'comsys-box-base\'>' + '<div class=\'comsys-box-head\'>' + '<div class=\'comsys-box-title\'>标题处</div>' + '<div class=\'comsys-box-close\'></div>' + '</div>' + '<iframe src=\'about:blank\' width=\'100%\' height=\'100%\' marginheight=\'0\' marginwidth=\'0\' scrolling=\'auto\' frameborder=\'0\' style=\'width: 100%; height: 100%; border: 0px;\'></iframe>' + '<div class=\'comsys-box-content\'></div>' + '</div>' },
        initialize: function () {
            var me = this;
            this.$BoxBaseEl.addClass('comsys-box-window');
            this.$BoxBaseClose.off('.BoxBaseCloseHandler').on('click.BoxBaseCloseHandler', function () {
                return me.close.call(me);
            });
            this.$BoxBaseHead.get(0).onselectstart = function () {
                return false;
            };
            this.addMoveBehavior();
            this.deferred.promise(this);
            return this;
        },
        addMoveBehavior: function () {
            this.drapObject = draggable(this.setting.dragoption, this.$BoxBaseEl);
        },
        removeMoveBehavior: function () {
            this.drapObject.destroy();
        },
        WindowLoadType: {
            'iframe': 'iframe',
            'content': 'content',
            'ajax': 'ajax'
        },
        show: function (setting) {
            this.status = true;
            this.deferred = new $.Deferred();
            this.deferred.promise(this);
            var me = this;
            setting = setting || {};
            setting.title = setting.title || '';
            setting.content = setting.content || '';
            setting.src = setting.src || '';
            setting.ajax = typeof setting.ajax === 'boolean' && setting.ajax === true ? true : false;
            setting.width = setting.width || 800;
            setting.height = setting.height || 600;
            setting.callback = setting.callback || function () {
            };
            setting.maxHeight = setting.maxHeight || null;
            this.then(function () {
                setting.callback.apply(me, arguments);
            });
            if (!document.getElementById(this.classids)) {
                this.$BoxBaseAppend.append(this.$BoxBaseEl);
            }
            var $win = $(window);
            var gh = $win.height();
            var gw = $win.width();
            setting.width = gw > setting.width ? setting.width : gw * 0.99;
            setting.height = gh > setting.height ? setting.height : gh * 0.99;
            var top = (gh - setting.height) / 2 - (gh - setting.height) / 2 * 2 / 5;
            this.$BoxBaseEl.css({
                position: 'fixed',
                width: setting.width,
                height: 'auto',
                left: (gw - setting.width) / 2,
                top: top < 0 ? 0 : top
            }).hide();
            this.resize(setting.height, setting.maxHeight);
            this.$BoxBaseTitle.html(setting.title);
            this.$BoxBaseContent.empty();
            if (setting.content) {
                this.windowLoadType = this.WindowLoadType.content;
                this.$BoxBaseFrame.hide();
                if (setting.content.jquery && setting.content.jquery == $('head').jquery)
                    setting.content.show();
                this.$BoxBaseContent.append(setting.content).show();
            } else {
                if (setting.src) {
                    if (setting.ajax) {
                        this.$BoxBaseFrame.hide();
                        $.ajax({
                            url: setting.src,
                            success: function (html) {
                                me.$BoxBaseContent.append(html).show();
                            }
                        });
                        this.windowLoadType = this.WindowLoadType.ajax;
                    } else {
                        this.$BoxBaseContent.hide();
                        this.$BoxBaseFrame.attr('src', setting.src).show();
                        this.windowLoadType = this.WindowLoadType.iframe;
                    }
                } else {
                    return;
                }
            }
            this.$BoxBaseEl.fadeIn();
            layer.mask(function (e) {
                me.$BoxBaseContent.animate({ scrollTop: me.$BoxBaseContent.scrollTop() - e.wheelDelta });
                return false;
            });
            return this;
        },
        close: function (command) {
            this.$BoxBaseEl.hide();
            var cmd = command;
            this.$BoxBaseFrame.attr('src', 'about:blank');
            layer.hide();
            if (command instanceof Function) {
                this.then(function () {
                    command.apply(null, arguments);
                });
                cmd = 'close';
            }
            this.status = false;
            this.deferred.resolve(cmd || 'close');
        },
        resize: function (height, maxHeight) {
            height = height || this.$BoxBaseEl.height();
            var ch = height - this.setting.titleHeight;
            this.$BoxBaseContent.css({
                height: 'auto',
                minHeight: ch + 'px'
            });
            if (maxHeight && maxHeight >= height)
                this.$BoxBaseContent.css({ maxHeight: maxHeight - this.setting.titleHeight + 'px' });
            this.$BoxBaseFrame.css({ height: ch });
        },
        destory: function () {
            this.drapObject.destroy();
            this.$BoxBaseClose.off('.BoxBaseCloseHandler');
            this.$BoxBaseEl.remove();
        }
    }, Base);
    return Window;
});
define('comsys/base/Dialog', [
    'jquery',
    'Class',
    'TPLEngine',
    'comsys/base/Window'
], function ($, Class, TPLEngine, Window) {
    var ClassName = 'Control.Dialog';
    var Dialog = Class(ClassName, {
        constructor: function (args) {
            this.callParent(args);
            this.setting.dragoption.cancel = '.comsys-box-content,.comsys-box-buttons,iframe';
        },
        initialize: function () {
            var me = this;
            this.callParent();
            this.$BoxBaseEl.addClass('comsys-box-dialog');
            this.$BoxBaseButtons = $('<div class=\'comsys-box-buttons\'></div>');
            this.$BoxBaseEl.append(this.$BoxBaseButtons);
            this.$BoxBaseButtons.on('click.buttonsClikHanler', 'div', function () {
                return me.OnButtonsClikHanler.apply(me, Array.prototype.slice.call(arguments, 0).concat($(this)));
            });
            return this;
        },
        DialogTPL: { button: '<%if(this.length==0)return \'\';%>' + '<%for(var i=0;i<this.length;i++){%>' + '<div class=\'comsys-box-button\' command=\'<%=this[i].command%>\'><%=this[i].text%></div>' + '<%}%>' },
        OnButtonsClikHanler: function (e, $button) {
            var command = $button.attr('command') || 'uncommand';
            this.close(command);
        },
        show: function (setting) {
            this.setting.buttons = (setting || { buttons: [] }).buttons || [];
            this.callParent.call(this, setting);
            this.$BoxBaseContent.removeAttr('class');
            this.$BoxBaseContent.addClass('comsys-box-content ' + (setting.icon || 'info'));
            return this;
        },
        resize: function (height) {
            height = height || this.$BoxBaseEl.height();
            var buttonString = TPLEngine.render(this.DialogTPL.button, this.setting.buttons);
            if (buttonString) {
                height -= this.setting.titleHeight + this.setting.borderWidth;
                this.$BoxBaseButtons.html(buttonString).show();
            } else {
                this.$BoxBaseButtons.empty().hide();
            }
            var ch = height - this.setting.titleHeight;
            this.$BoxBaseContent.css({ minHeight: ch });
            this.$BoxBaseFrame.css({ height: ch });
        },
        destory: function () {
            this.$BoxBaseButtons.off('click.buttonsClikHanler');
            this.callParent();
        }
    }, Window);
    return Dialog;
});
define('common/client/Bumper', [], function () {
    var BumperCore = function () {
        this.timer = null;
    };
    BumperCore.prototype = {
        constructor: BumperCore,
        trigger: function (fn, interval) {
            interval = interval || 500;
            window.clearTimeout(this.timer);
            this.timer = window.setTimeout(fn, interval);
        },
        clear: function () {
            window.clearTimeout(this.timer);
        }
    };
    Bumper = {
        instance: null,
        create: function () {
            return new BumperCore();
        },
        trigger: function (fn, interval) {
            if (!this.instance)
                this.instance = new BumperCore();
            this.instance.trigger(fn, interval);
        }
    };
    return Bumper;
});
define('comsys/base/ResizeWindow', [
    'jquery',
    'Class',
    'common/client/Bumper',
    'comsys/base/Window'
], function ($, Class, Bumper, Window) {
    var ClassName = 'Control.ResizeWindow';
    var ResizeWindow = Class(ClassName, {
        constructor: function (args) {
            this.callParent(args);
            this.windowState = this.WindowStatus.Normal;
        },
        WindowStatus: {
            Full: 'Full',
            Normal: 'Normal'
        },
        initialize: function () {
            var me = this;
            this.callParent();
            this.$BoxBaseEl.addClass('comsys-box-resize-window');
            this.$BoxBaseFull = $('<div class="comsys-box-full"></div>');
            this.$BoxBaseNormal = $('<div class="comsys-box-normal"></div>');
            this.$BoxBaseClose.before(this.$BoxBaseFull);
            this.$BoxBaseClose.before(this.$BoxBaseNormal);
            this.$BoxBaseFull.off('.BoxBaseFullHandler').on('click.BoxBaseFullHandler', function () {
                return me.BoxBaseFullHandler.apply(me, arguments);
            });
            this.$BoxBaseNormal.off('.BoxBaseNormalHandler').on('click.BoxBaseNormalHandler', function () {
                return me.BoxBaseNormalHandler.apply(me, arguments);
            });
            this.$BoxBaseTitle.off('.BoxBaseTitleDoubleClick').on('dblclick.BoxBaseTitleDoubleClick', function () {
                return me.BoxBaseTitleDoubleClick.apply(me, arguments);
            });
            return this;
        },
        BindResize: function () {
            var me = this;
            $(window).on('resize.ResizeWindowResize', function () {
                Bumper.trigger(function () {
                    me.WindowResizeHandler();
                }, 500);
            });
        },
        UnBindResize: function () {
            $(window).off('resize.ResizeWindowResize');
        },
        WindowResizeHandler: function () {
            this.BoxBaseFullHandler(null, true);
        },
        CachePosition: null,
        BoxBaseTitleDoubleClick: function (e) {
            var me = this;
            if (me.windowState == me.WindowStatus.Normal) {
                me.$BoxBaseFull.trigger('click.BoxBaseFullHandler');
            } else {
                me.$BoxBaseNormal.trigger('click.BoxBaseNormalHandler');
            }
        },
        BoxBaseFullHandler: function (e, state) {
            var me = this;
            if (!state) {
                this.CachePosition = {
                    width: this.$BoxBaseEl.css('width'),
                    height: this.$BoxBaseEl.height(),
                    left: this.$BoxBaseEl.css('left'),
                    top: this.$BoxBaseEl.css('top')
                };
            }
            var $win = $(window);
            var gh = $win.height();
            var ch = gh * 0.99 - this.setting.titleHeight;
            if (state) {
                this.$BoxBaseEl.css({
                    width: '99%',
                    height: '99%',
                    top: '0.5%',
                    left: '0.5%'
                });
                this.$BoxBaseFull.hide();
                this.$BoxBaseNormal.show();
                this.removeMoveBehavior();
                me.windowState = me.WindowStatus.Full;
                if (this.windowLoadType == this.WindowLoadType.iframe) {
                    this.$BoxBaseFrame.css({ height: ch });
                } else
                    this.$BoxBaseContent.css({ height: ch });
            } else {
                this.$BoxBaseEl.animate({
                    width: '99%',
                    height: '99%',
                    top: '0.5%',
                    left: '0.5%'
                }, 'fast', function () {
                    me.$BoxBaseFull.hide();
                    me.$BoxBaseNormal.show();
                    me.removeMoveBehavior();
                    me.windowState = me.WindowStatus.Full;
                });
                if (this.windowLoadType == this.WindowLoadType.iframe) {
                    this.$BoxBaseFrame.animate({ height: ch }, 'fast');
                } else
                    this.$BoxBaseContent.animate({ height: ch }, 'fast');
            }
            this.BindResize();
        },
        BoxBaseNormalHandler: function () {
            var me = this;
            var cache = this.CachePosition;
            if (!cache) {
                var $win = $(window);
                var gh = $win.height();
                var gw = $win.width();
                var top = (gh - me.fullsetting.height) / 2 - (gh - me.fullsetting.height) / 2 * 2 / 5;
                cache = this.CachePosition = {
                    width: me.fullsetting.width,
                    height: me.fullsetting.height,
                    left: (gw - me.fullsetting.width) / 2,
                    top: top < 0 ? 0 : top
                };
            }
            this.$BoxBaseEl.animate(cache, 'fast', function () {
                me.$BoxBaseEl.css({ height: 'auto' });
                me.$BoxBaseFull.show();
                me.$BoxBaseNormal.hide();
                me.addMoveBehavior();
                me.resize(me.fullsetting.height || 600);
                me.windowState = me.WindowStatus.Normal;
                me.UnBindResize();
            });
        },
        show: function (setting) {
            var me = this;
            var $win = $(window);
            var gh = $win.height();
            var gw = $win.width();
            if (gh < setting.height || gw < setting.width)
                setting.full = true;
            this.callParent.call(this, setting);
            me.fullsetting = setting;
            if (setting.full || setting.alwaysfull) {
                this.BoxBaseFullHandler(null, true);
                this.BindResize();
            } else {
                me.$BoxBaseFull.show();
                me.$BoxBaseNormal.hide();
            }
            return this;
        },
        close: function () {
            this.callParent.apply(this, arguments);
            this.UnBindResize();
        },
        destory: function () {
            this.$BoxBaseFull.off('.BoxBaseFullHandler');
            this.$BoxBaseNormal.off('.BoxBaseNormalHandler');
            this.$BoxBaseTitle.off('.BoxBaseTitleDoubleClick');
            this.UnBindResize();
            this.callParent();
        }
    }, Window);
    return ResizeWindow;
});
define('comsys/widget/Window', [
    'comsys/base/Window',
    'comsys/base/Dialog',
    'comsys/base/ResizeWindow',
    'common/client/Bumper'
], function (w, d, rw, Bumper) {
    var bumper = Bumper.create();
    var Win = {
        type: {
            dialog: 'dialog',
            window: 'window',
            resizewindow: 'resizewindow'
        },
        button: {
            'OK': [{
                    text: '确认',
                    command: 'sure'
                }],
            'OKANDCANCEL': [
                {
                    text: '确认',
                    command: 'sure'
                },
                {
                    text: '取消',
                    command: 'cancel'
                }
            ]
        },
        icon: {
            info: 'info',
            error: 'error',
            question: 'question',
            talk: 'talk'
        },
        _dialog: d,
        _window: w,
        _resizewindow: rw,
        dialog: [],
        window: [],
        resizewindow: [],
        clear: function (type, name) {
            if (type === undefined) {
                this.clearItem(this.type.window, name);
                this.clearItem(this.type.resizewindow, name);
            } else {
                this.clearItem(type, name);
            }
        },
        clearItem: function (type, name) {
            var _w = this[type];
            this[type] = $.grep(_w, function (n, i) {
                if (name === undefined) {
                    if (i === 0)
                        return true;
                    if (!n.window.status) {
                        n.window.destory();
                        return false;
                    } else
                        return true;
                } else {
                    if (i === 0)
                        return true;
                    if (n.name === name) {
                        n.window.destory();
                        return false;
                    }
                    return true;
                }
            });
        },
        close: function (type, name, command) {
            var hasClose = false;
            if (type === undefined) {
                hasClose = this.closeItem(this.type.window, name, command);
                hasClose = this.closeItem(this.type.resizewindow, name, command);
            } else {
                hasClose = this.closeItem(type, name, command);
            }
            return hasClose;
        },
        closeItem: function (type, name, command) {
            var hasItem = false;
            var _w = this[type];
            $.each(_w, function () {
                if (name === undefined) {
                    this.window.close(command);
                    hasItem = true;
                } else {
                    if (this.name === name) {
                        this.window.close(command);
                        hasItem = true;
                    }
                }
            });
            return hasItem;
        },
        create: function (type, name) {
            name = name || 'unname';
            var _w = this[type];
            if (_w.length == 0 || _w.length != 0 && _w[0].window.status)
                _w.push({
                    name: name,
                    window: new this['_' + type]().initialize()
                });
            return _w[_w.length - 1].window;
        },
        show: function () {
            var setting, name = '', type;
            if (arguments.length == 3) {
                name = arguments[0];
                setting = arguments[1];
                type = arguments[2];
            } else if (arguments.length == 2) {
                setting = arguments[0];
                type = arguments[1];
            } else if (arguments.length == 1) {
                setting = arguments[0];
                type = Win.type.dialog;
            } else
                return;
            var _win;
            setting = setting || {};
            setting.type = type;
            setting.buttons = setting.buttons || Win.button.OK;
            switch (setting.type) {
            case this.type.dialog:
                setting.title = setting.title || '消息';
                setting.content = setting.content || '';
                setting.ajax = false;
                setting.width = setting.width || 300;
                setting.height = setting.height || 130;
                setting.callback = setting.callback;
                setting.icon = setting.icon || this.icon.info;
                setting.buttons = setting.buttons || this.button.OK;
                break;
            case this.type.resizewindow:
                setting.full = typeof setting.full == 'boolean' ? setting.full : false;
            case this.type.window:
                setting.title = setting.title || '';
                setting.src = setting.src || '';
                setting.ajax = typeof setting.ajax === 'boolean' && setting.ajax === true ? true : false;
                setting.width = setting.width || 800;
                setting.height = setting.height || 600;
                setting.content = setting.content || '';
                setting.callback = setting.callback;
                setting.maxHeight = setting.maxHeight || null;
                break;
            }
            _win = this.create(setting.type, name);
            _win.show(setting);
            _win.then(function (_type_) {
                return function (state) {
                    bumper.trigger(function () {
                        Win.clear(_type_, undefined, false);
                    });
                    return state;
                };
            }(setting.type));
            return _win;
        }
    };
    return Win;
});
define('common/client/XImage', [], function () {
    function XImage(src, w, h, loaded, errored, onbeforeloaded, onbeforeerrored) {
        var me = this;
        me.w = w || 0;
        me.h = h || 0;
        me.onloaded = loaded || function () {
        }, me.onerrored = errored || function () {
        }, me.onbeforeloaded = onbeforeloaded || function () {
        }, me.onbeforeerrored = onbeforeerrored || function () {
        }, me.t = new Image();
        this.re = new Image();
        this.re.csid = (Math.random() * 10000000000).toFixed(0);
        this.re.src = this.loadingImageCode;
        me.t.onload = function () {
            me.onbeforeloaded();
            me.onload();
            me.onloaded();
        };
        this.t.onerror = function () {
            me.onbeforeerrored();
            me.onerror();
            me.onerrored();
        };
        me.t.src = src;
        return this.re;
    }
    ;
    XImage.prototype = {
        constructor: XImage,
        loadingImageCode: 'data:image/gif;base64,R0lGODlhEAAQAPYAAOfn5xhFjMPL15CiwGWBrkttok5vo3GLs5urxcvR2p2txjRbmDhemT5inENnn0psoW2Isa+7zi5WlXSNtNfa39nc4LXA0YecvFh3p2SArbK9z8HJ1kZpoClTk4mdvaGwyGJ/rHyTt8/U3ISZuyJNkGyGsJanw2qFr6u4zFBwpCBLj6e1ypGkwSpTkxxIjdTX3t3f4nmRtoOZu9/h44GXuqCvx+Pk5eXl5rO+0LvF0+Hi5MXM2KWzytvd4cLJ1tHW3czR2r/I1bnD0rC7zs3T28fO2N3f4snP2XqRtqm3y6i1ylV1p1p4qGB9q2eDrk1vo0hqoLfB0XePtUBkndXZ3zpfmoufvl99qzthmzBXlpmqxFZ1pyZQkoabvGiDrkJlnrrD0r3G1NPX3q26zX6UuI6hv5ipw117qoyfvlRzplJypTJZl56txiROkSBLj6OyyRpGjJWnwzZcmShRkkRnn3aOtTxhmx5JjnKLszFZl1x6qW+Jsn+WuQAAAAAAAAAAACH/C05FVFNDQVBFMi4wAwEAAAAh/hpDcmVhdGVkIHdpdGggYWpheGxvYWQuaW5mbwAh+QQJCgAAACwAAAAAEAAQAAAHjYAAgoOEhYUbIykthoUIHCQqLoI2OjeFCgsdJSsvgjcwPTaDAgYSHoY2FBSWAAMLE4wAPT89ggQMEbEzQD+CBQ0UsQA7RYIGDhWxN0E+ggcPFrEUQjuCCAYXsT5DRIIJEBgfhjsrFkaDERkgJhswMwk4CDzdhBohJwcxNB4sPAmMIlCwkOGhRo5gwhIGAgAh+QQJCgAAACwAAAAAEAAQAAAHjIAAgoOEhYU7A1dYDFtdG4YAPBhVC1ktXCRfJoVKT1NIERRUSl4qXIRHBFCbhTKFCgYjkII3g0hLUbMAOjaCBEw9ukZGgidNxLMUFYIXTkGzOmLLAEkQCLNUQMEAPxdSGoYvAkS9gjkyNEkJOjovRWAb04NBJlYsWh9KQ2FUkFQ5SWqsEJIAhq6DAAIBACH5BAkKAAAALAAAAAAQABAAAAeJgACCg4SFhQkKE2kGXiwChgBDB0sGDw4NDGpshTheZ2hRFRVDUmsMCIMiZE48hmgtUBuCYxBmkAAQbV2CLBM+t0puaoIySDC3VC4tgh40M7eFNRdH0IRgZUO3NjqDFB9mv4U6Pc+DRzUfQVQ3NzAULxU2hUBDKENCQTtAL9yGRgkbcvggEq9atUAAIfkECQoAAAAsAAAAABAAEAAAB4+AAIKDhIWFPygeEE4hbEeGADkXBycZZ1tqTkqFQSNIbBtGPUJdD088g1QmMjiGZl9MO4I5ViiQAEgMA4JKLAm3EWtXgmxmOrcUElWCb2zHkFQdcoIWPGK3Sm1LgkcoPrdOKiOCRmA4IpBwDUGDL2A5IjCCN/QAcYUURQIJIlQ9MzZu6aAgRgwFGAFvKRwUCAAh+QQJCgAAACwAAAAAEAAQAAAHjIAAgoOEhYUUYW9lHiYRP4YACStxZRc0SBMyFoVEPAoWQDMzAgolEBqDRjg8O4ZKIBNAgkBjG5AAZVtsgj44VLdCanWCYUI3txUPS7xBx5AVDgazAjC3Q3ZeghUJv5B1cgOCNmI/1YUeWSkCgzNUFDODKydzCwqFNkYwOoIubnQIt244MzDC1q2DggIBACH5BAkKAAAALAAAAAAQABAAAAeJgACCg4SFhTBAOSgrEUEUhgBUQThjSh8IcQo+hRUbYEdUNjoiGlZWQYM2QD4vhkI0ZWKCPQmtkG9SEYJURDOQAD4HaLuyv0ZeB4IVj8ZNJ4IwRje/QkxkgjYz05BdamyDN9uFJg9OR4YEK1RUYzFTT0qGdnduXC1Zchg8kEEjaQsMzpTZ8avgoEAAIfkECQoAAAAsAAAAABAAEAAAB4iAAIKDhIWFNz0/Oz47IjCGADpURAkCQUI4USKFNhUvFTMANxU7KElAhDA9OoZHH0oVgjczrJBRZkGyNpCCRCw8vIUzHmXBhDM0HoIGLsCQAjEmgjIqXrxaBxGCGw5cF4Y8TnybglprLXhjFBUWVnpeOIUIT3lydg4PantDz2UZDwYOIEhgzFggACH5BAkKAAAALAAAAAAQABAAAAeLgACCg4SFhjc6RhUVRjaGgzYzRhRiREQ9hSaGOhRFOxSDQQ0uj1RBPjOCIypOjwAJFkSCSyQrrhRDOYILXFSuNkpjggwtvo86H7YAZ1korkRaEYJlC3WuESxBggJLWHGGFhcIxgBvUHQyUT1GQWwhFxuFKyBPakxNXgceYY9HCDEZTlxA8cOVwUGBAAA7AAAAAAAAAAAA',
        errorImageCode: 'data:image/gif;base64,R0lGODlhUAAZAPIHAL+/v8fHx+Pj4+jo6Ovr6/n5+f7+/v///yH5BAAAAAAALAAAAABQABkAAAPWeLrc/jDKSau9OOvNu/9gKI7kUghBGghF6VKDKgeEBFS3cucOb18EmUJWg/gegGTykPM1e8pnpTAbylpIRrTBO+q+3MXugpqZBdCtNMpeittippw9MVuF2Tl4Lw/zvztdFHYHhD2AYHBjfF5ji14NVFWFk4d6fZeZflp6UhKEhn6Pb0qZbXSOfZANZSp3KSx5o5xxWUepixOSrpQqWJuzpIi0mLV/EjG8REZxW0ylgE6bl7kUQWY0zM+JorVuXLnf37qtK78v6Lrp6+zt7u/w8fLz9PULCQA7',
        resize: function () {
            var me = this, img = me.t, ratio = 1, w = img.width, h = img.height, maxWidth = me.w, maxHeight = me.h, wRatio = maxWidth / w, hRatio = maxHeight / h;
            if (maxWidth == 0 && maxHeight == 0) {
                ratio = 1;
            } else if (maxWidth == 0) {
                if (hRatio < 1)
                    ratio = hRatio;
            } else if (maxHeight == 0) {
                if (wRatio < 1)
                    ratio = wRatio;
            } else if (wRatio < 1 || hRatio < 1) {
                ratio = wRatio <= hRatio ? wRatio : hRatio;
            }
            if (ratio < 1) {
                w = w * ratio;
                h = h * ratio;
            }
            me.re.src = me.t.src;
            me.re.width = w;
            me.re.height = h;
        },
        onload: function () {
            var me = this;
            me.t.onload = null;
            me.resize();
            me.t = null;
        },
        onerror: function () {
            var me = this;
            me.t.onerror = null;
            var htmlImageElement = new XImage(me.errorImageCode, 0, 0, function () {
                me.re.src = this.re.src;
                me.re.width = this.re.width;
                me.re.height = this.re.height;
            });
        }
    };
    return XImage;
});
define('common/client/Sync', [], function () {
    var Sync = {
        ClearAsync: function (type) {
            var Timers = Sync.AsyncTimerController(type);
            for (var i in Timers.length) {
                window.clearTimeout(Timers[i]);
                Timers[i] = null;
            }
            Sync.AsyncTimerController(type, new Array());
        },
        SetAsync: function (fn, type, interval) {
            interval = interval || 0;
            var Timers = Sync.AsyncTimerController(type);
            Timers.push(window.setTimeout(fn, interval));
        },
        AsyncTimerController: function (type, value) {
            type = type || 'Default';
            if (value)
                Sync.AsyncTimer[type] = value;
            else
                return Sync.AsyncTimer[type] ? Sync.AsyncTimer[type] : Sync.AsyncTimer[type] = new Array();
        },
        AsyncTimer: {}
    };
    return Sync;
});
(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? module.exports = factory() : typeof define === 'function' && define.amd ? define('vue', [], factory) : global.Vue = factory();
}(this, function () {
    'use strict';
    function set(obj, key, val) {
        if (hasOwn(obj, key)) {
            obj[key] = val;
            return;
        }
        if (obj._isVue) {
            set(obj._data, key, val);
            return;
        }
        var ob = obj.__ob__;
        if (!ob) {
            obj[key] = val;
            return;
        }
        ob.convert(key, val);
        ob.dep.notify();
        if (ob.vms) {
            var i = ob.vms.length;
            while (i--) {
                var vm = ob.vms[i];
                vm._proxy(key);
                vm._digest();
            }
        }
        return val;
    }
    function del(obj, key) {
        if (!hasOwn(obj, key)) {
            return;
        }
        delete obj[key];
        var ob = obj.__ob__;
        if (!ob) {
            if (obj._isVue) {
                delete obj._data[key];
                obj._digest();
            }
            return;
        }
        ob.dep.notify();
        if (ob.vms) {
            var i = ob.vms.length;
            while (i--) {
                var vm = ob.vms[i];
                vm._unproxy(key);
                vm._digest();
            }
        }
    }
    var hasOwnProperty = Object.prototype.hasOwnProperty;
    function hasOwn(obj, key) {
        return hasOwnProperty.call(obj, key);
    }
    var literalValueRE = /^\s?(true|false|-?[\d\.]+|'[^']*'|"[^"]*")\s?$/;
    function isLiteral(exp) {
        return literalValueRE.test(exp);
    }
    function isReserved(str) {
        var c = (str + '').charCodeAt(0);
        return c === 36 || c === 95;
    }
    function _toString(value) {
        return value == null ? '' : value.toString();
    }
    function toNumber(value) {
        if (typeof value !== 'string') {
            return value;
        } else {
            var parsed = Number(value);
            return isNaN(parsed) ? value : parsed;
        }
    }
    function toBoolean(value) {
        return value === 'true' ? true : value === 'false' ? false : value;
    }
    function stripQuotes(str) {
        var a = str.charCodeAt(0);
        var b = str.charCodeAt(str.length - 1);
        return a === b && (a === 34 || a === 39) ? str.slice(1, -1) : str;
    }
    var camelizeRE = /-(\w)/g;
    function camelize(str) {
        return str.replace(camelizeRE, toUpper);
    }
    function toUpper(_, c) {
        return c ? c.toUpperCase() : '';
    }
    var hyphenateRE = /([a-z\d])([A-Z])/g;
    function hyphenate(str) {
        return str.replace(hyphenateRE, '$1-$2').toLowerCase();
    }
    var classifyRE = /(?:^|[-_\/])(\w)/g;
    function classify(str) {
        return str.replace(classifyRE, toUpper);
    }
    function bind(fn, ctx) {
        return function (a) {
            var l = arguments.length;
            return l ? l > 1 ? fn.apply(ctx, arguments) : fn.call(ctx, a) : fn.call(ctx);
        };
    }
    function toArray(list, start) {
        start = start || 0;
        var i = list.length - start;
        var ret = new Array(i);
        while (i--) {
            ret[i] = list[i + start];
        }
        return ret;
    }
    function extend(to, from) {
        var keys = Object.keys(from);
        var i = keys.length;
        while (i--) {
            to[keys[i]] = from[keys[i]];
        }
        return to;
    }
    function isObject(obj) {
        return obj !== null && typeof obj === 'object';
    }
    var toString = Object.prototype.toString;
    var OBJECT_STRING = '[object Object]';
    function isPlainObject(obj) {
        return toString.call(obj) === OBJECT_STRING;
    }
    var isArray = Array.isArray;
    function def(obj, key, val, enumerable) {
        Object.defineProperty(obj, key, {
            value: val,
            enumerable: !!enumerable,
            writable: true,
            configurable: true
        });
    }
    function _debounce(func, wait) {
        var timeout, args, context, timestamp, result;
        var later = function later() {
            var last = Date.now() - timestamp;
            if (last < wait && last >= 0) {
                timeout = setTimeout(later, wait - last);
            } else {
                timeout = null;
                result = func.apply(context, args);
                if (!timeout)
                    context = args = null;
            }
        };
        return function () {
            context = this;
            args = arguments;
            timestamp = Date.now();
            if (!timeout) {
                timeout = setTimeout(later, wait);
            }
            return result;
        };
    }
    function indexOf(arr, obj) {
        var i = arr.length;
        while (i--) {
            if (arr[i] === obj)
                return i;
        }
        return -1;
    }
    function cancellable(fn) {
        var cb = function cb() {
            if (!cb.cancelled) {
                return fn.apply(this, arguments);
            }
        };
        cb.cancel = function () {
            cb.cancelled = true;
        };
        return cb;
    }
    function looseEqual(a, b) {
        return a == b || (isObject(a) && isObject(b) ? JSON.stringify(a) === JSON.stringify(b) : false);
    }
    var hasProto = '__proto__' in {};
    var inBrowser = typeof window !== 'undefined' && Object.prototype.toString.call(window) !== '[object Object]';
    var devtools = inBrowser && window.__VUE_DEVTOOLS_GLOBAL_HOOK__;
    var UA = inBrowser && window.navigator.userAgent.toLowerCase();
    var isIE9 = UA && UA.indexOf('msie 9.0') > 0;
    var isAndroid = UA && UA.indexOf('android') > 0;
    var isIos = UA && /(iphone|ipad|ipod|ios)/i.test(UA);
    var isWechat = UA && UA.indexOf('micromessenger') > 0;
    var transitionProp = undefined;
    var transitionEndEvent = undefined;
    var animationProp = undefined;
    var animationEndEvent = undefined;
    if (inBrowser && !isIE9) {
        var isWebkitTrans = window.ontransitionend === undefined && window.onwebkittransitionend !== undefined;
        var isWebkitAnim = window.onanimationend === undefined && window.onwebkitanimationend !== undefined;
        transitionProp = isWebkitTrans ? 'WebkitTransition' : 'transition';
        transitionEndEvent = isWebkitTrans ? 'webkitTransitionEnd' : 'transitionend';
        animationProp = isWebkitAnim ? 'WebkitAnimation' : 'animation';
        animationEndEvent = isWebkitAnim ? 'webkitAnimationEnd' : 'animationend';
    }
    var nextTick = function () {
        var callbacks = [];
        var pending = false;
        var timerFunc;
        function nextTickHandler() {
            pending = false;
            var copies = callbacks.slice(0);
            callbacks = [];
            for (var i = 0; i < copies.length; i++) {
                copies[i]();
            }
        }
        if (typeof MutationObserver !== 'undefined' && !(isWechat && isIos)) {
            var counter = 1;
            var observer = new MutationObserver(nextTickHandler);
            var textNode = document.createTextNode(counter);
            observer.observe(textNode, { characterData: true });
            timerFunc = function () {
                counter = (counter + 1) % 2;
                textNode.data = counter;
            };
        } else {
            var context = inBrowser ? window : typeof global !== 'undefined' ? global : {};
            timerFunc = context.setImmediate || setTimeout;
        }
        return function (cb, ctx) {
            var func = ctx ? function () {
                cb.call(ctx);
            } : cb;
            callbacks.push(func);
            if (pending)
                return;
            pending = true;
            timerFunc(nextTickHandler, 0);
        };
    }();
    var _Set = undefined;
    if (typeof Set !== 'undefined' && Set.toString().match(/native code/)) {
        _Set = Set;
    } else {
        _Set = function () {
            this.set = Object.create(null);
        };
        _Set.prototype.has = function (key) {
            return this.set[key] !== undefined;
        };
        _Set.prototype.add = function (key) {
            this.set[key] = 1;
        };
        _Set.prototype.clear = function () {
            this.set = Object.create(null);
        };
    }
    function Cache(limit) {
        this.size = 0;
        this.limit = limit;
        this.head = this.tail = undefined;
        this._keymap = Object.create(null);
    }
    var p = Cache.prototype;
    p.put = function (key, value) {
        var removed;
        if (this.size === this.limit) {
            removed = this.shift();
        }
        var entry = this.get(key, true);
        if (!entry) {
            entry = { key: key };
            this._keymap[key] = entry;
            if (this.tail) {
                this.tail.newer = entry;
                entry.older = this.tail;
            } else {
                this.head = entry;
            }
            this.tail = entry;
            this.size++;
        }
        entry.value = value;
        return removed;
    };
    p.shift = function () {
        var entry = this.head;
        if (entry) {
            this.head = this.head.newer;
            this.head.older = undefined;
            entry.newer = entry.older = undefined;
            this._keymap[entry.key] = undefined;
            this.size--;
        }
        return entry;
    };
    p.get = function (key, returnEntry) {
        var entry = this._keymap[key];
        if (entry === undefined)
            return;
        if (entry === this.tail) {
            return returnEntry ? entry : entry.value;
        }
        if (entry.newer) {
            if (entry === this.head) {
                this.head = entry.newer;
            }
            entry.newer.older = entry.older;
        }
        if (entry.older) {
            entry.older.newer = entry.newer;
        }
        entry.newer = undefined;
        entry.older = this.tail;
        if (this.tail) {
            this.tail.newer = entry;
        }
        this.tail = entry;
        return returnEntry ? entry : entry.value;
    };
    var cache$1 = new Cache(1000);
    var filterTokenRE = /[^\s'"]+|'[^']*'|"[^"]*"/g;
    var reservedArgRE = /^in$|^-?\d+/;
    var str;
    var dir;
    var c;
    var prev;
    var i;
    var l;
    var lastFilterIndex;
    var inSingle;
    var inDouble;
    var curly;
    var square;
    var paren;
    function pushFilter() {
        var exp = str.slice(lastFilterIndex, i).trim();
        var filter;
        if (exp) {
            filter = {};
            var tokens = exp.match(filterTokenRE);
            filter.name = tokens[0];
            if (tokens.length > 1) {
                filter.args = tokens.slice(1).map(processFilterArg);
            }
        }
        if (filter) {
            (dir.filters = dir.filters || []).push(filter);
        }
        lastFilterIndex = i + 1;
    }
    function processFilterArg(arg) {
        if (reservedArgRE.test(arg)) {
            return {
                value: toNumber(arg),
                dynamic: false
            };
        } else {
            var stripped = stripQuotes(arg);
            var dynamic = stripped === arg;
            return {
                value: dynamic ? arg : stripped,
                dynamic: dynamic
            };
        }
    }
    function parseDirective(s) {
        var hit = cache$1.get(s);
        if (hit) {
            return hit;
        }
        str = s;
        inSingle = inDouble = false;
        curly = square = paren = 0;
        lastFilterIndex = 0;
        dir = {};
        for (i = 0, l = str.length; i < l; i++) {
            prev = c;
            c = str.charCodeAt(i);
            if (inSingle) {
                if (c === 39 && prev !== 92)
                    inSingle = !inSingle;
            } else if (inDouble) {
                if (c === 34 && prev !== 92)
                    inDouble = !inDouble;
            } else if (c === 124 && str.charCodeAt(i + 1) !== 124 && str.charCodeAt(i - 1) !== 124) {
                if (dir.expression == null) {
                    lastFilterIndex = i + 1;
                    dir.expression = str.slice(0, i).trim();
                } else {
                    pushFilter();
                }
            } else {
                switch (c) {
                case 34:
                    inDouble = true;
                    break;
                case 39:
                    inSingle = true;
                    break;
                case 40:
                    paren++;
                    break;
                case 41:
                    paren--;
                    break;
                case 91:
                    square++;
                    break;
                case 93:
                    square--;
                    break;
                case 123:
                    curly++;
                    break;
                case 125:
                    curly--;
                    break;
                }
            }
        }
        if (dir.expression == null) {
            dir.expression = str.slice(0, i).trim();
        } else if (lastFilterIndex !== 0) {
            pushFilter();
        }
        cache$1.put(s, dir);
        return dir;
    }
    var directive = Object.freeze({ parseDirective: parseDirective });
    var regexEscapeRE = /[-.*+?^${}()|[\]\/\\]/g;
    var cache = undefined;
    var tagRE = undefined;
    var htmlRE = undefined;
    function escapeRegex(str) {
        return str.replace(regexEscapeRE, '\\$&');
    }
    function compileRegex() {
        var open = escapeRegex(config.delimiters[0]);
        var close = escapeRegex(config.delimiters[1]);
        var unsafeOpen = escapeRegex(config.unsafeDelimiters[0]);
        var unsafeClose = escapeRegex(config.unsafeDelimiters[1]);
        tagRE = new RegExp(unsafeOpen + '((?:.|\\n)+?)' + unsafeClose + '|' + open + '((?:.|\\n)+?)' + close, 'g');
        htmlRE = new RegExp('^' + unsafeOpen + '.*' + unsafeClose + '$');
        cache = new Cache(1000);
    }
    function parseText(text) {
        if (!cache) {
            compileRegex();
        }
        var hit = cache.get(text);
        if (hit) {
            return hit;
        }
        if (!tagRE.test(text)) {
            return null;
        }
        var tokens = [];
        var lastIndex = tagRE.lastIndex = 0;
        var match, index, html, value, first, oneTime;
        while (match = tagRE.exec(text)) {
            index = match.index;
            if (index > lastIndex) {
                tokens.push({ value: text.slice(lastIndex, index) });
            }
            html = htmlRE.test(match[0]);
            value = html ? match[1] : match[2];
            first = value.charCodeAt(0);
            oneTime = first === 42;
            value = oneTime ? value.slice(1) : value;
            tokens.push({
                tag: true,
                value: value.trim(),
                html: html,
                oneTime: oneTime
            });
            lastIndex = index + match[0].length;
        }
        if (lastIndex < text.length) {
            tokens.push({ value: text.slice(lastIndex) });
        }
        cache.put(text, tokens);
        return tokens;
    }
    function tokensToExp(tokens, vm) {
        if (tokens.length > 1) {
            return tokens.map(function (token) {
                return formatToken(token, vm);
            }).join('+');
        } else {
            return formatToken(tokens[0], vm, true);
        }
    }
    function formatToken(token, vm, single) {
        return token.tag ? token.oneTime && vm ? '"' + vm.$eval(token.value) + '"' : inlineFilters(token.value, single) : '"' + token.value + '"';
    }
    var filterRE = /[^|]\|[^|]/;
    function inlineFilters(exp, single) {
        if (!filterRE.test(exp)) {
            return single ? exp : '(' + exp + ')';
        } else {
            var dir = parseDirective(exp);
            if (!dir.filters) {
                return '(' + exp + ')';
            } else {
                return 'this._applyFilters(' + dir.expression + ',null,' + JSON.stringify(dir.filters) + ',false)';
            }
        }
    }
    var text = Object.freeze({
        compileRegex: compileRegex,
        parseText: parseText,
        tokensToExp: tokensToExp
    });
    var delimiters = [
        '{{',
        '}}'
    ];
    var unsafeDelimiters = [
        '{{{',
        '}}}'
    ];
    var config = Object.defineProperties({
        debug: false,
        silent: false,
        async: true,
        warnExpressionErrors: true,
        devtools: 'development' !== 'production',
        _delimitersChanged: true,
        _assetTypes: [
            'component',
            'directive',
            'elementDirective',
            'filter',
            'transition',
            'partial'
        ],
        _propBindingModes: {
            ONE_WAY: 0,
            TWO_WAY: 1,
            ONE_TIME: 2
        },
        _maxUpdateCount: 100
    }, {
        delimiters: {
            get: function get() {
                return delimiters;
            },
            set: function set(val) {
                delimiters = val;
                compileRegex();
            },
            configurable: true,
            enumerable: true
        },
        unsafeDelimiters: {
            get: function get() {
                return unsafeDelimiters;
            },
            set: function set(val) {
                unsafeDelimiters = val;
                compileRegex();
            },
            configurable: true,
            enumerable: true
        }
    });
    var warn = undefined;
    var formatComponentName = undefined;
    if ('development' !== 'production') {
        (function () {
            var hasConsole = typeof console !== 'undefined';
            warn = function (msg, vm) {
                if (hasConsole && !config.silent) {
                    console.error('[Vue warn]: ' + msg + (vm ? formatComponentName(vm) : ''));
                }
            };
            formatComponentName = function (vm) {
                var name = vm._isVue ? vm.$options.name : vm.name;
                return name ? ' (found in component: <' + hyphenate(name) + '>)' : '';
            };
        }());
    }
    function appendWithTransition(el, target, vm, cb) {
        applyTransition(el, 1, function () {
            target.appendChild(el);
        }, vm, cb);
    }
    function beforeWithTransition(el, target, vm, cb) {
        applyTransition(el, 1, function () {
            before(el, target);
        }, vm, cb);
    }
    function removeWithTransition(el, vm, cb) {
        applyTransition(el, -1, function () {
            remove(el);
        }, vm, cb);
    }
    function applyTransition(el, direction, op, vm, cb) {
        var transition = el.__v_trans;
        if (!transition || !transition.hooks && !transitionEndEvent || !vm._isCompiled || vm.$parent && !vm.$parent._isCompiled) {
            op();
            if (cb)
                cb();
            return;
        }
        var action = direction > 0 ? 'enter' : 'leave';
        transition[action](op, cb);
    }
    var transition = Object.freeze({
        appendWithTransition: appendWithTransition,
        beforeWithTransition: beforeWithTransition,
        removeWithTransition: removeWithTransition,
        applyTransition: applyTransition
    });
    function query(el) {
        if (typeof el === 'string') {
            var selector = el;
            el = document.querySelector(el);
            if (!el) {
                'development' !== 'production' && warn('Cannot find element: ' + selector);
            }
        }
        return el;
    }
    function inDoc(node) {
        if (!node)
            return false;
        var doc = node.ownerDocument.documentElement;
        var parent = node.parentNode;
        return doc === node || doc === parent || !!(parent && parent.nodeType === 1 && doc.contains(parent));
    }
    function getAttr(node, _attr) {
        var val = node.getAttribute(_attr);
        if (val !== null) {
            node.removeAttribute(_attr);
        }
        return val;
    }
    function getBindAttr(node, name) {
        var val = getAttr(node, ':' + name);
        if (val === null) {
            val = getAttr(node, 'v-bind:' + name);
        }
        return val;
    }
    function hasBindAttr(node, name) {
        return node.hasAttribute(name) || node.hasAttribute(':' + name) || node.hasAttribute('v-bind:' + name);
    }
    function before(el, target) {
        target.parentNode.insertBefore(el, target);
    }
    function after(el, target) {
        if (target.nextSibling) {
            before(el, target.nextSibling);
        } else {
            target.parentNode.appendChild(el);
        }
    }
    function remove(el) {
        el.parentNode.removeChild(el);
    }
    function prepend(el, target) {
        if (target.firstChild) {
            before(el, target.firstChild);
        } else {
            target.appendChild(el);
        }
    }
    function replace(target, el) {
        var parent = target.parentNode;
        if (parent) {
            parent.replaceChild(el, target);
        }
    }
    function on(el, event, cb, useCapture) {
        el.addEventListener(event, cb, useCapture);
    }
    function off(el, event, cb) {
        el.removeEventListener(event, cb);
    }
    function getClass(el) {
        var classname = el.className;
        if (typeof classname === 'object') {
            classname = classname.baseVal || '';
        }
        return classname;
    }
    function setClass(el, cls) {
        if (isIE9 && !/svg$/.test(el.namespaceURI)) {
            el.className = cls;
        } else {
            el.setAttribute('class', cls);
        }
    }
    function addClass(el, cls) {
        if (el.classList) {
            el.classList.add(cls);
        } else {
            var cur = ' ' + getClass(el) + ' ';
            if (cur.indexOf(' ' + cls + ' ') < 0) {
                setClass(el, (cur + cls).trim());
            }
        }
    }
    function removeClass(el, cls) {
        if (el.classList) {
            el.classList.remove(cls);
        } else {
            var cur = ' ' + getClass(el) + ' ';
            var tar = ' ' + cls + ' ';
            while (cur.indexOf(tar) >= 0) {
                cur = cur.replace(tar, ' ');
            }
            setClass(el, cur.trim());
        }
        if (!el.className) {
            el.removeAttribute('class');
        }
    }
    function extractContent(el, asFragment) {
        var child;
        var rawContent;
        if (isTemplate(el) && isFragment(el.content)) {
            el = el.content;
        }
        if (el.hasChildNodes()) {
            trimNode(el);
            rawContent = asFragment ? document.createDocumentFragment() : document.createElement('div');
            while (child = el.firstChild) {
                rawContent.appendChild(child);
            }
        }
        return rawContent;
    }
    function trimNode(node) {
        var child;
        while (child = node.firstChild, isTrimmable(child)) {
            node.removeChild(child);
        }
        while (child = node.lastChild, isTrimmable(child)) {
            node.removeChild(child);
        }
    }
    function isTrimmable(node) {
        return node && (node.nodeType === 3 && !node.data.trim() || node.nodeType === 8);
    }
    function isTemplate(el) {
        return el.tagName && el.tagName.toLowerCase() === 'template';
    }
    function createAnchor(content, persist) {
        var anchor = config.debug ? document.createComment(content) : document.createTextNode(persist ? ' ' : '');
        anchor.__v_anchor = true;
        return anchor;
    }
    var refRE = /^v-ref:/;
    function findRef(node) {
        if (node.hasAttributes()) {
            var attrs = node.attributes;
            for (var i = 0, l = attrs.length; i < l; i++) {
                var name = attrs[i].name;
                if (refRE.test(name)) {
                    return camelize(name.replace(refRE, ''));
                }
            }
        }
    }
    function mapNodeRange(node, end, op) {
        var next;
        while (node !== end) {
            next = node.nextSibling;
            op(node);
            node = next;
        }
        op(end);
    }
    function removeNodeRange(start, end, vm, frag, cb) {
        var done = false;
        var removed = 0;
        var nodes = [];
        mapNodeRange(start, end, function (node) {
            if (node === end)
                done = true;
            nodes.push(node);
            removeWithTransition(node, vm, onRemoved);
        });
        function onRemoved() {
            removed++;
            if (done && removed >= nodes.length) {
                for (var i = 0; i < nodes.length; i++) {
                    frag.appendChild(nodes[i]);
                }
                cb && cb();
            }
        }
    }
    function isFragment(node) {
        return node && node.nodeType === 11;
    }
    function getOuterHTML(el) {
        if (el.outerHTML) {
            return el.outerHTML;
        } else {
            var container = document.createElement('div');
            container.appendChild(el.cloneNode(true));
            return container.innerHTML;
        }
    }
    var commonTagRE = /^(div|p|span|img|a|b|i|br|ul|ol|li|h1|h2|h3|h4|h5|h6|code|pre|table|th|td|tr|form|label|input|select|option|nav|article|section|header|footer)$/i;
    var reservedTagRE = /^(slot|partial|component)$/i;
    var isUnknownElement = undefined;
    if ('development' !== 'production') {
        isUnknownElement = function (el, tag) {
            if (tag.indexOf('-') > -1) {
                return el.constructor === window.HTMLUnknownElement || el.constructor === window.HTMLElement;
            } else {
                return /HTMLUnknownElement/.test(el.toString()) && !/^(data|time|rtc|rb)$/.test(tag);
            }
        };
    }
    function checkComponentAttr(el, options) {
        var tag = el.tagName.toLowerCase();
        var hasAttrs = el.hasAttributes();
        if (!commonTagRE.test(tag) && !reservedTagRE.test(tag)) {
            if (resolveAsset(options, 'components', tag)) {
                return { id: tag };
            } else {
                var is = hasAttrs && getIsBinding(el, options);
                if (is) {
                    return is;
                } else if ('development' !== 'production') {
                    var expectedTag = options._componentNameMap && options._componentNameMap[tag];
                    if (expectedTag) {
                        warn('Unknown custom element: <' + tag + '> - ' + 'did you mean <' + expectedTag + '>? ' + 'HTML is case-insensitive, remember to use kebab-case in templates.');
                    } else if (isUnknownElement(el, tag)) {
                        warn('Unknown custom element: <' + tag + '> - did you ' + 'register the component correctly? For recursive components, ' + 'make sure to provide the "name" option.');
                    }
                }
            }
        } else if (hasAttrs) {
            return getIsBinding(el, options);
        }
    }
    function getIsBinding(el, options) {
        var exp = el.getAttribute('is');
        if (exp != null) {
            if (resolveAsset(options, 'components', exp)) {
                el.removeAttribute('is');
                return { id: exp };
            }
        } else {
            exp = getBindAttr(el, 'is');
            if (exp != null) {
                return {
                    id: exp,
                    dynamic: true
                };
            }
        }
    }
    var strats = config.optionMergeStrategies = Object.create(null);
    function mergeData(to, from) {
        var key, toVal, fromVal;
        for (key in from) {
            toVal = to[key];
            fromVal = from[key];
            if (!hasOwn(to, key)) {
                set(to, key, fromVal);
            } else if (isObject(toVal) && isObject(fromVal)) {
                mergeData(toVal, fromVal);
            }
        }
        return to;
    }
    strats.data = function (parentVal, childVal, vm) {
        if (!vm) {
            if (!childVal) {
                return parentVal;
            }
            if (typeof childVal !== 'function') {
                'development' !== 'production' && warn('The "data" option should be a function ' + 'that returns a per-instance value in component ' + 'definitions.', vm);
                return parentVal;
            }
            if (!parentVal) {
                return childVal;
            }
            return function mergedDataFn() {
                return mergeData(childVal.call(this), parentVal.call(this));
            };
        } else if (parentVal || childVal) {
            return function mergedInstanceDataFn() {
                var instanceData = typeof childVal === 'function' ? childVal.call(vm) : childVal;
                var defaultData = typeof parentVal === 'function' ? parentVal.call(vm) : undefined;
                if (instanceData) {
                    return mergeData(instanceData, defaultData);
                } else {
                    return defaultData;
                }
            };
        }
    };
    strats.el = function (parentVal, childVal, vm) {
        if (!vm && childVal && typeof childVal !== 'function') {
            'development' !== 'production' && warn('The "el" option should be a function ' + 'that returns a per-instance value in component ' + 'definitions.', vm);
            return;
        }
        var ret = childVal || parentVal;
        return vm && typeof ret === 'function' ? ret.call(vm) : ret;
    };
    strats.init = strats.created = strats.ready = strats.attached = strats.detached = strats.beforeCompile = strats.compiled = strats.beforeDestroy = strats.destroyed = strats.activate = function (parentVal, childVal) {
        return childVal ? parentVal ? parentVal.concat(childVal) : isArray(childVal) ? childVal : [childVal] : parentVal;
    };
    function mergeAssets(parentVal, childVal) {
        var res = Object.create(parentVal || null);
        return childVal ? extend(res, guardArrayAssets(childVal)) : res;
    }
    config._assetTypes.forEach(function (type) {
        strats[type + 's'] = mergeAssets;
    });
    strats.watch = strats.events = function (parentVal, childVal) {
        if (!childVal)
            return parentVal;
        if (!parentVal)
            return childVal;
        var ret = {};
        extend(ret, parentVal);
        for (var key in childVal) {
            var parent = ret[key];
            var child = childVal[key];
            if (parent && !isArray(parent)) {
                parent = [parent];
            }
            ret[key] = parent ? parent.concat(child) : [child];
        }
        return ret;
    };
    strats.props = strats.methods = strats.computed = function (parentVal, childVal) {
        if (!childVal)
            return parentVal;
        if (!parentVal)
            return childVal;
        var ret = Object.create(null);
        extend(ret, parentVal);
        extend(ret, childVal);
        return ret;
    };
    var defaultStrat = function defaultStrat(parentVal, childVal) {
        return childVal === undefined ? parentVal : childVal;
    };
    function guardComponents(options) {
        if (options.components) {
            var components = options.components = guardArrayAssets(options.components);
            var ids = Object.keys(components);
            var def;
            if ('development' !== 'production') {
                var map = options._componentNameMap = {};
            }
            for (var i = 0, l = ids.length; i < l; i++) {
                var key = ids[i];
                if (commonTagRE.test(key) || reservedTagRE.test(key)) {
                    'development' !== 'production' && warn('Do not use built-in or reserved HTML elements as component ' + 'id: ' + key);
                    continue;
                }
                if ('development' !== 'production') {
                    map[key.replace(/-/g, '').toLowerCase()] = hyphenate(key);
                }
                def = components[key];
                if (isPlainObject(def)) {
                    components[key] = Vue.extend(def);
                }
            }
        }
    }
    function guardProps(options) {
        var props = options.props;
        var i, val;
        if (isArray(props)) {
            options.props = {};
            i = props.length;
            while (i--) {
                val = props[i];
                if (typeof val === 'string') {
                    options.props[val] = null;
                } else if (val.name) {
                    options.props[val.name] = val;
                }
            }
        } else if (isPlainObject(props)) {
            var keys = Object.keys(props);
            i = keys.length;
            while (i--) {
                val = props[keys[i]];
                if (typeof val === 'function') {
                    props[keys[i]] = { type: val };
                }
            }
        }
    }
    function guardArrayAssets(assets) {
        if (isArray(assets)) {
            var res = {};
            var i = assets.length;
            var asset;
            while (i--) {
                asset = assets[i];
                var id = typeof asset === 'function' ? asset.options && asset.options.name || asset.id : asset.name || asset.id;
                if (!id) {
                    'development' !== 'production' && warn('Array-syntax assets must provide a "name" or "id" field.');
                } else {
                    res[id] = asset;
                }
            }
            return res;
        }
        return assets;
    }
    function mergeOptions(parent, child, vm) {
        guardComponents(child);
        guardProps(child);
        if ('development' !== 'production') {
            if (child.propsData && !vm) {
                warn('propsData can only be used as an instantiation option.');
            }
        }
        var options = {};
        var key;
        if (child['extends']) {
            parent = typeof child['extends'] === 'function' ? mergeOptions(parent, child['extends'].options, vm) : mergeOptions(parent, child['extends'], vm);
        }
        if (child.mixins) {
            for (var i = 0, l = child.mixins.length; i < l; i++) {
                parent = mergeOptions(parent, child.mixins[i], vm);
            }
        }
        for (key in parent) {
            mergeField(key);
        }
        for (key in child) {
            if (!hasOwn(parent, key)) {
                mergeField(key);
            }
        }
        function mergeField(key) {
            var strat = strats[key] || defaultStrat;
            options[key] = strat(parent[key], child[key], vm, key);
        }
        return options;
    }
    function resolveAsset(options, type, id, warnMissing) {
        if (typeof id !== 'string') {
            return;
        }
        var assets = options[type];
        var camelizedId;
        var res = assets[id] || assets[camelizedId = camelize(id)] || assets[camelizedId.charAt(0).toUpperCase() + camelizedId.slice(1)];
        if ('development' !== 'production' && warnMissing && !res) {
            warn('Failed to resolve ' + type.slice(0, -1) + ': ' + id, options);
        }
        return res;
    }
    var uid$1 = 0;
    function Dep() {
        this.id = uid$1++;
        this.subs = [];
    }
    Dep.target = null;
    Dep.prototype.addSub = function (sub) {
        this.subs.push(sub);
    };
    Dep.prototype.removeSub = function (sub) {
        this.subs.$remove(sub);
    };
    Dep.prototype.depend = function () {
        Dep.target.addDep(this);
    };
    Dep.prototype.notify = function () {
        var subs = toArray(this.subs);
        for (var i = 0, l = subs.length; i < l; i++) {
            subs[i].update();
        }
    };
    var arrayProto = Array.prototype;
    var arrayMethods = Object.create(arrayProto);
    [
        'push',
        'pop',
        'shift',
        'unshift',
        'splice',
        'sort',
        'reverse'
    ].forEach(function (method) {
        var original = arrayProto[method];
        def(arrayMethods, method, function mutator() {
            var i = arguments.length;
            var args = new Array(i);
            while (i--) {
                args[i] = arguments[i];
            }
            var result = original.apply(this, args);
            var ob = this.__ob__;
            var inserted;
            switch (method) {
            case 'push':
                inserted = args;
                break;
            case 'unshift':
                inserted = args;
                break;
            case 'splice':
                inserted = args.slice(2);
                break;
            }
            if (inserted)
                ob.observeArray(inserted);
            ob.dep.notify();
            return result;
        });
    });
    def(arrayProto, '$set', function $set(index, val) {
        if (index >= this.length) {
            this.length = Number(index) + 1;
        }
        return this.splice(index, 1, val)[0];
    });
    def(arrayProto, '$remove', function $remove(item) {
        if (!this.length)
            return;
        var index = indexOf(this, item);
        if (index > -1) {
            return this.splice(index, 1);
        }
    });
    var arrayKeys = Object.getOwnPropertyNames(arrayMethods);
    var shouldConvert = true;
    function withoutConversion(fn) {
        shouldConvert = false;
        fn();
        shouldConvert = true;
    }
    function Observer(value) {
        this.value = value;
        this.dep = new Dep();
        def(value, '__ob__', this);
        if (isArray(value)) {
            var augment = hasProto ? protoAugment : copyAugment;
            augment(value, arrayMethods, arrayKeys);
            this.observeArray(value);
        } else {
            this.walk(value);
        }
    }
    Observer.prototype.walk = function (obj) {
        var keys = Object.keys(obj);
        for (var i = 0, l = keys.length; i < l; i++) {
            this.convert(keys[i], obj[keys[i]]);
        }
    };
    Observer.prototype.observeArray = function (items) {
        for (var i = 0, l = items.length; i < l; i++) {
            observe(items[i]);
        }
    };
    Observer.prototype.convert = function (key, val) {
        defineReactive(this.value, key, val);
    };
    Observer.prototype.addVm = function (vm) {
        (this.vms || (this.vms = [])).push(vm);
    };
    Observer.prototype.removeVm = function (vm) {
        this.vms.$remove(vm);
    };
    function protoAugment(target, src) {
        target.__proto__ = src;
    }
    function copyAugment(target, src, keys) {
        for (var i = 0, l = keys.length; i < l; i++) {
            var key = keys[i];
            def(target, key, src[key]);
        }
    }
    function observe(value, vm) {
        if (!value || typeof value !== 'object') {
            return;
        }
        var ob;
        if (hasOwn(value, '__ob__') && value.__ob__ instanceof Observer) {
            ob = value.__ob__;
        } else if (shouldConvert && (isArray(value) || isPlainObject(value)) && Object.isExtensible(value) && !value._isVue) {
            ob = new Observer(value);
        }
        if (ob && vm) {
            ob.addVm(vm);
        }
        return ob;
    }
    function defineReactive(obj, key, val) {
        var dep = new Dep();
        var property = Object.getOwnPropertyDescriptor(obj, key);
        if (property && property.configurable === false) {
            return;
        }
        var getter = property && property.get;
        var setter = property && property.set;
        var childOb = observe(val);
        Object.defineProperty(obj, key, {
            enumerable: true,
            configurable: true,
            get: function reactiveGetter() {
                var value = getter ? getter.call(obj) : val;
                if (Dep.target) {
                    dep.depend();
                    if (childOb) {
                        childOb.dep.depend();
                    }
                    if (isArray(value)) {
                        for (var e, i = 0, l = value.length; i < l; i++) {
                            e = value[i];
                            e && e.__ob__ && e.__ob__.dep.depend();
                        }
                    }
                }
                return value;
            },
            set: function reactiveSetter(newVal) {
                var value = getter ? getter.call(obj) : val;
                if (newVal === value) {
                    return;
                }
                if (setter) {
                    setter.call(obj, newVal);
                } else {
                    val = newVal;
                }
                childOb = observe(newVal);
                dep.notify();
            }
        });
    }
    var util = Object.freeze({
        defineReactive: defineReactive,
        set: set,
        del: del,
        hasOwn: hasOwn,
        isLiteral: isLiteral,
        isReserved: isReserved,
        _toString: _toString,
        toNumber: toNumber,
        toBoolean: toBoolean,
        stripQuotes: stripQuotes,
        camelize: camelize,
        hyphenate: hyphenate,
        classify: classify,
        bind: bind,
        toArray: toArray,
        extend: extend,
        isObject: isObject,
        isPlainObject: isPlainObject,
        def: def,
        debounce: _debounce,
        indexOf: indexOf,
        cancellable: cancellable,
        looseEqual: looseEqual,
        isArray: isArray,
        hasProto: hasProto,
        inBrowser: inBrowser,
        devtools: devtools,
        isIE9: isIE9,
        isAndroid: isAndroid,
        isIos: isIos,
        isWechat: isWechat,
        get transitionProp() {
            return transitionProp;
        },
        get transitionEndEvent() {
            return transitionEndEvent;
        },
        get animationProp() {
            return animationProp;
        },
        get animationEndEvent() {
            return animationEndEvent;
        },
        nextTick: nextTick,
        get _Set() {
            return _Set;
        },
        query: query,
        inDoc: inDoc,
        getAttr: getAttr,
        getBindAttr: getBindAttr,
        hasBindAttr: hasBindAttr,
        before: before,
        after: after,
        remove: remove,
        prepend: prepend,
        replace: replace,
        on: on,
        off: off,
        setClass: setClass,
        addClass: addClass,
        removeClass: removeClass,
        extractContent: extractContent,
        trimNode: trimNode,
        isTemplate: isTemplate,
        createAnchor: createAnchor,
        findRef: findRef,
        mapNodeRange: mapNodeRange,
        removeNodeRange: removeNodeRange,
        isFragment: isFragment,
        getOuterHTML: getOuterHTML,
        mergeOptions: mergeOptions,
        resolveAsset: resolveAsset,
        checkComponentAttr: checkComponentAttr,
        commonTagRE: commonTagRE,
        reservedTagRE: reservedTagRE,
        get warn() {
            return warn;
        }
    });
    var uid = 0;
    function initMixin(Vue) {
        Vue.prototype._init = function (options) {
            options = options || {};
            this.$el = null;
            this.$parent = options.parent;
            this.$root = this.$parent ? this.$parent.$root : this;
            this.$children = [];
            this.$refs = {};
            this.$els = {};
            this._watchers = [];
            this._directives = [];
            this._uid = uid++;
            this._isVue = true;
            this._events = {};
            this._eventsCount = {};
            this._isFragment = false;
            this._fragment = this._fragmentStart = this._fragmentEnd = null;
            this._isCompiled = this._isDestroyed = this._isReady = this._isAttached = this._isBeingDestroyed = this._vForRemoving = false;
            this._unlinkFn = null;
            this._context = options._context || this.$parent;
            this._scope = options._scope;
            this._frag = options._frag;
            if (this._frag) {
                this._frag.children.push(this);
            }
            if (this.$parent) {
                this.$parent.$children.push(this);
            }
            options = this.$options = mergeOptions(this.constructor.options, options, this);
            this._updateRef();
            this._data = {};
            this._callHook('init');
            this._initState();
            this._initEvents();
            this._callHook('created');
            if (options.el) {
                this.$mount(options.el);
            }
        };
    }
    var pathCache = new Cache(1000);
    var APPEND = 0;
    var PUSH = 1;
    var INC_SUB_PATH_DEPTH = 2;
    var PUSH_SUB_PATH = 3;
    var BEFORE_PATH = 0;
    var IN_PATH = 1;
    var BEFORE_IDENT = 2;
    var IN_IDENT = 3;
    var IN_SUB_PATH = 4;
    var IN_SINGLE_QUOTE = 5;
    var IN_DOUBLE_QUOTE = 6;
    var AFTER_PATH = 7;
    var ERROR = 8;
    var pathStateMachine = [];
    pathStateMachine[BEFORE_PATH] = {
        'ws': [BEFORE_PATH],
        'ident': [
            IN_IDENT,
            APPEND
        ],
        '[': [IN_SUB_PATH],
        'eof': [AFTER_PATH]
    };
    pathStateMachine[IN_PATH] = {
        'ws': [IN_PATH],
        '.': [BEFORE_IDENT],
        '[': [IN_SUB_PATH],
        'eof': [AFTER_PATH]
    };
    pathStateMachine[BEFORE_IDENT] = {
        'ws': [BEFORE_IDENT],
        'ident': [
            IN_IDENT,
            APPEND
        ]
    };
    pathStateMachine[IN_IDENT] = {
        'ident': [
            IN_IDENT,
            APPEND
        ],
        '0': [
            IN_IDENT,
            APPEND
        ],
        'number': [
            IN_IDENT,
            APPEND
        ],
        'ws': [
            IN_PATH,
            PUSH
        ],
        '.': [
            BEFORE_IDENT,
            PUSH
        ],
        '[': [
            IN_SUB_PATH,
            PUSH
        ],
        'eof': [
            AFTER_PATH,
            PUSH
        ]
    };
    pathStateMachine[IN_SUB_PATH] = {
        '\'': [
            IN_SINGLE_QUOTE,
            APPEND
        ],
        '"': [
            IN_DOUBLE_QUOTE,
            APPEND
        ],
        '[': [
            IN_SUB_PATH,
            INC_SUB_PATH_DEPTH
        ],
        ']': [
            IN_PATH,
            PUSH_SUB_PATH
        ],
        'eof': ERROR,
        'else': [
            IN_SUB_PATH,
            APPEND
        ]
    };
    pathStateMachine[IN_SINGLE_QUOTE] = {
        '\'': [
            IN_SUB_PATH,
            APPEND
        ],
        'eof': ERROR,
        'else': [
            IN_SINGLE_QUOTE,
            APPEND
        ]
    };
    pathStateMachine[IN_DOUBLE_QUOTE] = {
        '"': [
            IN_SUB_PATH,
            APPEND
        ],
        'eof': ERROR,
        'else': [
            IN_DOUBLE_QUOTE,
            APPEND
        ]
    };
    function getPathCharType(ch) {
        if (ch === undefined) {
            return 'eof';
        }
        var code = ch.charCodeAt(0);
        switch (code) {
        case 91:
        case 93:
        case 46:
        case 34:
        case 39:
        case 48:
            return ch;
        case 95:
        case 36:
            return 'ident';
        case 32:
        case 9:
        case 10:
        case 13:
        case 160:
        case 65279:
        case 8232:
        case 8233:
            return 'ws';
        }
        if (code >= 97 && code <= 122 || code >= 65 && code <= 90) {
            return 'ident';
        }
        if (code >= 49 && code <= 57) {
            return 'number';
        }
        return 'else';
    }
    function formatSubPath(path) {
        var trimmed = path.trim();
        if (path.charAt(0) === '0' && isNaN(path)) {
            return false;
        }
        return isLiteral(trimmed) ? stripQuotes(trimmed) : '*' + trimmed;
    }
    function parse(path) {
        var keys = [];
        var index = -1;
        var mode = BEFORE_PATH;
        var subPathDepth = 0;
        var c, newChar, key, type, transition, action, typeMap;
        var actions = [];
        actions[PUSH] = function () {
            if (key !== undefined) {
                keys.push(key);
                key = undefined;
            }
        };
        actions[APPEND] = function () {
            if (key === undefined) {
                key = newChar;
            } else {
                key += newChar;
            }
        };
        actions[INC_SUB_PATH_DEPTH] = function () {
            actions[APPEND]();
            subPathDepth++;
        };
        actions[PUSH_SUB_PATH] = function () {
            if (subPathDepth > 0) {
                subPathDepth--;
                mode = IN_SUB_PATH;
                actions[APPEND]();
            } else {
                subPathDepth = 0;
                key = formatSubPath(key);
                if (key === false) {
                    return false;
                } else {
                    actions[PUSH]();
                }
            }
        };
        function maybeUnescapeQuote() {
            var nextChar = path[index + 1];
            if (mode === IN_SINGLE_QUOTE && nextChar === '\'' || mode === IN_DOUBLE_QUOTE && nextChar === '"') {
                index++;
                newChar = '\\' + nextChar;
                actions[APPEND]();
                return true;
            }
        }
        while (mode != null) {
            index++;
            c = path[index];
            if (c === '\\' && maybeUnescapeQuote()) {
                continue;
            }
            type = getPathCharType(c);
            typeMap = pathStateMachine[mode];
            transition = typeMap[type] || typeMap['else'] || ERROR;
            if (transition === ERROR) {
                return;
            }
            mode = transition[0];
            action = actions[transition[1]];
            if (action) {
                newChar = transition[2];
                newChar = newChar === undefined ? c : newChar;
                if (action() === false) {
                    return;
                }
            }
            if (mode === AFTER_PATH) {
                keys.raw = path;
                return keys;
            }
        }
    }
    function parsePath(path) {
        var hit = pathCache.get(path);
        if (!hit) {
            hit = parse(path);
            if (hit) {
                pathCache.put(path, hit);
            }
        }
        return hit;
    }
    function getPath(obj, path) {
        return parseExpression(path).get(obj);
    }
    var warnNonExistent;
    if ('development' !== 'production') {
        warnNonExistent = function (path, vm) {
            warn('You are setting a non-existent path "' + path.raw + '" ' + 'on a vm instance. Consider pre-initializing the property ' + 'with the "data" option for more reliable reactivity ' + 'and better performance.', vm);
        };
    }
    function setPath(obj, path, val) {
        var original = obj;
        if (typeof path === 'string') {
            path = parse(path);
        }
        if (!path || !isObject(obj)) {
            return false;
        }
        var last, key;
        for (var i = 0, l = path.length; i < l; i++) {
            last = obj;
            key = path[i];
            if (key.charAt(0) === '*') {
                key = parseExpression(key.slice(1)).get.call(original, original);
            }
            if (i < l - 1) {
                obj = obj[key];
                if (!isObject(obj)) {
                    obj = {};
                    if ('development' !== 'production' && last._isVue) {
                        warnNonExistent(path, last);
                    }
                    set(last, key, obj);
                }
            } else {
                if (isArray(obj)) {
                    obj.$set(key, val);
                } else if (key in obj) {
                    obj[key] = val;
                } else {
                    if ('development' !== 'production' && obj._isVue) {
                        warnNonExistent(path, obj);
                    }
                    set(obj, key, val);
                }
            }
        }
        return true;
    }
    var path = Object.freeze({
        parsePath: parsePath,
        getPath: getPath,
        setPath: setPath
    });
    var expressionCache = new Cache(1000);
    var allowedKeywords = 'Math,Date,this,true,false,null,undefined,Infinity,NaN,' + 'isNaN,isFinite,decodeURI,decodeURIComponent,encodeURI,' + 'encodeURIComponent,parseInt,parseFloat';
    var allowedKeywordsRE = new RegExp('^(' + allowedKeywords.replace(/,/g, '\\b|') + '\\b)');
    var improperKeywords = 'break,case,class,catch,const,continue,debugger,default,' + 'delete,do,else,export,extends,finally,for,function,if,' + 'import,in,instanceof,let,return,super,switch,throw,try,' + 'var,while,with,yield,enum,await,implements,package,' + 'protected,static,interface,private,public';
    var improperKeywordsRE = new RegExp('^(' + improperKeywords.replace(/,/g, '\\b|') + '\\b)');
    var wsRE = /\s/g;
    var newlineRE = /\n/g;
    var saveRE = /[\{,]\s*[\w\$_]+\s*:|('(?:[^'\\]|\\.)*'|"(?:[^"\\]|\\.)*"|`(?:[^`\\]|\\.)*\$\{|\}(?:[^`\\]|\\.)*`|`(?:[^`\\]|\\.)*`)|new |typeof |void /g;
    var restoreRE = /"(\d+)"/g;
    var pathTestRE = /^[A-Za-z_$][\w$]*(?:\.[A-Za-z_$][\w$]*|\['.*?'\]|\[".*?"\]|\[\d+\]|\[[A-Za-z_$][\w$]*\])*$/;
    var identRE = /[^\w$\.](?:[A-Za-z_$][\w$]*)/g;
    var booleanLiteralRE = /^(?:true|false)$/;
    var saved = [];
    function save(str, isString) {
        var i = saved.length;
        saved[i] = isString ? str.replace(newlineRE, '\\n') : str;
        return '"' + i + '"';
    }
    function rewrite(raw) {
        var c = raw.charAt(0);
        var path = raw.slice(1);
        if (allowedKeywordsRE.test(path)) {
            return raw;
        } else {
            path = path.indexOf('"') > -1 ? path.replace(restoreRE, restore) : path;
            return c + 'scope.' + path;
        }
    }
    function restore(str, i) {
        return saved[i];
    }
    function compileGetter(exp) {
        if (improperKeywordsRE.test(exp)) {
            'development' !== 'production' && warn('Avoid using reserved keywords in expression: ' + exp);
        }
        saved.length = 0;
        var body = exp.replace(saveRE, save).replace(wsRE, '');
        body = (' ' + body).replace(identRE, rewrite).replace(restoreRE, restore);
        return makeGetterFn(body);
    }
    function makeGetterFn(body) {
        try {
            return new Function('scope', 'return ' + body + ';');
        } catch (e) {
            'development' !== 'production' && warn('Invalid expression. ' + 'Generated function body: ' + body);
        }
    }
    function compileSetter(exp) {
        var path = parsePath(exp);
        if (path) {
            return function (scope, val) {
                setPath(scope, path, val);
            };
        } else {
            'development' !== 'production' && warn('Invalid setter expression: ' + exp);
        }
    }
    function parseExpression(exp, needSet) {
        exp = exp.trim();
        var hit = expressionCache.get(exp);
        if (hit) {
            if (needSet && !hit.set) {
                hit.set = compileSetter(hit.exp);
            }
            return hit;
        }
        var res = { exp: exp };
        res.get = isSimplePath(exp) && exp.indexOf('[') < 0 ? makeGetterFn('scope.' + exp) : compileGetter(exp);
        if (needSet) {
            res.set = compileSetter(exp);
        }
        expressionCache.put(exp, res);
        return res;
    }
    function isSimplePath(exp) {
        return pathTestRE.test(exp) && !booleanLiteralRE.test(exp) && exp.slice(0, 5) !== 'Math.';
    }
    var expression = Object.freeze({
        parseExpression: parseExpression,
        isSimplePath: isSimplePath
    });
    var queue = [];
    var userQueue = [];
    var has = {};
    var circular = {};
    var waiting = false;
    function resetBatcherState() {
        queue.length = 0;
        userQueue.length = 0;
        has = {};
        circular = {};
        waiting = false;
    }
    function flushBatcherQueue() {
        var _again = true;
        _function:
            while (_again) {
                _again = false;
                runBatcherQueue(queue);
                runBatcherQueue(userQueue);
                if (queue.length) {
                    _again = true;
                    continue _function;
                }
                if (devtools && config.devtools) {
                    devtools.emit('flush');
                }
                resetBatcherState();
            }
    }
    function runBatcherQueue(queue) {
        for (var i = 0; i < queue.length; i++) {
            var watcher = queue[i];
            var id = watcher.id;
            has[id] = null;
            watcher.run();
            if ('development' !== 'production' && has[id] != null) {
                circular[id] = (circular[id] || 0) + 1;
                if (circular[id] > config._maxUpdateCount) {
                    warn('You may have an infinite update loop for watcher ' + 'with expression "' + watcher.expression + '"', watcher.vm);
                    break;
                }
            }
        }
        queue.length = 0;
    }
    function pushWatcher(watcher) {
        var id = watcher.id;
        if (has[id] == null) {
            var q = watcher.user ? userQueue : queue;
            has[id] = q.length;
            q.push(watcher);
            if (!waiting) {
                waiting = true;
                nextTick(flushBatcherQueue);
            }
        }
    }
    var uid$2 = 0;
    function Watcher(vm, expOrFn, cb, options) {
        if (options) {
            extend(this, options);
        }
        var isFn = typeof expOrFn === 'function';
        this.vm = vm;
        vm._watchers.push(this);
        this.expression = expOrFn;
        this.cb = cb;
        this.id = ++uid$2;
        this.active = true;
        this.dirty = this.lazy;
        this.deps = [];
        this.newDeps = [];
        this.depIds = new _Set();
        this.newDepIds = new _Set();
        this.prevError = null;
        if (isFn) {
            this.getter = expOrFn;
            this.setter = undefined;
        } else {
            var res = parseExpression(expOrFn, this.twoWay);
            this.getter = res.get;
            this.setter = res.set;
        }
        this.value = this.lazy ? undefined : this.get();
        this.queued = this.shallow = false;
    }
    Watcher.prototype.get = function () {
        this.beforeGet();
        var scope = this.scope || this.vm;
        var value;
        try {
            value = this.getter.call(scope, scope);
        } catch (e) {
            if ('development' !== 'production' && config.warnExpressionErrors) {
                warn('Error when evaluating expression ' + '"' + this.expression + '": ' + e.toString(), this.vm);
            }
        }
        if (this.deep) {
            traverse(value);
        }
        if (this.preProcess) {
            value = this.preProcess(value);
        }
        if (this.filters) {
            value = scope._applyFilters(value, null, this.filters, false);
        }
        if (this.postProcess) {
            value = this.postProcess(value);
        }
        this.afterGet();
        return value;
    };
    Watcher.prototype.set = function (value) {
        var scope = this.scope || this.vm;
        if (this.filters) {
            value = scope._applyFilters(value, this.value, this.filters, true);
        }
        try {
            this.setter.call(scope, scope, value);
        } catch (e) {
            if ('development' !== 'production' && config.warnExpressionErrors) {
                warn('Error when evaluating setter ' + '"' + this.expression + '": ' + e.toString(), this.vm);
            }
        }
        var forContext = scope.$forContext;
        if (forContext && forContext.alias === this.expression) {
            if (forContext.filters) {
                'development' !== 'production' && warn('It seems you are using two-way binding on ' + 'a v-for alias (' + this.expression + '), and the ' + 'v-for has filters. This will not work properly. ' + 'Either remove the filters or use an array of ' + 'objects and bind to object properties instead.', this.vm);
                return;
            }
            forContext._withLock(function () {
                if (scope.$key) {
                    forContext.rawValue[scope.$key] = value;
                } else {
                    forContext.rawValue.$set(scope.$index, value);
                }
            });
        }
    };
    Watcher.prototype.beforeGet = function () {
        Dep.target = this;
    };
    Watcher.prototype.addDep = function (dep) {
        var id = dep.id;
        if (!this.newDepIds.has(id)) {
            this.newDepIds.add(id);
            this.newDeps.push(dep);
            if (!this.depIds.has(id)) {
                dep.addSub(this);
            }
        }
    };
    Watcher.prototype.afterGet = function () {
        Dep.target = null;
        var i = this.deps.length;
        while (i--) {
            var dep = this.deps[i];
            if (!this.newDepIds.has(dep.id)) {
                dep.removeSub(this);
            }
        }
        var tmp = this.depIds;
        this.depIds = this.newDepIds;
        this.newDepIds = tmp;
        this.newDepIds.clear();
        tmp = this.deps;
        this.deps = this.newDeps;
        this.newDeps = tmp;
        this.newDeps.length = 0;
    };
    Watcher.prototype.update = function (shallow) {
        if (this.lazy) {
            this.dirty = true;
        } else if (this.sync || !config.async) {
            this.run();
        } else {
            this.shallow = this.queued ? shallow ? this.shallow : false : !!shallow;
            this.queued = true;
            if ('development' !== 'production' && config.debug) {
                this.prevError = new Error('[vue] async stack trace');
            }
            pushWatcher(this);
        }
    };
    Watcher.prototype.run = function () {
        if (this.active) {
            var value = this.get();
            if (value !== this.value || (isObject(value) || this.deep) && !this.shallow) {
                var oldValue = this.value;
                this.value = value;
                var prevError = this.prevError;
                if ('development' !== 'production' && config.debug && prevError) {
                    this.prevError = null;
                    try {
                        this.cb.call(this.vm, value, oldValue);
                    } catch (e) {
                        nextTick(function () {
                            throw prevError;
                        }, 0);
                        throw e;
                    }
                } else {
                    this.cb.call(this.vm, value, oldValue);
                }
            }
            this.queued = this.shallow = false;
        }
    };
    Watcher.prototype.evaluate = function () {
        var current = Dep.target;
        this.value = this.get();
        this.dirty = false;
        Dep.target = current;
    };
    Watcher.prototype.depend = function () {
        var i = this.deps.length;
        while (i--) {
            this.deps[i].depend();
        }
    };
    Watcher.prototype.teardown = function () {
        if (this.active) {
            if (!this.vm._isBeingDestroyed && !this.vm._vForRemoving) {
                this.vm._watchers.$remove(this);
            }
            var i = this.deps.length;
            while (i--) {
                this.deps[i].removeSub(this);
            }
            this.active = false;
            this.vm = this.cb = this.value = null;
        }
    };
    var seenObjects = new _Set();
    function traverse(val, seen) {
        var i = undefined, keys = undefined;
        if (!seen) {
            seen = seenObjects;
            seen.clear();
        }
        var isA = isArray(val);
        var isO = isObject(val);
        if (isA || isO) {
            if (val.__ob__) {
                var depId = val.__ob__.dep.id;
                if (seen.has(depId)) {
                    return;
                } else {
                    seen.add(depId);
                }
            }
            if (isA) {
                i = val.length;
                while (i--)
                    traverse(val[i], seen);
            } else if (isO) {
                keys = Object.keys(val);
                i = keys.length;
                while (i--)
                    traverse(val[keys[i]], seen);
            }
        }
    }
    var text$1 = {
        bind: function bind() {
            this.attr = this.el.nodeType === 3 ? 'data' : 'textContent';
        },
        update: function update(value) {
            this.el[this.attr] = _toString(value);
        }
    };
    var templateCache = new Cache(1000);
    var idSelectorCache = new Cache(1000);
    var map = {
        efault: [
            0,
            '',
            ''
        ],
        legend: [
            1,
            '<fieldset>',
            '</fieldset>'
        ],
        tr: [
            2,
            '<table><tbody>',
            '</tbody></table>'
        ],
        col: [
            2,
            '<table><tbody></tbody><colgroup>',
            '</colgroup></table>'
        ]
    };
    map.td = map.th = [
        3,
        '<table><tbody><tr>',
        '</tr></tbody></table>'
    ];
    map.option = map.optgroup = [
        1,
        '<select multiple="multiple">',
        '</select>'
    ];
    map.thead = map.tbody = map.colgroup = map.caption = map.tfoot = [
        1,
        '<table>',
        '</table>'
    ];
    map.g = map.defs = map.symbol = map.use = map.image = map.text = map.circle = map.ellipse = map.line = map.path = map.polygon = map.polyline = map.rect = [
        1,
        '<svg ' + 'xmlns="http://www.w3.org/2000/svg" ' + 'xmlns:xlink="http://www.w3.org/1999/xlink" ' + 'xmlns:ev="http://www.w3.org/2001/xml-events"' + 'version="1.1">',
        '</svg>'
    ];
    function isRealTemplate(node) {
        return isTemplate(node) && isFragment(node.content);
    }
    var tagRE$1 = /<([\w:-]+)/;
    var entityRE = /&#?\w+?;/;
    function stringToFragment(templateString, raw) {
        var cacheKey = raw ? templateString : templateString.trim();
        var hit = templateCache.get(cacheKey);
        if (hit) {
            return hit;
        }
        var frag = document.createDocumentFragment();
        var tagMatch = templateString.match(tagRE$1);
        var entityMatch = entityRE.test(templateString);
        if (!tagMatch && !entityMatch) {
            frag.appendChild(document.createTextNode(templateString));
        } else {
            var tag = tagMatch && tagMatch[1];
            var wrap = map[tag] || map.efault;
            var depth = wrap[0];
            var prefix = wrap[1];
            var suffix = wrap[2];
            var node = document.createElement('div');
            node.innerHTML = prefix + templateString + suffix;
            while (depth--) {
                node = node.lastChild;
            }
            var child;
            while (child = node.firstChild) {
                frag.appendChild(child);
            }
        }
        if (!raw) {
            trimNode(frag);
        }
        templateCache.put(cacheKey, frag);
        return frag;
    }
    function nodeToFragment(node) {
        if (isRealTemplate(node)) {
            return stringToFragment(node.innerHTML);
        }
        if (node.tagName === 'SCRIPT') {
            return stringToFragment(node.textContent);
        }
        var clonedNode = cloneNode(node);
        var frag = document.createDocumentFragment();
        var child;
        while (child = clonedNode.firstChild) {
            frag.appendChild(child);
        }
        trimNode(frag);
        return frag;
    }
    var hasBrokenTemplate = function () {
        if (inBrowser) {
            var a = document.createElement('div');
            a.innerHTML = '<template>1</template>';
            return !a.cloneNode(true).firstChild.innerHTML;
        } else {
            return false;
        }
    }();
    var hasTextareaCloneBug = function () {
        if (inBrowser) {
            var t = document.createElement('textarea');
            t.placeholder = 't';
            return t.cloneNode(true).value === 't';
        } else {
            return false;
        }
    }();
    function cloneNode(node) {
        if (!node.querySelectorAll) {
            return node.cloneNode();
        }
        var res = node.cloneNode(true);
        var i, original, cloned;
        if (hasBrokenTemplate) {
            var tempClone = res;
            if (isRealTemplate(node)) {
                node = node.content;
                tempClone = res.content;
            }
            original = node.querySelectorAll('template');
            if (original.length) {
                cloned = tempClone.querySelectorAll('template');
                i = cloned.length;
                while (i--) {
                    cloned[i].parentNode.replaceChild(cloneNode(original[i]), cloned[i]);
                }
            }
        }
        if (hasTextareaCloneBug) {
            if (node.tagName === 'TEXTAREA') {
                res.value = node.value;
            } else {
                original = node.querySelectorAll('textarea');
                if (original.length) {
                    cloned = res.querySelectorAll('textarea');
                    i = cloned.length;
                    while (i--) {
                        cloned[i].value = original[i].value;
                    }
                }
            }
        }
        return res;
    }
    function parseTemplate(template, shouldClone, raw) {
        var node, frag;
        if (isFragment(template)) {
            trimNode(template);
            return shouldClone ? cloneNode(template) : template;
        }
        if (typeof template === 'string') {
            if (!raw && template.charAt(0) === '#') {
                frag = idSelectorCache.get(template);
                if (!frag) {
                    node = document.getElementById(template.slice(1));
                    if (node) {
                        frag = nodeToFragment(node);
                        idSelectorCache.put(template, frag);
                    }
                }
            } else {
                frag = stringToFragment(template, raw);
            }
        } else if (template.nodeType) {
            frag = nodeToFragment(template);
        }
        return frag && shouldClone ? cloneNode(frag) : frag;
    }
    var template = Object.freeze({
        cloneNode: cloneNode,
        parseTemplate: parseTemplate
    });
    var html = {
        bind: function bind() {
            if (this.el.nodeType === 8) {
                this.nodes = [];
                this.anchor = createAnchor('v-html');
                replace(this.el, this.anchor);
            }
        },
        update: function update(value) {
            value = _toString(value);
            if (this.nodes) {
                this.swap(value);
            } else {
                this.el.innerHTML = value;
            }
        },
        swap: function swap(value) {
            var i = this.nodes.length;
            while (i--) {
                remove(this.nodes[i]);
            }
            var frag = parseTemplate(value, true, true);
            this.nodes = toArray(frag.childNodes);
            before(frag, this.anchor);
        }
    };
    function Fragment(linker, vm, frag, host, scope, parentFrag) {
        this.children = [];
        this.childFrags = [];
        this.vm = vm;
        this.scope = scope;
        this.inserted = false;
        this.parentFrag = parentFrag;
        if (parentFrag) {
            parentFrag.childFrags.push(this);
        }
        this.unlink = linker(vm, frag, host, scope, this);
        var single = this.single = frag.childNodes.length === 1 && !frag.childNodes[0].__v_anchor;
        if (single) {
            this.node = frag.childNodes[0];
            this.before = singleBefore;
            this.remove = singleRemove;
        } else {
            this.node = createAnchor('fragment-start');
            this.end = createAnchor('fragment-end');
            this.frag = frag;
            prepend(this.node, frag);
            frag.appendChild(this.end);
            this.before = multiBefore;
            this.remove = multiRemove;
        }
        this.node.__v_frag = this;
    }
    Fragment.prototype.callHook = function (hook) {
        var i, l;
        for (i = 0, l = this.childFrags.length; i < l; i++) {
            this.childFrags[i].callHook(hook);
        }
        for (i = 0, l = this.children.length; i < l; i++) {
            hook(this.children[i]);
        }
    };
    function singleBefore(target, withTransition) {
        this.inserted = true;
        var method = withTransition !== false ? beforeWithTransition : before;
        method(this.node, target, this.vm);
        if (inDoc(this.node)) {
            this.callHook(attach);
        }
    }
    function singleRemove() {
        this.inserted = false;
        var shouldCallRemove = inDoc(this.node);
        var self = this;
        this.beforeRemove();
        removeWithTransition(this.node, this.vm, function () {
            if (shouldCallRemove) {
                self.callHook(detach);
            }
            self.destroy();
        });
    }
    function multiBefore(target, withTransition) {
        this.inserted = true;
        var vm = this.vm;
        var method = withTransition !== false ? beforeWithTransition : before;
        mapNodeRange(this.node, this.end, function (node) {
            method(node, target, vm);
        });
        if (inDoc(this.node)) {
            this.callHook(attach);
        }
    }
    function multiRemove() {
        this.inserted = false;
        var self = this;
        var shouldCallRemove = inDoc(this.node);
        this.beforeRemove();
        removeNodeRange(this.node, this.end, this.vm, this.frag, function () {
            if (shouldCallRemove) {
                self.callHook(detach);
            }
            self.destroy();
        });
    }
    Fragment.prototype.beforeRemove = function () {
        var i, l;
        for (i = 0, l = this.childFrags.length; i < l; i++) {
            this.childFrags[i].beforeRemove(false);
        }
        for (i = 0, l = this.children.length; i < l; i++) {
            this.children[i].$destroy(false, true);
        }
        var dirs = this.unlink.dirs;
        for (i = 0, l = dirs.length; i < l; i++) {
            dirs[i]._watcher && dirs[i]._watcher.teardown();
        }
    };
    Fragment.prototype.destroy = function () {
        if (this.parentFrag) {
            this.parentFrag.childFrags.$remove(this);
        }
        this.node.__v_frag = null;
        this.unlink();
    };
    function attach(child) {
        if (!child._isAttached && inDoc(child.$el)) {
            child._callHook('attached');
        }
    }
    function detach(child) {
        if (child._isAttached && !inDoc(child.$el)) {
            child._callHook('detached');
        }
    }
    var linkerCache = new Cache(5000);
    function FragmentFactory(vm, el) {
        this.vm = vm;
        var template;
        var isString = typeof el === 'string';
        if (isString || isTemplate(el) && !el.hasAttribute('v-if')) {
            template = parseTemplate(el, true);
        } else {
            template = document.createDocumentFragment();
            template.appendChild(el);
        }
        this.template = template;
        var linker;
        var cid = vm.constructor.cid;
        if (cid > 0) {
            var cacheId = cid + (isString ? el : getOuterHTML(el));
            linker = linkerCache.get(cacheId);
            if (!linker) {
                linker = compile(template, vm.$options, true);
                linkerCache.put(cacheId, linker);
            }
        } else {
            linker = compile(template, vm.$options, true);
        }
        this.linker = linker;
    }
    FragmentFactory.prototype.create = function (host, scope, parentFrag) {
        var frag = cloneNode(this.template);
        return new Fragment(this.linker, this.vm, frag, host, scope, parentFrag);
    };
    var ON = 700;
    var MODEL = 800;
    var BIND = 850;
    var TRANSITION = 1100;
    var EL = 1500;
    var COMPONENT = 1500;
    var PARTIAL = 1750;
    var IF = 2100;
    var FOR = 2200;
    var SLOT = 2300;
    var uid$3 = 0;
    var vFor = {
        priority: FOR,
        terminal: true,
        params: [
            'track-by',
            'stagger',
            'enter-stagger',
            'leave-stagger'
        ],
        bind: function bind() {
            var inMatch = this.expression.match(/(.*) (?:in|of) (.*)/);
            if (inMatch) {
                var itMatch = inMatch[1].match(/\((.*),(.*)\)/);
                if (itMatch) {
                    this.iterator = itMatch[1].trim();
                    this.alias = itMatch[2].trim();
                } else {
                    this.alias = inMatch[1].trim();
                }
                this.expression = inMatch[2];
            }
            if (!this.alias) {
                'development' !== 'production' && warn('Invalid v-for expression "' + this.descriptor.raw + '": ' + 'alias is required.', this.vm);
                return;
            }
            this.id = '__v-for__' + ++uid$3;
            var tag = this.el.tagName;
            this.isOption = (tag === 'OPTION' || tag === 'OPTGROUP') && this.el.parentNode.tagName === 'SELECT';
            this.start = createAnchor('v-for-start');
            this.end = createAnchor('v-for-end');
            replace(this.el, this.end);
            before(this.start, this.end);
            this.cache = Object.create(null);
            this.factory = new FragmentFactory(this.vm, this.el);
        },
        update: function update(data) {
            this.diff(data);
            this.updateRef();
            this.updateModel();
        },
        diff: function diff(data) {
            var item = data[0];
            var convertedFromObject = this.fromObject = isObject(item) && hasOwn(item, '$key') && hasOwn(item, '$value');
            var trackByKey = this.params.trackBy;
            var oldFrags = this.frags;
            var frags = this.frags = new Array(data.length);
            var alias = this.alias;
            var iterator = this.iterator;
            var start = this.start;
            var end = this.end;
            var inDocument = inDoc(start);
            var init = !oldFrags;
            var i, l, frag, key, value, primitive;
            for (i = 0, l = data.length; i < l; i++) {
                item = data[i];
                key = convertedFromObject ? item.$key : null;
                value = convertedFromObject ? item.$value : item;
                primitive = !isObject(value);
                frag = !init && this.getCachedFrag(value, i, key);
                if (frag) {
                    frag.reused = true;
                    frag.scope.$index = i;
                    if (key) {
                        frag.scope.$key = key;
                    }
                    if (iterator) {
                        frag.scope[iterator] = key !== null ? key : i;
                    }
                    if (trackByKey || convertedFromObject || primitive) {
                        withoutConversion(function () {
                            frag.scope[alias] = value;
                        });
                    }
                } else {
                    frag = this.create(value, alias, i, key);
                    frag.fresh = !init;
                }
                frags[i] = frag;
                if (init) {
                    frag.before(end);
                }
            }
            if (init) {
                return;
            }
            var removalIndex = 0;
            var totalRemoved = oldFrags.length - frags.length;
            this.vm._vForRemoving = true;
            for (i = 0, l = oldFrags.length; i < l; i++) {
                frag = oldFrags[i];
                if (!frag.reused) {
                    this.deleteCachedFrag(frag);
                    this.remove(frag, removalIndex++, totalRemoved, inDocument);
                }
            }
            this.vm._vForRemoving = false;
            if (removalIndex) {
                this.vm._watchers = this.vm._watchers.filter(function (w) {
                    return w.active;
                });
            }
            var targetPrev, prevEl, currentPrev;
            var insertionIndex = 0;
            for (i = 0, l = frags.length; i < l; i++) {
                frag = frags[i];
                targetPrev = frags[i - 1];
                prevEl = targetPrev ? targetPrev.staggerCb ? targetPrev.staggerAnchor : targetPrev.end || targetPrev.node : start;
                if (frag.reused && !frag.staggerCb) {
                    currentPrev = findPrevFrag(frag, start, this.id);
                    if (currentPrev !== targetPrev && (!currentPrev || findPrevFrag(currentPrev, start, this.id) !== targetPrev)) {
                        this.move(frag, prevEl);
                    }
                } else {
                    this.insert(frag, insertionIndex++, prevEl, inDocument);
                }
                frag.reused = frag.fresh = false;
            }
        },
        create: function create(value, alias, index, key) {
            var host = this._host;
            var parentScope = this._scope || this.vm;
            var scope = Object.create(parentScope);
            scope.$refs = Object.create(parentScope.$refs);
            scope.$els = Object.create(parentScope.$els);
            scope.$parent = parentScope;
            scope.$forContext = this;
            withoutConversion(function () {
                defineReactive(scope, alias, value);
            });
            defineReactive(scope, '$index', index);
            if (key) {
                defineReactive(scope, '$key', key);
            } else if (scope.$key) {
                def(scope, '$key', null);
            }
            if (this.iterator) {
                defineReactive(scope, this.iterator, key !== null ? key : index);
            }
            var frag = this.factory.create(host, scope, this._frag);
            frag.forId = this.id;
            this.cacheFrag(value, frag, index, key);
            return frag;
        },
        updateRef: function updateRef() {
            var ref = this.descriptor.ref;
            if (!ref)
                return;
            var hash = (this._scope || this.vm).$refs;
            var refs;
            if (!this.fromObject) {
                refs = this.frags.map(findVmFromFrag);
            } else {
                refs = {};
                this.frags.forEach(function (frag) {
                    refs[frag.scope.$key] = findVmFromFrag(frag);
                });
            }
            hash[ref] = refs;
        },
        updateModel: function updateModel() {
            if (this.isOption) {
                var parent = this.start.parentNode;
                var model = parent && parent.__v_model;
                if (model) {
                    model.forceUpdate();
                }
            }
        },
        insert: function insert(frag, index, prevEl, inDocument) {
            if (frag.staggerCb) {
                frag.staggerCb.cancel();
                frag.staggerCb = null;
            }
            var staggerAmount = this.getStagger(frag, index, null, 'enter');
            if (inDocument && staggerAmount) {
                var anchor = frag.staggerAnchor;
                if (!anchor) {
                    anchor = frag.staggerAnchor = createAnchor('stagger-anchor');
                    anchor.__v_frag = frag;
                }
                after(anchor, prevEl);
                var op = frag.staggerCb = cancellable(function () {
                    frag.staggerCb = null;
                    frag.before(anchor);
                    remove(anchor);
                });
                setTimeout(op, staggerAmount);
            } else {
                var target = prevEl.nextSibling;
                if (!target) {
                    after(this.end, prevEl);
                    target = this.end;
                }
                frag.before(target);
            }
        },
        remove: function remove(frag, index, total, inDocument) {
            if (frag.staggerCb) {
                frag.staggerCb.cancel();
                frag.staggerCb = null;
                return;
            }
            var staggerAmount = this.getStagger(frag, index, total, 'leave');
            if (inDocument && staggerAmount) {
                var op = frag.staggerCb = cancellable(function () {
                    frag.staggerCb = null;
                    frag.remove();
                });
                setTimeout(op, staggerAmount);
            } else {
                frag.remove();
            }
        },
        move: function move(frag, prevEl) {
            if (!prevEl.nextSibling) {
                this.end.parentNode.appendChild(this.end);
            }
            frag.before(prevEl.nextSibling, false);
        },
        cacheFrag: function cacheFrag(value, frag, index, key) {
            var trackByKey = this.params.trackBy;
            var cache = this.cache;
            var primitive = !isObject(value);
            var id;
            if (key || trackByKey || primitive) {
                id = getTrackByKey(index, key, value, trackByKey);
                if (!cache[id]) {
                    cache[id] = frag;
                } else if (trackByKey !== '$index') {
                    'development' !== 'production' && this.warnDuplicate(value);
                }
            } else {
                id = this.id;
                if (hasOwn(value, id)) {
                    if (value[id] === null) {
                        value[id] = frag;
                    } else {
                        'development' !== 'production' && this.warnDuplicate(value);
                    }
                } else if (Object.isExtensible(value)) {
                    def(value, id, frag);
                } else if ('development' !== 'production') {
                    warn('Frozen v-for objects cannot be automatically tracked, make sure to ' + 'provide a track-by key.');
                }
            }
            frag.raw = value;
        },
        getCachedFrag: function getCachedFrag(value, index, key) {
            var trackByKey = this.params.trackBy;
            var primitive = !isObject(value);
            var frag;
            if (key || trackByKey || primitive) {
                var id = getTrackByKey(index, key, value, trackByKey);
                frag = this.cache[id];
            } else {
                frag = value[this.id];
            }
            if (frag && (frag.reused || frag.fresh)) {
                'development' !== 'production' && this.warnDuplicate(value);
            }
            return frag;
        },
        deleteCachedFrag: function deleteCachedFrag(frag) {
            var value = frag.raw;
            var trackByKey = this.params.trackBy;
            var scope = frag.scope;
            var index = scope.$index;
            var key = hasOwn(scope, '$key') && scope.$key;
            var primitive = !isObject(value);
            if (trackByKey || key || primitive) {
                var id = getTrackByKey(index, key, value, trackByKey);
                this.cache[id] = null;
            } else {
                value[this.id] = null;
                frag.raw = null;
            }
        },
        getStagger: function getStagger(frag, index, total, type) {
            type = type + 'Stagger';
            var trans = frag.node.__v_trans;
            var hooks = trans && trans.hooks;
            var hook = hooks && (hooks[type] || hooks.stagger);
            return hook ? hook.call(frag, index, total) : index * parseInt(this.params[type] || this.params.stagger, 10);
        },
        _preProcess: function _preProcess(value) {
            this.rawValue = value;
            return value;
        },
        _postProcess: function _postProcess(value) {
            if (isArray(value)) {
                return value;
            } else if (isPlainObject(value)) {
                var keys = Object.keys(value);
                var i = keys.length;
                var res = new Array(i);
                var key;
                while (i--) {
                    key = keys[i];
                    res[i] = {
                        $key: key,
                        $value: value[key]
                    };
                }
                return res;
            } else {
                if (typeof value === 'number' && !isNaN(value)) {
                    value = range(value);
                }
                return value || [];
            }
        },
        unbind: function unbind() {
            if (this.descriptor.ref) {
                (this._scope || this.vm).$refs[this.descriptor.ref] = null;
            }
            if (this.frags) {
                var i = this.frags.length;
                var frag;
                while (i--) {
                    frag = this.frags[i];
                    this.deleteCachedFrag(frag);
                    frag.destroy();
                }
            }
        }
    };
    function findPrevFrag(frag, anchor, id) {
        var el = frag.node.previousSibling;
        if (!el)
            return;
        frag = el.__v_frag;
        while ((!frag || frag.forId !== id || !frag.inserted) && el !== anchor) {
            el = el.previousSibling;
            if (!el)
                return;
            frag = el.__v_frag;
        }
        return frag;
    }
    function findVmFromFrag(frag) {
        var node = frag.node;
        if (frag.end) {
            while (!node.__vue__ && node !== frag.end && node.nextSibling) {
                node = node.nextSibling;
            }
        }
        return node.__vue__;
    }
    function range(n) {
        var i = -1;
        var ret = new Array(Math.floor(n));
        while (++i < n) {
            ret[i] = i;
        }
        return ret;
    }
    function getTrackByKey(index, key, value, trackByKey) {
        return trackByKey ? trackByKey === '$index' ? index : trackByKey.charAt(0).match(/\w/) ? getPath(value, trackByKey) : value[trackByKey] : key || value;
    }
    if ('development' !== 'production') {
        vFor.warnDuplicate = function (value) {
            warn('Duplicate value found in v-for="' + this.descriptor.raw + '": ' + JSON.stringify(value) + '. Use track-by="$index" if ' + 'you are expecting duplicate values.', this.vm);
        };
    }
    var vIf = {
        priority: IF,
        terminal: true,
        bind: function bind() {
            var el = this.el;
            if (!el.__vue__) {
                var next = el.nextElementSibling;
                if (next && getAttr(next, 'v-else') !== null) {
                    remove(next);
                    this.elseEl = next;
                }
                this.anchor = createAnchor('v-if');
                replace(el, this.anchor);
            } else {
                'development' !== 'production' && warn('v-if="' + this.expression + '" cannot be ' + 'used on an instance root element.', this.vm);
                this.invalid = true;
            }
        },
        update: function update(value) {
            if (this.invalid)
                return;
            if (value) {
                if (!this.frag) {
                    this.insert();
                }
            } else {
                this.remove();
            }
        },
        insert: function insert() {
            if (this.elseFrag) {
                this.elseFrag.remove();
                this.elseFrag = null;
            }
            if (!this.factory) {
                this.factory = new FragmentFactory(this.vm, this.el);
            }
            this.frag = this.factory.create(this._host, this._scope, this._frag);
            this.frag.before(this.anchor);
        },
        remove: function remove() {
            if (this.frag) {
                this.frag.remove();
                this.frag = null;
            }
            if (this.elseEl && !this.elseFrag) {
                if (!this.elseFactory) {
                    this.elseFactory = new FragmentFactory(this.elseEl._context || this.vm, this.elseEl);
                }
                this.elseFrag = this.elseFactory.create(this._host, this._scope, this._frag);
                this.elseFrag.before(this.anchor);
            }
        },
        unbind: function unbind() {
            if (this.frag) {
                this.frag.destroy();
            }
            if (this.elseFrag) {
                this.elseFrag.destroy();
            }
        }
    };
    var show = {
        bind: function bind() {
            var next = this.el.nextElementSibling;
            if (next && getAttr(next, 'v-else') !== null) {
                this.elseEl = next;
            }
        },
        update: function update(value) {
            this.apply(this.el, value);
            if (this.elseEl) {
                this.apply(this.elseEl, !value);
            }
        },
        apply: function apply(el, value) {
            if (inDoc(el)) {
                applyTransition(el, value ? 1 : -1, toggle, this.vm);
            } else {
                toggle();
            }
            function toggle() {
                el.style.display = value ? '' : 'none';
            }
        }
    };
    var text$2 = {
        bind: function bind() {
            var self = this;
            var el = this.el;
            var isRange = el.type === 'range';
            var lazy = this.params.lazy;
            var number = this.params.number;
            var debounce = this.params.debounce;
            var composing = false;
            if (!isAndroid && !isRange) {
                this.on('compositionstart', function () {
                    composing = true;
                });
                this.on('compositionend', function () {
                    composing = false;
                    if (!lazy) {
                        self.listener();
                    }
                });
            }
            this.focused = false;
            if (!isRange && !lazy) {
                this.on('focus', function () {
                    self.focused = true;
                });
                this.on('blur', function () {
                    self.focused = false;
                    if (!self._frag || self._frag.inserted) {
                        self.rawListener();
                    }
                });
            }
            this.listener = this.rawListener = function () {
                if (composing || !self._bound) {
                    return;
                }
                var val = number || isRange ? toNumber(el.value) : el.value;
                self.set(val);
                nextTick(function () {
                    if (self._bound && !self.focused) {
                        self.update(self._watcher.value);
                    }
                });
            };
            if (debounce) {
                this.listener = _debounce(this.listener, debounce);
            }
            this.hasjQuery = typeof jQuery === 'function';
            if (this.hasjQuery) {
                var method = jQuery.fn.on ? 'on' : 'bind';
                jQuery(el)[method]('change', this.rawListener);
                if (!lazy) {
                    jQuery(el)[method]('input', this.listener);
                }
            } else {
                this.on('change', this.rawListener);
                if (!lazy) {
                    this.on('input', this.listener);
                }
            }
            if (!lazy && isIE9) {
                this.on('cut', function () {
                    nextTick(self.listener);
                });
                this.on('keyup', function (e) {
                    if (e.keyCode === 46 || e.keyCode === 8) {
                        self.listener();
                    }
                });
            }
            if (el.hasAttribute('value') || el.tagName === 'TEXTAREA' && el.value.trim()) {
                this.afterBind = this.listener;
            }
        },
        update: function update(value) {
            this.el.value = _toString(value);
        },
        unbind: function unbind() {
            var el = this.el;
            if (this.hasjQuery) {
                var method = jQuery.fn.off ? 'off' : 'unbind';
                jQuery(el)[method]('change', this.listener);
                jQuery(el)[method]('input', this.listener);
            }
        }
    };
    var radio = {
        bind: function bind() {
            var self = this;
            var el = this.el;
            this.getValue = function () {
                if (el.hasOwnProperty('_value')) {
                    return el._value;
                }
                var val = el.value;
                if (self.params.number) {
                    val = toNumber(val);
                }
                return val;
            };
            this.listener = function () {
                self.set(self.getValue());
            };
            this.on('change', this.listener);
            if (el.hasAttribute('checked')) {
                this.afterBind = this.listener;
            }
        },
        update: function update(value) {
            this.el.checked = looseEqual(value, this.getValue());
        }
    };
    var select = {
        bind: function bind() {
            var self = this;
            var el = this.el;
            this.forceUpdate = function () {
                if (self._watcher) {
                    self.update(self._watcher.get());
                }
            };
            var multiple = this.multiple = el.hasAttribute('multiple');
            this.listener = function () {
                var value = getValue(el, multiple);
                value = self.params.number ? isArray(value) ? value.map(toNumber) : toNumber(value) : value;
                self.set(value);
            };
            this.on('change', this.listener);
            var initValue = getValue(el, multiple, true);
            if (multiple && initValue.length || !multiple && initValue !== null) {
                this.afterBind = this.listener;
            }
            this.vm.$on('hook:attached', this.forceUpdate);
        },
        update: function update(value) {
            var el = this.el;
            el.selectedIndex = -1;
            var multi = this.multiple && isArray(value);
            var options = el.options;
            var i = options.length;
            var op, val;
            while (i--) {
                op = options[i];
                val = op.hasOwnProperty('_value') ? op._value : op.value;
                op.selected = multi ? indexOf$1(value, val) > -1 : looseEqual(value, val);
            }
        },
        unbind: function unbind() {
            this.vm.$off('hook:attached', this.forceUpdate);
        }
    };
    function getValue(el, multi, init) {
        var res = multi ? [] : null;
        var op, val, selected;
        for (var i = 0, l = el.options.length; i < l; i++) {
            op = el.options[i];
            selected = init ? op.hasAttribute('selected') : op.selected;
            if (selected) {
                val = op.hasOwnProperty('_value') ? op._value : op.value;
                if (multi) {
                    res.push(val);
                } else {
                    return val;
                }
            }
        }
        return res;
    }
    function indexOf$1(arr, val) {
        var i = arr.length;
        while (i--) {
            if (looseEqual(arr[i], val)) {
                return i;
            }
        }
        return -1;
    }
    var checkbox = {
        bind: function bind() {
            var self = this;
            var el = this.el;
            this.getValue = function () {
                return el.hasOwnProperty('_value') ? el._value : self.params.number ? toNumber(el.value) : el.value;
            };
            function getBooleanValue() {
                var val = el.checked;
                if (val && el.hasOwnProperty('_trueValue')) {
                    return el._trueValue;
                }
                if (!val && el.hasOwnProperty('_falseValue')) {
                    return el._falseValue;
                }
                return val;
            }
            this.listener = function () {
                var model = self._watcher.value;
                if (isArray(model)) {
                    var val = self.getValue();
                    if (el.checked) {
                        if (indexOf(model, val) < 0) {
                            model.push(val);
                        }
                    } else {
                        model.$remove(val);
                    }
                } else {
                    self.set(getBooleanValue());
                }
            };
            this.on('change', this.listener);
            if (el.hasAttribute('checked')) {
                this.afterBind = this.listener;
            }
        },
        update: function update(value) {
            var el = this.el;
            if (isArray(value)) {
                el.checked = indexOf(value, this.getValue()) > -1;
            } else {
                if (el.hasOwnProperty('_trueValue')) {
                    el.checked = looseEqual(value, el._trueValue);
                } else {
                    el.checked = !!value;
                }
            }
        }
    };
    var handlers = {
        text: text$2,
        radio: radio,
        select: select,
        checkbox: checkbox
    };
    var model = {
        priority: MODEL,
        twoWay: true,
        handlers: handlers,
        params: [
            'lazy',
            'number',
            'debounce'
        ],
        bind: function bind() {
            this.checkFilters();
            if (this.hasRead && !this.hasWrite) {
                'development' !== 'production' && warn('It seems you are using a read-only filter with ' + 'v-model="' + this.descriptor.raw + '". ' + 'You might want to use a two-way filter to ensure correct behavior.', this.vm);
            }
            var el = this.el;
            var tag = el.tagName;
            var handler;
            if (tag === 'INPUT') {
                handler = handlers[el.type] || handlers.text;
            } else if (tag === 'SELECT') {
                handler = handlers.select;
            } else if (tag === 'TEXTAREA') {
                handler = handlers.text;
            } else {
                'development' !== 'production' && warn('v-model does not support element type: ' + tag, this.vm);
                return;
            }
            el.__v_model = this;
            handler.bind.call(this);
            this.update = handler.update;
            this._unbind = handler.unbind;
        },
        checkFilters: function checkFilters() {
            var filters = this.filters;
            if (!filters)
                return;
            var i = filters.length;
            while (i--) {
                var filter = resolveAsset(this.vm.$options, 'filters', filters[i].name);
                if (typeof filter === 'function' || filter.read) {
                    this.hasRead = true;
                }
                if (filter.write) {
                    this.hasWrite = true;
                }
            }
        },
        unbind: function unbind() {
            this.el.__v_model = null;
            this._unbind && this._unbind();
        }
    };
    var keyCodes = {
        esc: 27,
        tab: 9,
        enter: 13,
        space: 32,
        'delete': [
            8,
            46
        ],
        up: 38,
        left: 37,
        right: 39,
        down: 40
    };
    function keyFilter(handler, keys) {
        var codes = keys.map(function (key) {
            var charCode = key.charCodeAt(0);
            if (charCode > 47 && charCode < 58) {
                return parseInt(key, 10);
            }
            if (key.length === 1) {
                charCode = key.toUpperCase().charCodeAt(0);
                if (charCode > 64 && charCode < 91) {
                    return charCode;
                }
            }
            return keyCodes[key];
        });
        codes = [].concat.apply([], codes);
        return function keyHandler(e) {
            if (codes.indexOf(e.keyCode) > -1) {
                return handler.call(this, e);
            }
        };
    }
    function stopFilter(handler) {
        return function stopHandler(e) {
            e.stopPropagation();
            return handler.call(this, e);
        };
    }
    function preventFilter(handler) {
        return function preventHandler(e) {
            e.preventDefault();
            return handler.call(this, e);
        };
    }
    function selfFilter(handler) {
        return function selfHandler(e) {
            if (e.target === e.currentTarget) {
                return handler.call(this, e);
            }
        };
    }
    var on$1 = {
        priority: ON,
        acceptStatement: true,
        keyCodes: keyCodes,
        bind: function bind() {
            if (this.el.tagName === 'IFRAME' && this.arg !== 'load') {
                var self = this;
                this.iframeBind = function () {
                    on(self.el.contentWindow, self.arg, self.handler, self.modifiers.capture);
                };
                this.on('load', this.iframeBind);
            }
        },
        update: function update(handler) {
            if (!this.descriptor.raw) {
                handler = function () {
                };
            }
            if (typeof handler !== 'function') {
                'development' !== 'production' && warn('v-on:' + this.arg + '="' + this.expression + '" expects a function value, ' + 'got ' + handler, this.vm);
                return;
            }
            if (this.modifiers.stop) {
                handler = stopFilter(handler);
            }
            if (this.modifiers.prevent) {
                handler = preventFilter(handler);
            }
            if (this.modifiers.self) {
                handler = selfFilter(handler);
            }
            var keys = Object.keys(this.modifiers).filter(function (key) {
                return key !== 'stop' && key !== 'prevent' && key !== 'self' && key !== 'capture';
            });
            if (keys.length) {
                handler = keyFilter(handler, keys);
            }
            this.reset();
            this.handler = handler;
            if (this.iframeBind) {
                this.iframeBind();
            } else {
                on(this.el, this.arg, this.handler, this.modifiers.capture);
            }
        },
        reset: function reset() {
            var el = this.iframeBind ? this.el.contentWindow : this.el;
            if (this.handler) {
                off(el, this.arg, this.handler);
            }
        },
        unbind: function unbind() {
            this.reset();
        }
    };
    var prefixes = [
        '-webkit-',
        '-moz-',
        '-ms-'
    ];
    var camelPrefixes = [
        'Webkit',
        'Moz',
        'ms'
    ];
    var importantRE = /!important;?$/;
    var propCache = Object.create(null);
    var testEl = null;
    var style = {
        deep: true,
        update: function update(value) {
            if (typeof value === 'string') {
                this.el.style.cssText = value;
            } else if (isArray(value)) {
                this.handleObject(value.reduce(extend, {}));
            } else {
                this.handleObject(value || {});
            }
        },
        handleObject: function handleObject(value) {
            var cache = this.cache || (this.cache = {});
            var name, val;
            for (name in cache) {
                if (!(name in value)) {
                    this.handleSingle(name, null);
                    delete cache[name];
                }
            }
            for (name in value) {
                val = value[name];
                if (val !== cache[name]) {
                    cache[name] = val;
                    this.handleSingle(name, val);
                }
            }
        },
        handleSingle: function handleSingle(prop, value) {
            prop = normalize(prop);
            if (!prop)
                return;
            if (value != null)
                value += '';
            if (value) {
                var isImportant = importantRE.test(value) ? 'important' : '';
                if (isImportant) {
                    if ('development' !== 'production') {
                        warn('It\'s probably a bad idea to use !important with inline rules. ' + 'This feature will be deprecated in a future version of Vue.');
                    }
                    value = value.replace(importantRE, '').trim();
                    this.el.style.setProperty(prop.kebab, value, isImportant);
                } else {
                    this.el.style[prop.camel] = value;
                }
            } else {
                this.el.style[prop.camel] = '';
            }
        }
    };
    function normalize(prop) {
        if (propCache[prop]) {
            return propCache[prop];
        }
        var res = prefix(prop);
        propCache[prop] = propCache[res] = res;
        return res;
    }
    function prefix(prop) {
        prop = hyphenate(prop);
        var camel = camelize(prop);
        var upper = camel.charAt(0).toUpperCase() + camel.slice(1);
        if (!testEl) {
            testEl = document.createElement('div');
        }
        var i = prefixes.length;
        var prefixed;
        if (camel !== 'filter' && camel in testEl.style) {
            return {
                kebab: prop,
                camel: camel
            };
        }
        while (i--) {
            prefixed = camelPrefixes[i] + upper;
            if (prefixed in testEl.style) {
                return {
                    kebab: prefixes[i] + prop,
                    camel: prefixed
                };
            }
        }
    }
    var xlinkNS = 'http://www.w3.org/1999/xlink';
    var xlinkRE = /^xlink:/;
    var disallowedInterpAttrRE = /^v-|^:|^@|^(?:is|transition|transition-mode|debounce|track-by|stagger|enter-stagger|leave-stagger)$/;
    var attrWithPropsRE = /^(?:value|checked|selected|muted)$/;
    var enumeratedAttrRE = /^(?:draggable|contenteditable|spellcheck)$/;
    var modelProps = {
        value: '_value',
        'true-value': '_trueValue',
        'false-value': '_falseValue'
    };
    var bind$1 = {
        priority: BIND,
        bind: function bind() {
            var attr = this.arg;
            var tag = this.el.tagName;
            if (!attr) {
                this.deep = true;
            }
            var descriptor = this.descriptor;
            var tokens = descriptor.interp;
            if (tokens) {
                if (descriptor.hasOneTime) {
                    this.expression = tokensToExp(tokens, this._scope || this.vm);
                }
                if (disallowedInterpAttrRE.test(attr) || attr === 'name' && (tag === 'PARTIAL' || tag === 'SLOT')) {
                    'development' !== 'production' && warn(attr + '="' + descriptor.raw + '": ' + 'attribute interpolation is not allowed in Vue.js ' + 'directives and special attributes.', this.vm);
                    this.el.removeAttribute(attr);
                    this.invalid = true;
                }
                if ('development' !== 'production') {
                    var raw = attr + '="' + descriptor.raw + '": ';
                    if (attr === 'src') {
                        warn(raw + 'interpolation in "src" attribute will cause ' + 'a 404 request. Use v-bind:src instead.', this.vm);
                    }
                    if (attr === 'style') {
                        warn(raw + 'interpolation in "style" attribute will cause ' + 'the attribute to be discarded in Internet Explorer. ' + 'Use v-bind:style instead.', this.vm);
                    }
                }
            }
        },
        update: function update(value) {
            if (this.invalid) {
                return;
            }
            var attr = this.arg;
            if (this.arg) {
                this.handleSingle(attr, value);
            } else {
                this.handleObject(value || {});
            }
        },
        handleObject: style.handleObject,
        handleSingle: function handleSingle(attr, value) {
            var el = this.el;
            var interp = this.descriptor.interp;
            if (this.modifiers.camel) {
                attr = camelize(attr);
            }
            if (!interp && attrWithPropsRE.test(attr) && attr in el) {
                var attrValue = attr === 'value' ? value == null ? '' : value : value;
                if (el[attr] !== attrValue) {
                    el[attr] = attrValue;
                }
            }
            var modelProp = modelProps[attr];
            if (!interp && modelProp) {
                el[modelProp] = value;
                var model = el.__v_model;
                if (model) {
                    model.listener();
                }
            }
            if (attr === 'value' && el.tagName === 'TEXTAREA') {
                el.removeAttribute(attr);
                return;
            }
            if (enumeratedAttrRE.test(attr)) {
                el.setAttribute(attr, value ? 'true' : 'false');
            } else if (value != null && value !== false) {
                if (attr === 'class') {
                    if (el.__v_trans) {
                        value += ' ' + el.__v_trans.id + '-transition';
                    }
                    setClass(el, value);
                } else if (xlinkRE.test(attr)) {
                    el.setAttributeNS(xlinkNS, attr, value === true ? '' : value);
                } else {
                    el.setAttribute(attr, value === true ? '' : value);
                }
            } else {
                el.removeAttribute(attr);
            }
        }
    };
    var el = {
        priority: EL,
        bind: function bind() {
            if (!this.arg) {
                return;
            }
            var id = this.id = camelize(this.arg);
            var refs = (this._scope || this.vm).$els;
            if (hasOwn(refs, id)) {
                refs[id] = this.el;
            } else {
                defineReactive(refs, id, this.el);
            }
        },
        unbind: function unbind() {
            var refs = (this._scope || this.vm).$els;
            if (refs[this.id] === this.el) {
                refs[this.id] = null;
            }
        }
    };
    var ref = {
        bind: function bind() {
            'development' !== 'production' && warn('v-ref:' + this.arg + ' must be used on a child ' + 'component. Found on <' + this.el.tagName.toLowerCase() + '>.', this.vm);
        }
    };
    var cloak = {
        bind: function bind() {
            var el = this.el;
            this.vm.$once('pre-hook:compiled', function () {
                el.removeAttribute('v-cloak');
            });
        }
    };
    var directives = {
        text: text$1,
        html: html,
        'for': vFor,
        'if': vIf,
        show: show,
        model: model,
        on: on$1,
        bind: bind$1,
        el: el,
        ref: ref,
        cloak: cloak
    };
    var vClass = {
        deep: true,
        update: function update(value) {
            if (!value) {
                this.cleanup();
            } else if (typeof value === 'string') {
                this.setClass(value.trim().split(/\s+/));
            } else {
                this.setClass(normalize$1(value));
            }
        },
        setClass: function setClass(value) {
            this.cleanup(value);
            for (var i = 0, l = value.length; i < l; i++) {
                var val = value[i];
                if (val) {
                    apply(this.el, val, addClass);
                }
            }
            this.prevKeys = value;
        },
        cleanup: function cleanup(value) {
            var prevKeys = this.prevKeys;
            if (!prevKeys)
                return;
            var i = prevKeys.length;
            while (i--) {
                var key = prevKeys[i];
                if (!value || value.indexOf(key) < 0) {
                    apply(this.el, key, removeClass);
                }
            }
        }
    };
    function normalize$1(value) {
        var res = [];
        if (isArray(value)) {
            for (var i = 0, l = value.length; i < l; i++) {
                var _key = value[i];
                if (_key) {
                    if (typeof _key === 'string') {
                        res.push(_key);
                    } else {
                        for (var k in _key) {
                            if (_key[k])
                                res.push(k);
                        }
                    }
                }
            }
        } else if (isObject(value)) {
            for (var key in value) {
                if (value[key])
                    res.push(key);
            }
        }
        return res;
    }
    function apply(el, key, fn) {
        key = key.trim();
        if (key.indexOf(' ') === -1) {
            fn(el, key);
            return;
        }
        var keys = key.split(/\s+/);
        for (var i = 0, l = keys.length; i < l; i++) {
            fn(el, keys[i]);
        }
    }
    var component = {
        priority: COMPONENT,
        params: [
            'keep-alive',
            'transition-mode',
            'inline-template'
        ],
        bind: function bind() {
            if (!this.el.__vue__) {
                this.keepAlive = this.params.keepAlive;
                if (this.keepAlive) {
                    this.cache = {};
                }
                if (this.params.inlineTemplate) {
                    this.inlineTemplate = extractContent(this.el, true);
                }
                this.pendingComponentCb = this.Component = null;
                this.pendingRemovals = 0;
                this.pendingRemovalCb = null;
                this.anchor = createAnchor('v-component');
                replace(this.el, this.anchor);
                this.el.removeAttribute('is');
                this.el.removeAttribute(':is');
                if (this.descriptor.ref) {
                    this.el.removeAttribute('v-ref:' + hyphenate(this.descriptor.ref));
                }
                if (this.literal) {
                    this.setComponent(this.expression);
                }
            } else {
                'development' !== 'production' && warn('cannot mount component "' + this.expression + '" ' + 'on already mounted element: ' + this.el);
            }
        },
        update: function update(value) {
            if (!this.literal) {
                this.setComponent(value);
            }
        },
        setComponent: function setComponent(value, cb) {
            this.invalidatePending();
            if (!value) {
                this.unbuild(true);
                this.remove(this.childVM, cb);
                this.childVM = null;
            } else {
                var self = this;
                this.resolveComponent(value, function () {
                    self.mountComponent(cb);
                });
            }
        },
        resolveComponent: function resolveComponent(value, cb) {
            var self = this;
            this.pendingComponentCb = cancellable(function (Component) {
                self.ComponentName = Component.options.name || (typeof value === 'string' ? value : null);
                self.Component = Component;
                cb();
            });
            this.vm._resolveComponent(value, this.pendingComponentCb);
        },
        mountComponent: function mountComponent(cb) {
            this.unbuild(true);
            var self = this;
            var activateHooks = this.Component.options.activate;
            var cached = this.getCached();
            var newComponent = this.build();
            if (activateHooks && !cached) {
                this.waitingFor = newComponent;
                callActivateHooks(activateHooks, newComponent, function () {
                    if (self.waitingFor !== newComponent) {
                        return;
                    }
                    self.waitingFor = null;
                    self.transition(newComponent, cb);
                });
            } else {
                if (cached) {
                    newComponent._updateRef();
                }
                this.transition(newComponent, cb);
            }
        },
        invalidatePending: function invalidatePending() {
            if (this.pendingComponentCb) {
                this.pendingComponentCb.cancel();
                this.pendingComponentCb = null;
            }
        },
        build: function build(extraOptions) {
            var cached = this.getCached();
            if (cached) {
                return cached;
            }
            if (this.Component) {
                var options = {
                    name: this.ComponentName,
                    el: cloneNode(this.el),
                    template: this.inlineTemplate,
                    parent: this._host || this.vm,
                    _linkerCachable: !this.inlineTemplate,
                    _ref: this.descriptor.ref,
                    _asComponent: true,
                    _isRouterView: this._isRouterView,
                    _context: this.vm,
                    _scope: this._scope,
                    _frag: this._frag
                };
                if (extraOptions) {
                    extend(options, extraOptions);
                }
                var child = new this.Component(options);
                if (this.keepAlive) {
                    this.cache[this.Component.cid] = child;
                }
                if ('development' !== 'production' && this.el.hasAttribute('transition') && child._isFragment) {
                    warn('Transitions will not work on a fragment instance. ' + 'Template: ' + child.$options.template, child);
                }
                return child;
            }
        },
        getCached: function getCached() {
            return this.keepAlive && this.cache[this.Component.cid];
        },
        unbuild: function unbuild(defer) {
            if (this.waitingFor) {
                if (!this.keepAlive) {
                    this.waitingFor.$destroy();
                }
                this.waitingFor = null;
            }
            var child = this.childVM;
            if (!child || this.keepAlive) {
                if (child) {
                    child._inactive = true;
                    child._updateRef(true);
                }
                return;
            }
            child.$destroy(false, defer);
        },
        remove: function remove(child, cb) {
            var keepAlive = this.keepAlive;
            if (child) {
                this.pendingRemovals++;
                this.pendingRemovalCb = cb;
                var self = this;
                child.$remove(function () {
                    self.pendingRemovals--;
                    if (!keepAlive)
                        child._cleanup();
                    if (!self.pendingRemovals && self.pendingRemovalCb) {
                        self.pendingRemovalCb();
                        self.pendingRemovalCb = null;
                    }
                });
            } else if (cb) {
                cb();
            }
        },
        transition: function transition(target, cb) {
            var self = this;
            var current = this.childVM;
            if (current)
                current._inactive = true;
            target._inactive = false;
            this.childVM = target;
            switch (self.params.transitionMode) {
            case 'in-out':
                target.$before(self.anchor, function () {
                    self.remove(current, cb);
                });
                break;
            case 'out-in':
                self.remove(current, function () {
                    target.$before(self.anchor, cb);
                });
                break;
            default:
                self.remove(current);
                target.$before(self.anchor, cb);
            }
        },
        unbind: function unbind() {
            this.invalidatePending();
            this.unbuild();
            if (this.cache) {
                for (var key in this.cache) {
                    this.cache[key].$destroy();
                }
                this.cache = null;
            }
        }
    };
    function callActivateHooks(hooks, vm, cb) {
        var total = hooks.length;
        var called = 0;
        hooks[0].call(vm, next);
        function next() {
            if (++called >= total) {
                cb();
            } else {
                hooks[called].call(vm, next);
            }
        }
    }
    var propBindingModes = config._propBindingModes;
    var empty = {};
    var identRE$1 = /^[$_a-zA-Z]+[\w$]*$/;
    var settablePathRE = /^[A-Za-z_$][\w$]*(\.[A-Za-z_$][\w$]*|\[[^\[\]]+\])*$/;
    function compileProps(el, propOptions, vm) {
        var props = [];
        var names = Object.keys(propOptions);
        var i = names.length;
        var options, name, attr, value, path, parsed, prop;
        while (i--) {
            name = names[i];
            options = propOptions[name] || empty;
            if ('development' !== 'production' && name === '$data') {
                warn('Do not use $data as prop.', vm);
                continue;
            }
            path = camelize(name);
            if (!identRE$1.test(path)) {
                'development' !== 'production' && warn('Invalid prop key: "' + name + '". Prop keys ' + 'must be valid identifiers.', vm);
                continue;
            }
            prop = {
                name: name,
                path: path,
                options: options,
                mode: propBindingModes.ONE_WAY,
                raw: null
            };
            attr = hyphenate(name);
            if ((value = getBindAttr(el, attr)) === null) {
                if ((value = getBindAttr(el, attr + '.sync')) !== null) {
                    prop.mode = propBindingModes.TWO_WAY;
                } else if ((value = getBindAttr(el, attr + '.once')) !== null) {
                    prop.mode = propBindingModes.ONE_TIME;
                }
            }
            if (value !== null) {
                prop.raw = value;
                parsed = parseDirective(value);
                value = parsed.expression;
                prop.filters = parsed.filters;
                if (isLiteral(value) && !parsed.filters) {
                    prop.optimizedLiteral = true;
                } else {
                    prop.dynamic = true;
                    if ('development' !== 'production' && prop.mode === propBindingModes.TWO_WAY && !settablePathRE.test(value)) {
                        prop.mode = propBindingModes.ONE_WAY;
                        warn('Cannot bind two-way prop with non-settable ' + 'parent path: ' + value, vm);
                    }
                }
                prop.parentPath = value;
                if ('development' !== 'production' && options.twoWay && prop.mode !== propBindingModes.TWO_WAY) {
                    warn('Prop "' + name + '" expects a two-way binding type.', vm);
                }
            } else if ((value = getAttr(el, attr)) !== null) {
                prop.raw = value;
            } else if ('development' !== 'production') {
                var lowerCaseName = path.toLowerCase();
                value = /[A-Z\-]/.test(name) && (el.getAttribute(lowerCaseName) || el.getAttribute(':' + lowerCaseName) || el.getAttribute('v-bind:' + lowerCaseName) || el.getAttribute(':' + lowerCaseName + '.once') || el.getAttribute('v-bind:' + lowerCaseName + '.once') || el.getAttribute(':' + lowerCaseName + '.sync') || el.getAttribute('v-bind:' + lowerCaseName + '.sync'));
                if (value) {
                    warn('Possible usage error for prop `' + lowerCaseName + '` - ' + 'did you mean `' + attr + '`? HTML is case-insensitive, remember to use ' + 'kebab-case for props in templates.', vm);
                } else if (options.required) {
                    warn('Missing required prop: ' + name, vm);
                }
            }
            props.push(prop);
        }
        return makePropsLinkFn(props);
    }
    function makePropsLinkFn(props) {
        return function propsLinkFn(vm, scope) {
            vm._props = {};
            var inlineProps = vm.$options.propsData;
            var i = props.length;
            var prop, path, options, value, raw;
            while (i--) {
                prop = props[i];
                raw = prop.raw;
                path = prop.path;
                options = prop.options;
                vm._props[path] = prop;
                if (inlineProps && hasOwn(inlineProps, path)) {
                    initProp(vm, prop, inlineProps[path]);
                }
                if (raw === null) {
                    initProp(vm, prop, undefined);
                } else if (prop.dynamic) {
                    if (prop.mode === propBindingModes.ONE_TIME) {
                        value = (scope || vm._context || vm).$get(prop.parentPath);
                        initProp(vm, prop, value);
                    } else {
                        if (vm._context) {
                            vm._bindDir({
                                name: 'prop',
                                def: propDef,
                                prop: prop
                            }, null, null, scope);
                        } else {
                            initProp(vm, prop, vm.$get(prop.parentPath));
                        }
                    }
                } else if (prop.optimizedLiteral) {
                    var stripped = stripQuotes(raw);
                    value = stripped === raw ? toBoolean(toNumber(raw)) : stripped;
                    initProp(vm, prop, value);
                } else {
                    value = options.type === Boolean && (raw === '' || raw === hyphenate(prop.name)) ? true : raw;
                    initProp(vm, prop, value);
                }
            }
        };
    }
    function processPropValue(vm, prop, rawValue, fn) {
        var isSimple = prop.dynamic && isSimplePath(prop.parentPath);
        var value = rawValue;
        if (value === undefined) {
            value = getPropDefaultValue(vm, prop);
        }
        value = coerceProp(prop, value);
        var coerced = value !== rawValue;
        if (!assertProp(prop, value, vm)) {
            value = undefined;
        }
        if (isSimple && !coerced) {
            withoutConversion(function () {
                fn(value);
            });
        } else {
            fn(value);
        }
    }
    function initProp(vm, prop, value) {
        processPropValue(vm, prop, value, function (value) {
            defineReactive(vm, prop.path, value);
        });
    }
    function updateProp(vm, prop, value) {
        processPropValue(vm, prop, value, function (value) {
            vm[prop.path] = value;
        });
    }
    function getPropDefaultValue(vm, prop) {
        var options = prop.options;
        if (!hasOwn(options, 'default')) {
            return options.type === Boolean ? false : undefined;
        }
        var def = options['default'];
        if (isObject(def)) {
            'development' !== 'production' && warn('Invalid default value for prop "' + prop.name + '": ' + 'Props with type Object/Array must use a factory function ' + 'to return the default value.', vm);
        }
        return typeof def === 'function' && options.type !== Function ? def.call(vm) : def;
    }
    function assertProp(prop, value, vm) {
        if (!prop.options.required && (prop.raw === null || value == null)) {
            return true;
        }
        var options = prop.options;
        var type = options.type;
        var valid = !type;
        var expectedTypes = [];
        if (type) {
            if (!isArray(type)) {
                type = [type];
            }
            for (var i = 0; i < type.length && !valid; i++) {
                var assertedType = assertType(value, type[i]);
                expectedTypes.push(assertedType.expectedType);
                valid = assertedType.valid;
            }
        }
        if (!valid) {
            if ('development' !== 'production') {
                warn('Invalid prop: type check failed for prop "' + prop.name + '".' + ' Expected ' + expectedTypes.map(formatType).join(', ') + ', got ' + formatValue(value) + '.', vm);
            }
            return false;
        }
        var validator = options.validator;
        if (validator) {
            if (!validator(value)) {
                'development' !== 'production' && warn('Invalid prop: custom validator check failed for prop "' + prop.name + '".', vm);
                return false;
            }
        }
        return true;
    }
    function coerceProp(prop, value) {
        var coerce = prop.options.coerce;
        if (!coerce) {
            return value;
        }
        return coerce(value);
    }
    function assertType(value, type) {
        var valid;
        var expectedType;
        if (type === String) {
            expectedType = 'string';
            valid = typeof value === expectedType;
        } else if (type === Number) {
            expectedType = 'number';
            valid = typeof value === expectedType;
        } else if (type === Boolean) {
            expectedType = 'boolean';
            valid = typeof value === expectedType;
        } else if (type === Function) {
            expectedType = 'function';
            valid = typeof value === expectedType;
        } else if (type === Object) {
            expectedType = 'object';
            valid = isPlainObject(value);
        } else if (type === Array) {
            expectedType = 'array';
            valid = isArray(value);
        } else {
            valid = value instanceof type;
        }
        return {
            valid: valid,
            expectedType: expectedType
        };
    }
    function formatType(type) {
        return type ? type.charAt(0).toUpperCase() + type.slice(1) : 'custom type';
    }
    function formatValue(val) {
        return Object.prototype.toString.call(val).slice(8, -1);
    }
    var bindingModes = config._propBindingModes;
    var propDef = {
        bind: function bind() {
            var child = this.vm;
            var parent = child._context;
            var prop = this.descriptor.prop;
            var childKey = prop.path;
            var parentKey = prop.parentPath;
            var twoWay = prop.mode === bindingModes.TWO_WAY;
            var parentWatcher = this.parentWatcher = new Watcher(parent, parentKey, function (val) {
                updateProp(child, prop, val);
            }, {
                twoWay: twoWay,
                filters: prop.filters,
                scope: this._scope
            });
            initProp(child, prop, parentWatcher.value);
            if (twoWay) {
                var self = this;
                child.$once('pre-hook:created', function () {
                    self.childWatcher = new Watcher(child, childKey, function (val) {
                        parentWatcher.set(val);
                    }, { sync: true });
                });
            }
        },
        unbind: function unbind() {
            this.parentWatcher.teardown();
            if (this.childWatcher) {
                this.childWatcher.teardown();
            }
        }
    };
    var queue$1 = [];
    var queued = false;
    function pushJob(job) {
        queue$1.push(job);
        if (!queued) {
            queued = true;
            nextTick(flush);
        }
    }
    function flush() {
        var f = document.documentElement.offsetHeight;
        for (var i = 0; i < queue$1.length; i++) {
            queue$1[i]();
        }
        queue$1 = [];
        queued = false;
        return f;
    }
    var TYPE_TRANSITION = 'transition';
    var TYPE_ANIMATION = 'animation';
    var transDurationProp = transitionProp + 'Duration';
    var animDurationProp = animationProp + 'Duration';
    var raf = inBrowser && window.requestAnimationFrame;
    var waitForTransitionStart = raf ? function (fn) {
        raf(function () {
            raf(fn);
        });
    } : function (fn) {
        setTimeout(fn, 50);
    };
    function Transition(el, id, hooks, vm) {
        this.id = id;
        this.el = el;
        this.enterClass = hooks && hooks.enterClass || id + '-enter';
        this.leaveClass = hooks && hooks.leaveClass || id + '-leave';
        this.hooks = hooks;
        this.vm = vm;
        this.pendingCssEvent = this.pendingCssCb = this.cancel = this.pendingJsCb = this.op = this.cb = null;
        this.justEntered = false;
        this.entered = this.left = false;
        this.typeCache = {};
        this.type = hooks && hooks.type;
        if ('development' !== 'production') {
            if (this.type && this.type !== TYPE_TRANSITION && this.type !== TYPE_ANIMATION) {
                warn('invalid CSS transition type for transition="' + this.id + '": ' + this.type, vm);
            }
        }
        var self = this;
        [
            'enterNextTick',
            'enterDone',
            'leaveNextTick',
            'leaveDone'
        ].forEach(function (m) {
            self[m] = bind(self[m], self);
        });
    }
    var p$1 = Transition.prototype;
    p$1.enter = function (op, cb) {
        this.cancelPending();
        this.callHook('beforeEnter');
        this.cb = cb;
        addClass(this.el, this.enterClass);
        op();
        this.entered = false;
        this.callHookWithCb('enter');
        if (this.entered) {
            return;
        }
        this.cancel = this.hooks && this.hooks.enterCancelled;
        pushJob(this.enterNextTick);
    };
    p$1.enterNextTick = function () {
        var _this = this;
        this.justEntered = true;
        waitForTransitionStart(function () {
            _this.justEntered = false;
        });
        var enterDone = this.enterDone;
        var type = this.getCssTransitionType(this.enterClass);
        if (!this.pendingJsCb) {
            if (type === TYPE_TRANSITION) {
                removeClass(this.el, this.enterClass);
                this.setupCssCb(transitionEndEvent, enterDone);
            } else if (type === TYPE_ANIMATION) {
                this.setupCssCb(animationEndEvent, enterDone);
            } else {
                enterDone();
            }
        } else if (type === TYPE_TRANSITION) {
            removeClass(this.el, this.enterClass);
        }
    };
    p$1.enterDone = function () {
        this.entered = true;
        this.cancel = this.pendingJsCb = null;
        removeClass(this.el, this.enterClass);
        this.callHook('afterEnter');
        if (this.cb)
            this.cb();
    };
    p$1.leave = function (op, cb) {
        this.cancelPending();
        this.callHook('beforeLeave');
        this.op = op;
        this.cb = cb;
        addClass(this.el, this.leaveClass);
        this.left = false;
        this.callHookWithCb('leave');
        if (this.left) {
            return;
        }
        this.cancel = this.hooks && this.hooks.leaveCancelled;
        if (this.op && !this.pendingJsCb) {
            if (this.justEntered) {
                this.leaveDone();
            } else {
                pushJob(this.leaveNextTick);
            }
        }
    };
    p$1.leaveNextTick = function () {
        var type = this.getCssTransitionType(this.leaveClass);
        if (type) {
            var event = type === TYPE_TRANSITION ? transitionEndEvent : animationEndEvent;
            this.setupCssCb(event, this.leaveDone);
        } else {
            this.leaveDone();
        }
    };
    p$1.leaveDone = function () {
        this.left = true;
        this.cancel = this.pendingJsCb = null;
        this.op();
        removeClass(this.el, this.leaveClass);
        this.callHook('afterLeave');
        if (this.cb)
            this.cb();
        this.op = null;
    };
    p$1.cancelPending = function () {
        this.op = this.cb = null;
        var hasPending = false;
        if (this.pendingCssCb) {
            hasPending = true;
            off(this.el, this.pendingCssEvent, this.pendingCssCb);
            this.pendingCssEvent = this.pendingCssCb = null;
        }
        if (this.pendingJsCb) {
            hasPending = true;
            this.pendingJsCb.cancel();
            this.pendingJsCb = null;
        }
        if (hasPending) {
            removeClass(this.el, this.enterClass);
            removeClass(this.el, this.leaveClass);
        }
        if (this.cancel) {
            this.cancel.call(this.vm, this.el);
            this.cancel = null;
        }
    };
    p$1.callHook = function (type) {
        if (this.hooks && this.hooks[type]) {
            this.hooks[type].call(this.vm, this.el);
        }
    };
    p$1.callHookWithCb = function (type) {
        var hook = this.hooks && this.hooks[type];
        if (hook) {
            if (hook.length > 1) {
                this.pendingJsCb = cancellable(this[type + 'Done']);
            }
            hook.call(this.vm, this.el, this.pendingJsCb);
        }
    };
    p$1.getCssTransitionType = function (className) {
        if (!transitionEndEvent || document.hidden || this.hooks && this.hooks.css === false || isHidden(this.el)) {
            return;
        }
        var type = this.type || this.typeCache[className];
        if (type)
            return type;
        var inlineStyles = this.el.style;
        var computedStyles = window.getComputedStyle(this.el);
        var transDuration = inlineStyles[transDurationProp] || computedStyles[transDurationProp];
        if (transDuration && transDuration !== '0s') {
            type = TYPE_TRANSITION;
        } else {
            var animDuration = inlineStyles[animDurationProp] || computedStyles[animDurationProp];
            if (animDuration && animDuration !== '0s') {
                type = TYPE_ANIMATION;
            }
        }
        if (type) {
            this.typeCache[className] = type;
        }
        return type;
    };
    p$1.setupCssCb = function (event, cb) {
        this.pendingCssEvent = event;
        var self = this;
        var el = this.el;
        var onEnd = this.pendingCssCb = function (e) {
            if (e.target === el) {
                off(el, event, onEnd);
                self.pendingCssEvent = self.pendingCssCb = null;
                if (!self.pendingJsCb && cb) {
                    cb();
                }
            }
        };
        on(el, event, onEnd);
    };
    function isHidden(el) {
        if (/svg$/.test(el.namespaceURI)) {
            var rect = el.getBoundingClientRect();
            return !(rect.width || rect.height);
        } else {
            return !(el.offsetWidth || el.offsetHeight || el.getClientRects().length);
        }
    }
    var transition$1 = {
        priority: TRANSITION,
        update: function update(id, oldId) {
            var el = this.el;
            var hooks = resolveAsset(this.vm.$options, 'transitions', id);
            id = id || 'v';
            el.__v_trans = new Transition(el, id, hooks, this.vm);
            if (oldId) {
                removeClass(el, oldId + '-transition');
            }
            addClass(el, id + '-transition');
        }
    };
    var internalDirectives = {
        style: style,
        'class': vClass,
        component: component,
        prop: propDef,
        transition: transition$1
    };
    var bindRE = /^v-bind:|^:/;
    var onRE = /^v-on:|^@/;
    var dirAttrRE = /^v-([^:]+)(?:$|:(.*)$)/;
    var modifierRE = /\.[^\.]+/g;
    var transitionRE = /^(v-bind:|:)?transition$/;
    var DEFAULT_PRIORITY = 1000;
    var DEFAULT_TERMINAL_PRIORITY = 2000;
    function compile(el, options, partial) {
        var nodeLinkFn = partial || !options._asComponent ? compileNode(el, options) : null;
        var childLinkFn = !(nodeLinkFn && nodeLinkFn.terminal) && !isScript(el) && el.hasChildNodes() ? compileNodeList(el.childNodes, options) : null;
        return function compositeLinkFn(vm, el, host, scope, frag) {
            var childNodes = toArray(el.childNodes);
            var dirs = linkAndCapture(function compositeLinkCapturer() {
                if (nodeLinkFn)
                    nodeLinkFn(vm, el, host, scope, frag);
                if (childLinkFn)
                    childLinkFn(vm, childNodes, host, scope, frag);
            }, vm);
            return makeUnlinkFn(vm, dirs);
        };
    }
    function linkAndCapture(linker, vm) {
        if ('development' === 'production') {
        }
        var originalDirCount = vm._directives.length;
        linker();
        var dirs = vm._directives.slice(originalDirCount);
        dirs.sort(directiveComparator);
        for (var i = 0, l = dirs.length; i < l; i++) {
            dirs[i]._bind();
        }
        return dirs;
    }
    function directiveComparator(a, b) {
        a = a.descriptor.def.priority || DEFAULT_PRIORITY;
        b = b.descriptor.def.priority || DEFAULT_PRIORITY;
        return a > b ? -1 : a === b ? 0 : 1;
    }
    function makeUnlinkFn(vm, dirs, context, contextDirs) {
        function unlink(destroying) {
            teardownDirs(vm, dirs, destroying);
            if (context && contextDirs) {
                teardownDirs(context, contextDirs);
            }
        }
        unlink.dirs = dirs;
        return unlink;
    }
    function teardownDirs(vm, dirs, destroying) {
        var i = dirs.length;
        while (i--) {
            dirs[i]._teardown();
            if ('development' !== 'production' && !destroying) {
                vm._directives.$remove(dirs[i]);
            }
        }
    }
    function compileAndLinkProps(vm, el, props, scope) {
        var propsLinkFn = compileProps(el, props, vm);
        var propDirs = linkAndCapture(function () {
            propsLinkFn(vm, scope);
        }, vm);
        return makeUnlinkFn(vm, propDirs);
    }
    function compileRoot(el, options, contextOptions) {
        var containerAttrs = options._containerAttrs;
        var replacerAttrs = options._replacerAttrs;
        var contextLinkFn, replacerLinkFn;
        if (el.nodeType !== 11) {
            if (options._asComponent) {
                if (containerAttrs && contextOptions) {
                    contextLinkFn = compileDirectives(containerAttrs, contextOptions);
                }
                if (replacerAttrs) {
                    replacerLinkFn = compileDirectives(replacerAttrs, options);
                }
            } else {
                replacerLinkFn = compileDirectives(el.attributes, options);
            }
        } else if ('development' !== 'production' && containerAttrs) {
            var names = containerAttrs.filter(function (attr) {
                return attr.name.indexOf('_v-') < 0 && !onRE.test(attr.name) && attr.name !== 'slot';
            }).map(function (attr) {
                return '"' + attr.name + '"';
            });
            if (names.length) {
                var plural = names.length > 1;
                warn('Attribute' + (plural ? 's ' : ' ') + names.join(', ') + (plural ? ' are' : ' is') + ' ignored on component ' + '<' + options.el.tagName.toLowerCase() + '> because ' + 'the component is a fragment instance: ' + 'http://vuejs.org/guide/components.html#Fragment-Instance');
            }
        }
        options._containerAttrs = options._replacerAttrs = null;
        return function rootLinkFn(vm, el, scope) {
            var context = vm._context;
            var contextDirs;
            if (context && contextLinkFn) {
                contextDirs = linkAndCapture(function () {
                    contextLinkFn(context, el, null, scope);
                }, context);
            }
            var selfDirs = linkAndCapture(function () {
                if (replacerLinkFn)
                    replacerLinkFn(vm, el);
            }, vm);
            return makeUnlinkFn(vm, selfDirs, context, contextDirs);
        };
    }
    function compileNode(node, options) {
        var type = node.nodeType;
        if (type === 1 && !isScript(node)) {
            return compileElement(node, options);
        } else if (type === 3 && node.data.trim()) {
            return compileTextNode(node, options);
        } else {
            return null;
        }
    }
    function compileElement(el, options) {
        if (el.tagName === 'TEXTAREA') {
            var tokens = parseText(el.value);
            if (tokens) {
                el.setAttribute(':value', tokensToExp(tokens));
                el.value = '';
            }
        }
        var linkFn;
        var hasAttrs = el.hasAttributes();
        var attrs = hasAttrs && toArray(el.attributes);
        if (hasAttrs) {
            linkFn = checkTerminalDirectives(el, attrs, options);
        }
        if (!linkFn) {
            linkFn = checkElementDirectives(el, options);
        }
        if (!linkFn) {
            linkFn = checkComponent(el, options);
        }
        if (!linkFn && hasAttrs) {
            linkFn = compileDirectives(attrs, options);
        }
        return linkFn;
    }
    function compileTextNode(node, options) {
        if (node._skip) {
            return removeText;
        }
        var tokens = parseText(node.wholeText);
        if (!tokens) {
            return null;
        }
        var next = node.nextSibling;
        while (next && next.nodeType === 3) {
            next._skip = true;
            next = next.nextSibling;
        }
        var frag = document.createDocumentFragment();
        var el, token;
        for (var i = 0, l = tokens.length; i < l; i++) {
            token = tokens[i];
            el = token.tag ? processTextToken(token, options) : document.createTextNode(token.value);
            frag.appendChild(el);
        }
        return makeTextNodeLinkFn(tokens, frag, options);
    }
    function removeText(vm, node) {
        remove(node);
    }
    function processTextToken(token, options) {
        var el;
        if (token.oneTime) {
            el = document.createTextNode(token.value);
        } else {
            if (token.html) {
                el = document.createComment('v-html');
                setTokenType('html');
            } else {
                el = document.createTextNode(' ');
                setTokenType('text');
            }
        }
        function setTokenType(type) {
            if (token.descriptor)
                return;
            var parsed = parseDirective(token.value);
            token.descriptor = {
                name: type,
                def: directives[type],
                expression: parsed.expression,
                filters: parsed.filters
            };
        }
        return el;
    }
    function makeTextNodeLinkFn(tokens, frag) {
        return function textNodeLinkFn(vm, el, host, scope) {
            var fragClone = frag.cloneNode(true);
            var childNodes = toArray(fragClone.childNodes);
            var token, value, node;
            for (var i = 0, l = tokens.length; i < l; i++) {
                token = tokens[i];
                value = token.value;
                if (token.tag) {
                    node = childNodes[i];
                    if (token.oneTime) {
                        value = (scope || vm).$eval(value);
                        if (token.html) {
                            replace(node, parseTemplate(value, true));
                        } else {
                            node.data = value;
                        }
                    } else {
                        vm._bindDir(token.descriptor, node, host, scope);
                    }
                }
            }
            replace(el, fragClone);
        };
    }
    function compileNodeList(nodeList, options) {
        var linkFns = [];
        var nodeLinkFn, childLinkFn, node;
        for (var i = 0, l = nodeList.length; i < l; i++) {
            node = nodeList[i];
            nodeLinkFn = compileNode(node, options);
            childLinkFn = !(nodeLinkFn && nodeLinkFn.terminal) && node.tagName !== 'SCRIPT' && node.hasChildNodes() ? compileNodeList(node.childNodes, options) : null;
            linkFns.push(nodeLinkFn, childLinkFn);
        }
        return linkFns.length ? makeChildLinkFn(linkFns) : null;
    }
    function makeChildLinkFn(linkFns) {
        return function childLinkFn(vm, nodes, host, scope, frag) {
            var node, nodeLinkFn, childrenLinkFn;
            for (var i = 0, n = 0, l = linkFns.length; i < l; n++) {
                node = nodes[n];
                nodeLinkFn = linkFns[i++];
                childrenLinkFn = linkFns[i++];
                var childNodes = toArray(node.childNodes);
                if (nodeLinkFn) {
                    nodeLinkFn(vm, node, host, scope, frag);
                }
                if (childrenLinkFn) {
                    childrenLinkFn(vm, childNodes, host, scope, frag);
                }
            }
        };
    }
    function checkElementDirectives(el, options) {
        var tag = el.tagName.toLowerCase();
        if (commonTagRE.test(tag)) {
            return;
        }
        var def = resolveAsset(options, 'elementDirectives', tag);
        if (def) {
            return makeTerminalNodeLinkFn(el, tag, '', options, def);
        }
    }
    function checkComponent(el, options) {
        var component = checkComponentAttr(el, options);
        if (component) {
            var ref = findRef(el);
            var descriptor = {
                name: 'component',
                ref: ref,
                expression: component.id,
                def: internalDirectives.component,
                modifiers: { literal: !component.dynamic }
            };
            var componentLinkFn = function componentLinkFn(vm, el, host, scope, frag) {
                if (ref) {
                    defineReactive((scope || vm).$refs, ref, null);
                }
                vm._bindDir(descriptor, el, host, scope, frag);
            };
            componentLinkFn.terminal = true;
            return componentLinkFn;
        }
    }
    function checkTerminalDirectives(el, attrs, options) {
        if (getAttr(el, 'v-pre') !== null) {
            return skip;
        }
        if (el.hasAttribute('v-else')) {
            var prev = el.previousElementSibling;
            if (prev && prev.hasAttribute('v-if')) {
                return skip;
            }
        }
        var attr, name, value, modifiers, matched, dirName, rawName, arg, def, termDef;
        for (var i = 0, j = attrs.length; i < j; i++) {
            attr = attrs[i];
            name = attr.name.replace(modifierRE, '');
            if (matched = name.match(dirAttrRE)) {
                def = resolveAsset(options, 'directives', matched[1]);
                if (def && def.terminal) {
                    if (!termDef || (def.priority || DEFAULT_TERMINAL_PRIORITY) > termDef.priority) {
                        termDef = def;
                        rawName = attr.name;
                        modifiers = parseModifiers(attr.name);
                        value = attr.value;
                        dirName = matched[1];
                        arg = matched[2];
                    }
                }
            }
        }
        if (termDef) {
            return makeTerminalNodeLinkFn(el, dirName, value, options, termDef, rawName, arg, modifiers);
        }
    }
    function skip() {
    }
    skip.terminal = true;
    function makeTerminalNodeLinkFn(el, dirName, value, options, def, rawName, arg, modifiers) {
        var parsed = parseDirective(value);
        var descriptor = {
            name: dirName,
            arg: arg,
            expression: parsed.expression,
            filters: parsed.filters,
            raw: value,
            attr: rawName,
            modifiers: modifiers,
            def: def
        };
        if (dirName === 'for' || dirName === 'router-view') {
            descriptor.ref = findRef(el);
        }
        var fn = function terminalNodeLinkFn(vm, el, host, scope, frag) {
            if (descriptor.ref) {
                defineReactive((scope || vm).$refs, descriptor.ref, null);
            }
            vm._bindDir(descriptor, el, host, scope, frag);
        };
        fn.terminal = true;
        return fn;
    }
    function compileDirectives(attrs, options) {
        var i = attrs.length;
        var dirs = [];
        var attr, name, value, rawName, rawValue, dirName, arg, modifiers, dirDef, tokens, matched;
        while (i--) {
            attr = attrs[i];
            name = rawName = attr.name;
            value = rawValue = attr.value;
            tokens = parseText(value);
            arg = null;
            modifiers = parseModifiers(name);
            name = name.replace(modifierRE, '');
            if (tokens) {
                value = tokensToExp(tokens);
                arg = name;
                pushDir('bind', directives.bind, tokens);
                if ('development' !== 'production') {
                    if (name === 'class' && Array.prototype.some.call(attrs, function (attr) {
                            return attr.name === ':class' || attr.name === 'v-bind:class';
                        })) {
                        warn('class="' + rawValue + '": Do not mix mustache interpolation ' + 'and v-bind for "class" on the same element. Use one or the other.', options);
                    }
                }
            } else if (transitionRE.test(name)) {
                modifiers.literal = !bindRE.test(name);
                pushDir('transition', internalDirectives.transition);
            } else if (onRE.test(name)) {
                arg = name.replace(onRE, '');
                pushDir('on', directives.on);
            } else if (bindRE.test(name)) {
                dirName = name.replace(bindRE, '');
                if (dirName === 'style' || dirName === 'class') {
                    pushDir(dirName, internalDirectives[dirName]);
                } else {
                    arg = dirName;
                    pushDir('bind', directives.bind);
                }
            } else if (matched = name.match(dirAttrRE)) {
                dirName = matched[1];
                arg = matched[2];
                if (dirName === 'else') {
                    continue;
                }
                dirDef = resolveAsset(options, 'directives', dirName, true);
                if (dirDef) {
                    pushDir(dirName, dirDef);
                }
            }
        }
        function pushDir(dirName, def, interpTokens) {
            var hasOneTimeToken = interpTokens && hasOneTime(interpTokens);
            var parsed = !hasOneTimeToken && parseDirective(value);
            dirs.push({
                name: dirName,
                attr: rawName,
                raw: rawValue,
                def: def,
                arg: arg,
                modifiers: modifiers,
                expression: parsed && parsed.expression,
                filters: parsed && parsed.filters,
                interp: interpTokens,
                hasOneTime: hasOneTimeToken
            });
        }
        if (dirs.length) {
            return makeNodeLinkFn(dirs);
        }
    }
    function parseModifiers(name) {
        var res = Object.create(null);
        var match = name.match(modifierRE);
        if (match) {
            var i = match.length;
            while (i--) {
                res[match[i].slice(1)] = true;
            }
        }
        return res;
    }
    function makeNodeLinkFn(directives) {
        return function nodeLinkFn(vm, el, host, scope, frag) {
            var i = directives.length;
            while (i--) {
                vm._bindDir(directives[i], el, host, scope, frag);
            }
        };
    }
    function hasOneTime(tokens) {
        var i = tokens.length;
        while (i--) {
            if (tokens[i].oneTime)
                return true;
        }
    }
    function isScript(el) {
        return el.tagName === 'SCRIPT' && (!el.hasAttribute('type') || el.getAttribute('type') === 'text/javascript');
    }
    var specialCharRE = /[^\w\-:\.]/;
    function transclude(el, options) {
        if (options) {
            options._containerAttrs = extractAttrs(el);
        }
        if (isTemplate(el)) {
            el = parseTemplate(el);
        }
        if (options) {
            if (options._asComponent && !options.template) {
                options.template = '<slot></slot>';
            }
            if (options.template) {
                options._content = extractContent(el);
                el = transcludeTemplate(el, options);
            }
        }
        if (isFragment(el)) {
            prepend(createAnchor('v-start', true), el);
            el.appendChild(createAnchor('v-end', true));
        }
        return el;
    }
    function transcludeTemplate(el, options) {
        var template = options.template;
        var frag = parseTemplate(template, true);
        if (frag) {
            var replacer = frag.firstChild;
            var tag = replacer.tagName && replacer.tagName.toLowerCase();
            if (options.replace) {
                if (el === document.body) {
                    'development' !== 'production' && warn('You are mounting an instance with a template to ' + '<body>. This will replace <body> entirely. You ' + 'should probably use `replace: false` here.');
                }
                if (frag.childNodes.length > 1 || replacer.nodeType !== 1 || tag === 'component' || resolveAsset(options, 'components', tag) || hasBindAttr(replacer, 'is') || resolveAsset(options, 'elementDirectives', tag) || replacer.hasAttribute('v-for') || replacer.hasAttribute('v-if')) {
                    return frag;
                } else {
                    options._replacerAttrs = extractAttrs(replacer);
                    mergeAttrs(el, replacer);
                    return replacer;
                }
            } else {
                el.appendChild(frag);
                return el;
            }
        } else {
            'development' !== 'production' && warn('Invalid template option: ' + template);
        }
    }
    function extractAttrs(el) {
        if (el.nodeType === 1 && el.hasAttributes()) {
            return toArray(el.attributes);
        }
    }
    function mergeAttrs(from, to) {
        var attrs = from.attributes;
        var i = attrs.length;
        var name, value;
        while (i--) {
            name = attrs[i].name;
            value = attrs[i].value;
            if (!to.hasAttribute(name) && !specialCharRE.test(name)) {
                to.setAttribute(name, value);
            } else if (name === 'class' && !parseText(value) && (value = value.trim())) {
                value.split(/\s+/).forEach(function (cls) {
                    addClass(to, cls);
                });
            }
        }
    }
    function resolveSlots(vm, content) {
        if (!content) {
            return;
        }
        var contents = vm._slotContents = Object.create(null);
        var el, name;
        for (var i = 0, l = content.children.length; i < l; i++) {
            el = content.children[i];
            if (name = el.getAttribute('slot')) {
                (contents[name] || (contents[name] = [])).push(el);
            }
            if ('development' !== 'production' && getBindAttr(el, 'slot')) {
                warn('The "slot" attribute must be static.', vm.$parent);
            }
        }
        for (name in contents) {
            contents[name] = extractFragment(contents[name], content);
        }
        if (content.hasChildNodes()) {
            var nodes = content.childNodes;
            if (nodes.length === 1 && nodes[0].nodeType === 3 && !nodes[0].data.trim()) {
                return;
            }
            contents['default'] = extractFragment(content.childNodes, content);
        }
    }
    function extractFragment(nodes, parent) {
        var frag = document.createDocumentFragment();
        nodes = toArray(nodes);
        for (var i = 0, l = nodes.length; i < l; i++) {
            var node = nodes[i];
            if (isTemplate(node) && !node.hasAttribute('v-if') && !node.hasAttribute('v-for')) {
                parent.removeChild(node);
                node = parseTemplate(node, true);
            }
            frag.appendChild(node);
        }
        return frag;
    }
    var compiler = Object.freeze({
        compile: compile,
        compileAndLinkProps: compileAndLinkProps,
        compileRoot: compileRoot,
        transclude: transclude,
        resolveSlots: resolveSlots
    });
    function stateMixin(Vue) {
        Object.defineProperty(Vue.prototype, '$data', {
            get: function get() {
                return this._data;
            },
            set: function set(newData) {
                if (newData !== this._data) {
                    this._setData(newData);
                }
            }
        });
        Vue.prototype._initState = function () {
            this._initProps();
            this._initMeta();
            this._initMethods();
            this._initData();
            this._initComputed();
        };
        Vue.prototype._initProps = function () {
            var options = this.$options;
            var el = options.el;
            var props = options.props;
            if (props && !el) {
                'development' !== 'production' && warn('Props will not be compiled if no `el` option is ' + 'provided at instantiation.', this);
            }
            el = options.el = query(el);
            this._propsUnlinkFn = el && el.nodeType === 1 && props ? compileAndLinkProps(this, el, props, this._scope) : null;
        };
        Vue.prototype._initData = function () {
            var dataFn = this.$options.data;
            var data = this._data = dataFn ? dataFn() : {};
            if (!isPlainObject(data)) {
                data = {};
                'development' !== 'production' && warn('data functions should return an object.', this);
            }
            var props = this._props;
            var keys = Object.keys(data);
            var i, key;
            i = keys.length;
            while (i--) {
                key = keys[i];
                if (!props || !hasOwn(props, key)) {
                    this._proxy(key);
                } else if ('development' !== 'production') {
                    warn('Data field "' + key + '" is already defined ' + 'as a prop. To provide default value for a prop, use the "default" ' + 'prop option; if you want to pass prop values to an instantiation ' + 'call, use the "propsData" option.', this);
                }
            }
            observe(data, this);
        };
        Vue.prototype._setData = function (newData) {
            newData = newData || {};
            var oldData = this._data;
            this._data = newData;
            var keys, key, i;
            keys = Object.keys(oldData);
            i = keys.length;
            while (i--) {
                key = keys[i];
                if (!(key in newData)) {
                    this._unproxy(key);
                }
            }
            keys = Object.keys(newData);
            i = keys.length;
            while (i--) {
                key = keys[i];
                if (!hasOwn(this, key)) {
                    this._proxy(key);
                }
            }
            oldData.__ob__.removeVm(this);
            observe(newData, this);
            this._digest();
        };
        Vue.prototype._proxy = function (key) {
            if (!isReserved(key)) {
                var self = this;
                Object.defineProperty(self, key, {
                    configurable: true,
                    enumerable: true,
                    get: function proxyGetter() {
                        return self._data[key];
                    },
                    set: function proxySetter(val) {
                        self._data[key] = val;
                    }
                });
            }
        };
        Vue.prototype._unproxy = function (key) {
            if (!isReserved(key)) {
                delete this[key];
            }
        };
        Vue.prototype._digest = function () {
            for (var i = 0, l = this._watchers.length; i < l; i++) {
                this._watchers[i].update(true);
            }
        };
        function noop() {
        }
        Vue.prototype._initComputed = function () {
            var computed = this.$options.computed;
            if (computed) {
                for (var key in computed) {
                    var userDef = computed[key];
                    var def = {
                        enumerable: true,
                        configurable: true
                    };
                    if (typeof userDef === 'function') {
                        def.get = makeComputedGetter(userDef, this);
                        def.set = noop;
                    } else {
                        def.get = userDef.get ? userDef.cache !== false ? makeComputedGetter(userDef.get, this) : bind(userDef.get, this) : noop;
                        def.set = userDef.set ? bind(userDef.set, this) : noop;
                    }
                    Object.defineProperty(this, key, def);
                }
            }
        };
        function makeComputedGetter(getter, owner) {
            var watcher = new Watcher(owner, getter, null, { lazy: true });
            return function computedGetter() {
                if (watcher.dirty) {
                    watcher.evaluate();
                }
                if (Dep.target) {
                    watcher.depend();
                }
                return watcher.value;
            };
        }
        Vue.prototype._initMethods = function () {
            var methods = this.$options.methods;
            if (methods) {
                for (var key in methods) {
                    this[key] = bind(methods[key], this);
                }
            }
        };
        Vue.prototype._initMeta = function () {
            var metas = this.$options._meta;
            if (metas) {
                for (var key in metas) {
                    defineReactive(this, key, metas[key]);
                }
            }
        };
    }
    var eventRE = /^v-on:|^@/;
    function eventsMixin(Vue) {
        Vue.prototype._initEvents = function () {
            var options = this.$options;
            if (options._asComponent) {
                registerComponentEvents(this, options.el);
            }
            registerCallbacks(this, '$on', options.events);
            registerCallbacks(this, '$watch', options.watch);
        };
        function registerComponentEvents(vm, el) {
            var attrs = el.attributes;
            var name, value, handler;
            for (var i = 0, l = attrs.length; i < l; i++) {
                name = attrs[i].name;
                if (eventRE.test(name)) {
                    name = name.replace(eventRE, '');
                    value = attrs[i].value;
                    if (isSimplePath(value)) {
                        value += '.apply(this, $arguments)';
                    }
                    handler = (vm._scope || vm._context).$eval(value, true);
                    handler._fromParent = true;
                    vm.$on(name.replace(eventRE), handler);
                }
            }
        }
        function registerCallbacks(vm, action, hash) {
            if (!hash)
                return;
            var handlers, key, i, j;
            for (key in hash) {
                handlers = hash[key];
                if (isArray(handlers)) {
                    for (i = 0, j = handlers.length; i < j; i++) {
                        register(vm, action, key, handlers[i]);
                    }
                } else {
                    register(vm, action, key, handlers);
                }
            }
        }
        function register(vm, action, key, handler, options) {
            var type = typeof handler;
            if (type === 'function') {
                vm[action](key, handler, options);
            } else if (type === 'string') {
                var methods = vm.$options.methods;
                var method = methods && methods[handler];
                if (method) {
                    vm[action](key, method, options);
                } else {
                    'development' !== 'production' && warn('Unknown method: "' + handler + '" when ' + 'registering callback for ' + action + ': "' + key + '".', vm);
                }
            } else if (handler && type === 'object') {
                register(vm, action, key, handler.handler, handler);
            }
        }
        Vue.prototype._initDOMHooks = function () {
            this.$on('hook:attached', onAttached);
            this.$on('hook:detached', onDetached);
        };
        function onAttached() {
            if (!this._isAttached) {
                this._isAttached = true;
                this.$children.forEach(callAttach);
            }
        }
        function callAttach(child) {
            if (!child._isAttached && inDoc(child.$el)) {
                child._callHook('attached');
            }
        }
        function onDetached() {
            if (this._isAttached) {
                this._isAttached = false;
                this.$children.forEach(callDetach);
            }
        }
        function callDetach(child) {
            if (child._isAttached && !inDoc(child.$el)) {
                child._callHook('detached');
            }
        }
        Vue.prototype._callHook = function (hook) {
            this.$emit('pre-hook:' + hook);
            var handlers = this.$options[hook];
            if (handlers) {
                for (var i = 0, j = handlers.length; i < j; i++) {
                    handlers[i].call(this);
                }
            }
            this.$emit('hook:' + hook);
        };
    }
    function noop() {
    }
    function Directive(descriptor, vm, el, host, scope, frag) {
        this.vm = vm;
        this.el = el;
        this.descriptor = descriptor;
        this.name = descriptor.name;
        this.expression = descriptor.expression;
        this.arg = descriptor.arg;
        this.modifiers = descriptor.modifiers;
        this.filters = descriptor.filters;
        this.literal = this.modifiers && this.modifiers.literal;
        this._locked = false;
        this._bound = false;
        this._listeners = null;
        this._host = host;
        this._scope = scope;
        this._frag = frag;
        if ('development' !== 'production' && this.el) {
            this.el._vue_directives = this.el._vue_directives || [];
            this.el._vue_directives.push(this);
        }
    }
    Directive.prototype._bind = function () {
        var name = this.name;
        var descriptor = this.descriptor;
        if ((name !== 'cloak' || this.vm._isCompiled) && this.el && this.el.removeAttribute) {
            var attr = descriptor.attr || 'v-' + name;
            this.el.removeAttribute(attr);
        }
        var def = descriptor.def;
        if (typeof def === 'function') {
            this.update = def;
        } else {
            extend(this, def);
        }
        this._setupParams();
        if (this.bind) {
            this.bind();
        }
        this._bound = true;
        if (this.literal) {
            this.update && this.update(descriptor.raw);
        } else if ((this.expression || this.modifiers) && (this.update || this.twoWay) && !this._checkStatement()) {
            var dir = this;
            if (this.update) {
                this._update = function (val, oldVal) {
                    if (!dir._locked) {
                        dir.update(val, oldVal);
                    }
                };
            } else {
                this._update = noop;
            }
            var preProcess = this._preProcess ? bind(this._preProcess, this) : null;
            var postProcess = this._postProcess ? bind(this._postProcess, this) : null;
            var watcher = this._watcher = new Watcher(this.vm, this.expression, this._update, {
                filters: this.filters,
                twoWay: this.twoWay,
                deep: this.deep,
                preProcess: preProcess,
                postProcess: postProcess,
                scope: this._scope
            });
            if (this.afterBind) {
                this.afterBind();
            } else if (this.update) {
                this.update(watcher.value);
            }
        }
    };
    Directive.prototype._setupParams = function () {
        if (!this.params) {
            return;
        }
        var params = this.params;
        this.params = Object.create(null);
        var i = params.length;
        var key, val, mappedKey;
        while (i--) {
            key = hyphenate(params[i]);
            mappedKey = camelize(key);
            val = getBindAttr(this.el, key);
            if (val != null) {
                this._setupParamWatcher(mappedKey, val);
            } else {
                val = getAttr(this.el, key);
                if (val != null) {
                    this.params[mappedKey] = val === '' ? true : val;
                }
            }
        }
    };
    Directive.prototype._setupParamWatcher = function (key, expression) {
        var self = this;
        var called = false;
        var unwatch = (this._scope || this.vm).$watch(expression, function (val, oldVal) {
            self.params[key] = val;
            if (called) {
                var cb = self.paramWatchers && self.paramWatchers[key];
                if (cb) {
                    cb.call(self, val, oldVal);
                }
            } else {
                called = true;
            }
        }, {
            immediate: true,
            user: false
        });
        (this._paramUnwatchFns || (this._paramUnwatchFns = [])).push(unwatch);
    };
    Directive.prototype._checkStatement = function () {
        var expression = this.expression;
        if (expression && this.acceptStatement && !isSimplePath(expression)) {
            var fn = parseExpression(expression).get;
            var scope = this._scope || this.vm;
            var handler = function handler(e) {
                scope.$event = e;
                fn.call(scope, scope);
                scope.$event = null;
            };
            if (this.filters) {
                handler = scope._applyFilters(handler, null, this.filters);
            }
            this.update(handler);
            return true;
        }
    };
    Directive.prototype.set = function (value) {
        if (this.twoWay) {
            this._withLock(function () {
                this._watcher.set(value);
            });
        } else if ('development' !== 'production') {
            warn('Directive.set() can only be used inside twoWay' + 'directives.');
        }
    };
    Directive.prototype._withLock = function (fn) {
        var self = this;
        self._locked = true;
        fn.call(self);
        nextTick(function () {
            self._locked = false;
        });
    };
    Directive.prototype.on = function (event, handler, useCapture) {
        on(this.el, event, handler, useCapture);
        (this._listeners || (this._listeners = [])).push([
            event,
            handler
        ]);
    };
    Directive.prototype._teardown = function () {
        if (this._bound) {
            this._bound = false;
            if (this.unbind) {
                this.unbind();
            }
            if (this._watcher) {
                this._watcher.teardown();
            }
            var listeners = this._listeners;
            var i;
            if (listeners) {
                i = listeners.length;
                while (i--) {
                    off(this.el, listeners[i][0], listeners[i][1]);
                }
            }
            var unwatchFns = this._paramUnwatchFns;
            if (unwatchFns) {
                i = unwatchFns.length;
                while (i--) {
                    unwatchFns[i]();
                }
            }
            if ('development' !== 'production' && this.el) {
                this.el._vue_directives.$remove(this);
            }
            this.vm = this.el = this._watcher = this._listeners = null;
        }
    };
    function lifecycleMixin(Vue) {
        Vue.prototype._updateRef = function (remove) {
            var ref = this.$options._ref;
            if (ref) {
                var refs = (this._scope || this._context).$refs;
                if (remove) {
                    if (refs[ref] === this) {
                        refs[ref] = null;
                    }
                } else {
                    refs[ref] = this;
                }
            }
        };
        Vue.prototype._compile = function (el) {
            var options = this.$options;
            var original = el;
            el = transclude(el, options);
            this._initElement(el);
            if (el.nodeType === 1 && getAttr(el, 'v-pre') !== null) {
                return;
            }
            var contextOptions = this._context && this._context.$options;
            var rootLinker = compileRoot(el, options, contextOptions);
            resolveSlots(this, options._content);
            var contentLinkFn;
            var ctor = this.constructor;
            if (options._linkerCachable) {
                contentLinkFn = ctor.linker;
                if (!contentLinkFn) {
                    contentLinkFn = ctor.linker = compile(el, options);
                }
            }
            var rootUnlinkFn = rootLinker(this, el, this._scope);
            var contentUnlinkFn = contentLinkFn ? contentLinkFn(this, el) : compile(el, options)(this, el);
            this._unlinkFn = function () {
                rootUnlinkFn();
                contentUnlinkFn(true);
            };
            if (options.replace) {
                replace(original, el);
            }
            this._isCompiled = true;
            this._callHook('compiled');
        };
        Vue.prototype._initElement = function (el) {
            if (isFragment(el)) {
                this._isFragment = true;
                this.$el = this._fragmentStart = el.firstChild;
                this._fragmentEnd = el.lastChild;
                if (this._fragmentStart.nodeType === 3) {
                    this._fragmentStart.data = this._fragmentEnd.data = '';
                }
                this._fragment = el;
            } else {
                this.$el = el;
            }
            this.$el.__vue__ = this;
            this._callHook('beforeCompile');
        };
        Vue.prototype._bindDir = function (descriptor, node, host, scope, frag) {
            this._directives.push(new Directive(descriptor, this, node, host, scope, frag));
        };
        Vue.prototype._destroy = function (remove, deferCleanup) {
            if (this._isBeingDestroyed) {
                if (!deferCleanup) {
                    this._cleanup();
                }
                return;
            }
            var destroyReady;
            var pendingRemoval;
            var self = this;
            var cleanupIfPossible = function cleanupIfPossible() {
                if (destroyReady && !pendingRemoval && !deferCleanup) {
                    self._cleanup();
                }
            };
            if (remove && this.$el) {
                pendingRemoval = true;
                this.$remove(function () {
                    pendingRemoval = false;
                    cleanupIfPossible();
                });
            }
            this._callHook('beforeDestroy');
            this._isBeingDestroyed = true;
            var i;
            var parent = this.$parent;
            if (parent && !parent._isBeingDestroyed) {
                parent.$children.$remove(this);
                this._updateRef(true);
            }
            i = this.$children.length;
            while (i--) {
                this.$children[i].$destroy();
            }
            if (this._propsUnlinkFn) {
                this._propsUnlinkFn();
            }
            if (this._unlinkFn) {
                this._unlinkFn();
            }
            i = this._watchers.length;
            while (i--) {
                this._watchers[i].teardown();
            }
            if (this.$el) {
                this.$el.__vue__ = null;
            }
            destroyReady = true;
            cleanupIfPossible();
        };
        Vue.prototype._cleanup = function () {
            if (this._isDestroyed) {
                return;
            }
            if (this._frag) {
                this._frag.children.$remove(this);
            }
            if (this._data && this._data.__ob__) {
                this._data.__ob__.removeVm(this);
            }
            this.$el = this.$parent = this.$root = this.$children = this._watchers = this._context = this._scope = this._directives = null;
            this._isDestroyed = true;
            this._callHook('destroyed');
            this.$off();
        };
    }
    function miscMixin(Vue) {
        Vue.prototype._applyFilters = function (value, oldValue, filters, write) {
            var filter, fn, args, arg, offset, i, l, j, k;
            for (i = 0, l = filters.length; i < l; i++) {
                filter = filters[write ? l - i - 1 : i];
                fn = resolveAsset(this.$options, 'filters', filter.name, true);
                if (!fn)
                    continue;
                fn = write ? fn.write : fn.read || fn;
                if (typeof fn !== 'function')
                    continue;
                args = write ? [
                    value,
                    oldValue
                ] : [value];
                offset = write ? 2 : 1;
                if (filter.args) {
                    for (j = 0, k = filter.args.length; j < k; j++) {
                        arg = filter.args[j];
                        args[j + offset] = arg.dynamic ? this.$get(arg.value) : arg.value;
                    }
                }
                value = fn.apply(this, args);
            }
            return value;
        };
        Vue.prototype._resolveComponent = function (value, cb) {
            var factory;
            if (typeof value === 'function') {
                factory = value;
            } else {
                factory = resolveAsset(this.$options, 'components', value, true);
            }
            if (!factory) {
                return;
            }
            if (!factory.options) {
                if (factory.resolved) {
                    cb(factory.resolved);
                } else if (factory.requested) {
                    factory.pendingCallbacks.push(cb);
                } else {
                    factory.requested = true;
                    var cbs = factory.pendingCallbacks = [cb];
                    factory.call(this, function resolve(res) {
                        if (isPlainObject(res)) {
                            res = Vue.extend(res);
                        }
                        factory.resolved = res;
                        for (var i = 0, l = cbs.length; i < l; i++) {
                            cbs[i](res);
                        }
                    }, function reject(reason) {
                        'development' !== 'production' && warn('Failed to resolve async component' + (typeof value === 'string' ? ': ' + value : '') + '. ' + (reason ? '\nReason: ' + reason : ''));
                    });
                }
            } else {
                cb(factory);
            }
        };
    }
    var filterRE$1 = /[^|]\|[^|]/;
    function dataAPI(Vue) {
        Vue.prototype.$get = function (exp, asStatement) {
            var res = parseExpression(exp);
            if (res) {
                if (asStatement) {
                    var self = this;
                    return function statementHandler() {
                        self.$arguments = toArray(arguments);
                        var result = res.get.call(self, self);
                        self.$arguments = null;
                        return result;
                    };
                } else {
                    try {
                        return res.get.call(this, this);
                    } catch (e) {
                    }
                }
            }
        };
        Vue.prototype.$set = function (exp, val) {
            var res = parseExpression(exp, true);
            if (res && res.set) {
                res.set.call(this, this, val);
            }
        };
        Vue.prototype.$delete = function (key) {
            del(this._data, key);
        };
        Vue.prototype.$watch = function (expOrFn, cb, options) {
            var vm = this;
            var parsed;
            if (typeof expOrFn === 'string') {
                parsed = parseDirective(expOrFn);
                expOrFn = parsed.expression;
            }
            var watcher = new Watcher(vm, expOrFn, cb, {
                deep: options && options.deep,
                sync: options && options.sync,
                filters: parsed && parsed.filters,
                user: !options || options.user !== false
            });
            if (options && options.immediate) {
                cb.call(vm, watcher.value);
            }
            return function unwatchFn() {
                watcher.teardown();
            };
        };
        Vue.prototype.$eval = function (text, asStatement) {
            if (filterRE$1.test(text)) {
                var dir = parseDirective(text);
                var val = this.$get(dir.expression, asStatement);
                return dir.filters ? this._applyFilters(val, null, dir.filters) : val;
            } else {
                return this.$get(text, asStatement);
            }
        };
        Vue.prototype.$interpolate = function (text) {
            var tokens = parseText(text);
            var vm = this;
            if (tokens) {
                if (tokens.length === 1) {
                    return vm.$eval(tokens[0].value) + '';
                } else {
                    return tokens.map(function (token) {
                        return token.tag ? vm.$eval(token.value) : token.value;
                    }).join('');
                }
            } else {
                return text;
            }
        };
        Vue.prototype.$log = function (path) {
            var data = path ? getPath(this._data, path) : this._data;
            if (data) {
                data = clean(data);
            }
            if (!path) {
                var key;
                for (key in this.$options.computed) {
                    data[key] = clean(this[key]);
                }
                if (this._props) {
                    for (key in this._props) {
                        data[key] = clean(this[key]);
                    }
                }
            }
            console.log(data);
        };
        function clean(obj) {
            return JSON.parse(JSON.stringify(obj));
        }
    }
    function domAPI(Vue) {
        Vue.prototype.$nextTick = function (fn) {
            nextTick(fn, this);
        };
        Vue.prototype.$appendTo = function (target, cb, withTransition) {
            return insert(this, target, cb, withTransition, append, appendWithTransition);
        };
        Vue.prototype.$prependTo = function (target, cb, withTransition) {
            target = query(target);
            if (target.hasChildNodes()) {
                this.$before(target.firstChild, cb, withTransition);
            } else {
                this.$appendTo(target, cb, withTransition);
            }
            return this;
        };
        Vue.prototype.$before = function (target, cb, withTransition) {
            return insert(this, target, cb, withTransition, beforeWithCb, beforeWithTransition);
        };
        Vue.prototype.$after = function (target, cb, withTransition) {
            target = query(target);
            if (target.nextSibling) {
                this.$before(target.nextSibling, cb, withTransition);
            } else {
                this.$appendTo(target.parentNode, cb, withTransition);
            }
            return this;
        };
        Vue.prototype.$remove = function (cb, withTransition) {
            if (!this.$el.parentNode) {
                return cb && cb();
            }
            var inDocument = this._isAttached && inDoc(this.$el);
            if (!inDocument)
                withTransition = false;
            var self = this;
            var realCb = function realCb() {
                if (inDocument)
                    self._callHook('detached');
                if (cb)
                    cb();
            };
            if (this._isFragment) {
                removeNodeRange(this._fragmentStart, this._fragmentEnd, this, this._fragment, realCb);
            } else {
                var op = withTransition === false ? removeWithCb : removeWithTransition;
                op(this.$el, this, realCb);
            }
            return this;
        };
        function insert(vm, target, cb, withTransition, op1, op2) {
            target = query(target);
            var targetIsDetached = !inDoc(target);
            var op = withTransition === false || targetIsDetached ? op1 : op2;
            var shouldCallHook = !targetIsDetached && !vm._isAttached && !inDoc(vm.$el);
            if (vm._isFragment) {
                mapNodeRange(vm._fragmentStart, vm._fragmentEnd, function (node) {
                    op(node, target, vm);
                });
                cb && cb();
            } else {
                op(vm.$el, target, vm, cb);
            }
            if (shouldCallHook) {
                vm._callHook('attached');
            }
            return vm;
        }
        function query(el) {
            return typeof el === 'string' ? document.querySelector(el) : el;
        }
        function append(el, target, vm, cb) {
            target.appendChild(el);
            if (cb)
                cb();
        }
        function beforeWithCb(el, target, vm, cb) {
            before(el, target);
            if (cb)
                cb();
        }
        function removeWithCb(el, vm, cb) {
            remove(el);
            if (cb)
                cb();
        }
    }
    function eventsAPI(Vue) {
        Vue.prototype.$on = function (event, fn) {
            (this._events[event] || (this._events[event] = [])).push(fn);
            modifyListenerCount(this, event, 1);
            return this;
        };
        Vue.prototype.$once = function (event, fn) {
            var self = this;
            function on() {
                self.$off(event, on);
                fn.apply(this, arguments);
            }
            on.fn = fn;
            this.$on(event, on);
            return this;
        };
        Vue.prototype.$off = function (event, fn) {
            var cbs;
            if (!arguments.length) {
                if (this.$parent) {
                    for (event in this._events) {
                        cbs = this._events[event];
                        if (cbs) {
                            modifyListenerCount(this, event, -cbs.length);
                        }
                    }
                }
                this._events = {};
                return this;
            }
            cbs = this._events[event];
            if (!cbs) {
                return this;
            }
            if (arguments.length === 1) {
                modifyListenerCount(this, event, -cbs.length);
                this._events[event] = null;
                return this;
            }
            var cb;
            var i = cbs.length;
            while (i--) {
                cb = cbs[i];
                if (cb === fn || cb.fn === fn) {
                    modifyListenerCount(this, event, -1);
                    cbs.splice(i, 1);
                    break;
                }
            }
            return this;
        };
        Vue.prototype.$emit = function (event) {
            var isSource = typeof event === 'string';
            event = isSource ? event : event.name;
            var cbs = this._events[event];
            var shouldPropagate = isSource || !cbs;
            if (cbs) {
                cbs = cbs.length > 1 ? toArray(cbs) : cbs;
                var hasParentCbs = isSource && cbs.some(function (cb) {
                    return cb._fromParent;
                });
                if (hasParentCbs) {
                    shouldPropagate = false;
                }
                var args = toArray(arguments, 1);
                for (var i = 0, l = cbs.length; i < l; i++) {
                    var cb = cbs[i];
                    var res = cb.apply(this, args);
                    if (res === true && (!hasParentCbs || cb._fromParent)) {
                        shouldPropagate = true;
                    }
                }
            }
            return shouldPropagate;
        };
        Vue.prototype.$broadcast = function (event) {
            var isSource = typeof event === 'string';
            event = isSource ? event : event.name;
            if (!this._eventsCount[event])
                return;
            var children = this.$children;
            var args = toArray(arguments);
            if (isSource) {
                args[0] = {
                    name: event,
                    source: this
                };
            }
            for (var i = 0, l = children.length; i < l; i++) {
                var child = children[i];
                var shouldPropagate = child.$emit.apply(child, args);
                if (shouldPropagate) {
                    child.$broadcast.apply(child, args);
                }
            }
            return this;
        };
        Vue.prototype.$dispatch = function (event) {
            var shouldPropagate = this.$emit.apply(this, arguments);
            if (!shouldPropagate)
                return;
            var parent = this.$parent;
            var args = toArray(arguments);
            args[0] = {
                name: event,
                source: this
            };
            while (parent) {
                shouldPropagate = parent.$emit.apply(parent, args);
                parent = shouldPropagate ? parent.$parent : null;
            }
            return this;
        };
        var hookRE = /^hook:/;
        function modifyListenerCount(vm, event, count) {
            var parent = vm.$parent;
            if (!parent || !count || hookRE.test(event))
                return;
            while (parent) {
                parent._eventsCount[event] = (parent._eventsCount[event] || 0) + count;
                parent = parent.$parent;
            }
        }
    }
    function lifecycleAPI(Vue) {
        Vue.prototype.$mount = function (el) {
            if (this._isCompiled) {
                'development' !== 'production' && warn('$mount() should be called only once.', this);
                return;
            }
            el = query(el);
            if (!el) {
                el = document.createElement('div');
            }
            this._compile(el);
            this._initDOMHooks();
            if (inDoc(this.$el)) {
                this._callHook('attached');
                ready.call(this);
            } else {
                this.$once('hook:attached', ready);
            }
            return this;
        };
        function ready() {
            this._isAttached = true;
            this._isReady = true;
            this._callHook('ready');
        }
        Vue.prototype.$destroy = function (remove, deferCleanup) {
            this._destroy(remove, deferCleanup);
        };
        Vue.prototype.$compile = function (el, host, scope, frag) {
            return compile(el, this.$options, true)(this, el, host, scope, frag);
        };
    }
    function Vue(options) {
        this._init(options);
    }
    initMixin(Vue);
    stateMixin(Vue);
    eventsMixin(Vue);
    lifecycleMixin(Vue);
    miscMixin(Vue);
    dataAPI(Vue);
    domAPI(Vue);
    eventsAPI(Vue);
    lifecycleAPI(Vue);
    var slot = {
        priority: SLOT,
        params: ['name'],
        bind: function bind() {
            var name = this.params.name || 'default';
            var content = this.vm._slotContents && this.vm._slotContents[name];
            if (!content || !content.hasChildNodes()) {
                this.fallback();
            } else {
                this.compile(content.cloneNode(true), this.vm._context, this.vm);
            }
        },
        compile: function compile(content, context, host) {
            if (content && context) {
                if (this.el.hasChildNodes() && content.childNodes.length === 1 && content.childNodes[0].nodeType === 1 && content.childNodes[0].hasAttribute('v-if')) {
                    var elseBlock = document.createElement('template');
                    elseBlock.setAttribute('v-else', '');
                    elseBlock.innerHTML = this.el.innerHTML;
                    elseBlock._context = this.vm;
                    content.appendChild(elseBlock);
                }
                var scope = host ? host._scope : this._scope;
                this.unlink = context.$compile(content, host, scope, this._frag);
            }
            if (content) {
                replace(this.el, content);
            } else {
                remove(this.el);
            }
        },
        fallback: function fallback() {
            this.compile(extractContent(this.el, true), this.vm);
        },
        unbind: function unbind() {
            if (this.unlink) {
                this.unlink();
            }
        }
    };
    var partial = {
        priority: PARTIAL,
        params: ['name'],
        paramWatchers: {
            name: function name(value) {
                vIf.remove.call(this);
                if (value) {
                    this.insert(value);
                }
            }
        },
        bind: function bind() {
            this.anchor = createAnchor('v-partial');
            replace(this.el, this.anchor);
            this.insert(this.params.name);
        },
        insert: function insert(id) {
            var partial = resolveAsset(this.vm.$options, 'partials', id, true);
            if (partial) {
                this.factory = new FragmentFactory(this.vm, partial);
                vIf.insert.call(this);
            }
        },
        unbind: function unbind() {
            if (this.frag) {
                this.frag.destroy();
            }
        }
    };
    var elementDirectives = {
        slot: slot,
        partial: partial
    };
    var convertArray = vFor._postProcess;
    function limitBy(arr, n, offset) {
        offset = offset ? parseInt(offset, 10) : 0;
        n = toNumber(n);
        return typeof n === 'number' ? arr.slice(offset, offset + n) : arr;
    }
    function filterBy(arr, search, delimiter) {
        arr = convertArray(arr);
        if (search == null) {
            return arr;
        }
        if (typeof search === 'function') {
            return arr.filter(search);
        }
        search = ('' + search).toLowerCase();
        var n = delimiter === 'in' ? 3 : 2;
        var keys = Array.prototype.concat.apply([], toArray(arguments, n));
        var res = [];
        var item, key, val, j;
        for (var i = 0, l = arr.length; i < l; i++) {
            item = arr[i];
            val = item && item.$value || item;
            j = keys.length;
            if (j) {
                while (j--) {
                    key = keys[j];
                    if (key === '$key' && contains(item.$key, search) || contains(getPath(val, key), search)) {
                        res.push(item);
                        break;
                    }
                }
            } else if (contains(item, search)) {
                res.push(item);
            }
        }
        return res;
    }
    function orderBy(arr) {
        var comparator = null;
        var sortKeys = undefined;
        arr = convertArray(arr);
        var args = toArray(arguments, 1);
        var order = args[args.length - 1];
        if (typeof order === 'number') {
            order = order < 0 ? -1 : 1;
            args = args.length > 1 ? args.slice(0, -1) : args;
        } else {
            order = 1;
        }
        var firstArg = args[0];
        if (!firstArg) {
            return arr;
        } else if (typeof firstArg === 'function') {
            comparator = function (a, b) {
                return firstArg(a, b) * order;
            };
        } else {
            sortKeys = Array.prototype.concat.apply([], args);
            comparator = function (a, b, i) {
                i = i || 0;
                return i >= sortKeys.length - 1 ? baseCompare(a, b, i) : baseCompare(a, b, i) || comparator(a, b, i + 1);
            };
        }
        function baseCompare(a, b, sortKeyIndex) {
            var sortKey = sortKeys[sortKeyIndex];
            if (sortKey) {
                if (sortKey !== '$key') {
                    if (isObject(a) && '$value' in a)
                        a = a.$value;
                    if (isObject(b) && '$value' in b)
                        b = b.$value;
                }
                a = isObject(a) ? getPath(a, sortKey) : a;
                b = isObject(b) ? getPath(b, sortKey) : b;
            }
            return a === b ? 0 : a > b ? order : -order;
        }
        return arr.slice().sort(comparator);
    }
    function contains(val, search) {
        var i;
        if (isPlainObject(val)) {
            var keys = Object.keys(val);
            i = keys.length;
            while (i--) {
                if (contains(val[keys[i]], search)) {
                    return true;
                }
            }
        } else if (isArray(val)) {
            i = val.length;
            while (i--) {
                if (contains(val[i], search)) {
                    return true;
                }
            }
        } else if (val != null) {
            return val.toString().toLowerCase().indexOf(search) > -1;
        }
    }
    var digitsRE = /(\d{3})(?=\d)/g;
    var filters = {
        orderBy: orderBy,
        filterBy: filterBy,
        limitBy: limitBy,
        json: {
            read: function read(value, indent) {
                return typeof value === 'string' ? value : JSON.stringify(value, null, Number(indent) || 2);
            },
            write: function write(value) {
                try {
                    return JSON.parse(value);
                } catch (e) {
                    return value;
                }
            }
        },
        capitalize: function capitalize(value) {
            if (!value && value !== 0)
                return '';
            value = value.toString();
            return value.charAt(0).toUpperCase() + value.slice(1);
        },
        uppercase: function uppercase(value) {
            return value || value === 0 ? value.toString().toUpperCase() : '';
        },
        lowercase: function lowercase(value) {
            return value || value === 0 ? value.toString().toLowerCase() : '';
        },
        currency: function currency(value, _currency, decimals) {
            value = parseFloat(value);
            if (!isFinite(value) || !value && value !== 0)
                return '';
            _currency = _currency != null ? _currency : '$';
            decimals = decimals != null ? decimals : 2;
            var stringified = Math.abs(value).toFixed(decimals);
            var _int = decimals ? stringified.slice(0, -1 - decimals) : stringified;
            var i = _int.length % 3;
            var head = i > 0 ? _int.slice(0, i) + (_int.length > 3 ? ',' : '') : '';
            var _float = decimals ? stringified.slice(-1 - decimals) : '';
            var sign = value < 0 ? '-' : '';
            return sign + _currency + head + _int.slice(i).replace(digitsRE, '$1,') + _float;
        },
        pluralize: function pluralize(value) {
            var args = toArray(arguments, 1);
            return args.length > 1 ? args[value % 10 - 1] || args[args.length - 1] : args[0] + (value === 1 ? '' : 's');
        },
        debounce: function debounce(handler, delay) {
            if (!handler)
                return;
            if (!delay) {
                delay = 300;
            }
            return _debounce(handler, delay);
        }
    };
    function installGlobalAPI(Vue) {
        Vue.options = {
            directives: directives,
            elementDirectives: elementDirectives,
            filters: filters,
            transitions: {},
            components: {},
            partials: {},
            replace: true
        };
        Vue.util = util;
        Vue.config = config;
        Vue.set = set;
        Vue['delete'] = del;
        Vue.nextTick = nextTick;
        Vue.compiler = compiler;
        Vue.FragmentFactory = FragmentFactory;
        Vue.internalDirectives = internalDirectives;
        Vue.parsers = {
            path: path,
            text: text,
            template: template,
            directive: directive,
            expression: expression
        };
        Vue.cid = 0;
        var cid = 1;
        Vue.extend = function (extendOptions) {
            extendOptions = extendOptions || {};
            var Super = this;
            var isFirstExtend = Super.cid === 0;
            if (isFirstExtend && extendOptions._Ctor) {
                return extendOptions._Ctor;
            }
            var name = extendOptions.name || Super.options.name;
            if ('development' !== 'production') {
                if (!/^[a-zA-Z][\w-]*$/.test(name)) {
                    warn('Invalid component name: "' + name + '". Component names ' + 'can only contain alphanumeric characaters and the hyphen.');
                    name = null;
                }
            }
            var Sub = createClass(name || 'VueComponent');
            Sub.prototype = Object.create(Super.prototype);
            Sub.prototype.constructor = Sub;
            Sub.cid = cid++;
            Sub.options = mergeOptions(Super.options, extendOptions);
            Sub['super'] = Super;
            Sub.extend = Super.extend;
            config._assetTypes.forEach(function (type) {
                Sub[type] = Super[type];
            });
            if (name) {
                Sub.options.components[name] = Sub;
            }
            if (isFirstExtend) {
                extendOptions._Ctor = Sub;
            }
            return Sub;
        };
        function createClass(name) {
            return new Function('return function ' + classify(name) + ' (options) { this._init(options) }')();
        }
        Vue.use = function (plugin) {
            if (plugin.installed) {
                return;
            }
            var args = toArray(arguments, 1);
            args.unshift(this);
            if (typeof plugin.install === 'function') {
                plugin.install.apply(plugin, args);
            } else {
                plugin.apply(null, args);
            }
            plugin.installed = true;
            return this;
        };
        Vue.mixin = function (mixin) {
            Vue.options = mergeOptions(Vue.options, mixin);
        };
        config._assetTypes.forEach(function (type) {
            Vue[type] = function (id, definition) {
                if (!definition) {
                    return this.options[type + 's'][id];
                } else {
                    if ('development' !== 'production') {
                        if (type === 'component' && (commonTagRE.test(id) || reservedTagRE.test(id))) {
                            warn('Do not use built-in or reserved HTML elements as component ' + 'id: ' + id);
                        }
                    }
                    if (type === 'component' && isPlainObject(definition)) {
                        definition.name = id;
                        definition = Vue.extend(definition);
                    }
                    this.options[type + 's'][id] = definition;
                    return definition;
                }
            };
        });
        extend(Vue.transition, transition);
    }
    installGlobalAPI(Vue);
    Vue.version = '1.0.24';
    setTimeout(function () {
        if (config.devtools) {
            if (devtools) {
                devtools.emit('init', Vue);
            } else if ('development' !== 'production' && inBrowser && /Chrome\/\d+/.test(window.navigator.userAgent)) {
                console.log('Download the Vue Devtools for a better development experience:\n' + 'https://github.com/vuejs/vue-devtools');
            }
        }
    }, 0);
    return Vue;
}));
define('comsys/widget/baseClass/WidgetBase', [
    'jquery',
    'Class',
    'comsys/base/Base'
], function ($, Class, Base) {
    return Class('Control.WidgetBase', {
        constructor: function (args) {
            this.callParent(args);
            this.$BaseEl = $(args.element);
        },
        initialize: function () {
            if (!this.$BaseEl.attr('id'))
                this.$BaseEl.attr('id', this.classids);
            return this;
        }
    }, Base);
});
define('comsys/widget/baseClass/HiddenBase', [
    'jquery',
    'Class',
    'comsys/widget/baseClass/WidgetBase'
], function ($, Class, WidgetBase) {
    return Class('Control.HiddenBase', {
        constructor: function (args) {
            this.callParent(args);
            this.$HiddenBaseElContainer = $('<div class="comsys-hidden-container"></div>');
        },
        initialize: function () {
            this.callParent();
            return this;
        },
        addPlaceHolderBefore: function () {
            if (this.setting.addPlaceHolderBefore)
                this.setting.addPlaceHolderBefore.call(this);
        },
        addPlaceHolderAfter: function () {
            if (this.setting.addPlaceHolderAfter)
                this.setting.addPlaceHolderAfter.call(this);
        },
        addPlaceHolder: function (target) {
            this.addPlaceHolderBefore();
            target.append(this.$HiddenBaseElContainer);
            this.addPlaceHolderAfter();
        }
    }, WidgetBase);
});
define('comsys/widget/TextBox', [
    'jquery',
    'Core',
    'Class',
    'comsys/widget/baseClass/HiddenBase'
], function ($, Core, Class, HiddenBase) {
    var ClassName = 'Control.TextBox';
    var TextBox = Class(ClassName, {
        constructor: function (args) {
            this.callParent(args);
            this.$TextBoxEl = $(args.element);
        },
        initialize: function () {
            var $this = this.$TextBoxEl;
            var elName = $this.get(0).type.toLocaleLowerCase();
            if (elName != 'text' && elName != 'password' && elName != 'number')
                return this;
            if ($this.attr('noTextBox') != undefined)
                return this;
            if ($this.data(ClassName) == undefined) {
                this.$TextBoxControl = $('<div class="comsys-base comsys-TextBox"></div>');
                $this.before(this.$TextBoxControl).appendTo(this.$TextBoxControl);
                $this.data(ClassName, this);
                this.callParent();
                this.addPlaceHolder(this.$TextBoxControl);
            }
            return this;
        }
    }, HiddenBase);
    $.fn.extend({
        TextBoxInit: function () {
            return this.each(function () {
                new TextBox({ element: this }).initialize();
            });
        }
    });
    return TextBox;
});
define('comsys/widget/TipTextBox', [
    'jquery',
    'Core',
    'Class',
    'comsys/widget/TextBox'
], function ($, Core, Class, TextBox) {
    var ClassName = 'Control.TipTextBox';
    var TipTextBox = Class(ClassName, {
        constructor: function (args) {
            this.callParent(args);
            this.$TipTextBoxEl = $(args.element);
        },
        initialize: function () {
            var me = this;
            var $this = this.$TipTextBoxEl;
            var NoBindTextBox = $this.data('Control.TextBox') == undefined;
            if (NoBindTextBox) {
                this.$TextBoxEl = this.$TipTextBoxEl;
                this.callParent();
            }
            var title = $this.attr('tip-title');
            if (title && $this.data(ClassName) == undefined) {
                this.$TipTextBoxControl = NoBindTextBox ? this.$TextBoxControl : $this.data('Control.TextBox').$TextBoxControl;
                this.$TipTextBoxControl.addClass('comsys-TipTextBox').append('<span class="comsys-tip-span">' + $this.attr('tip-title') + '</span>');
                var $wrap = this.$TipTextBoxControl;
                var oldvalue = null;
                if ($this.val())
                    $wrap.find('span').hide();
                else
                    $wrap.find('span.comsys-tip-span').show();
                this.$TipTextBoxControl.off('.TipClick').on('click.TipClick', 'span.comsys-tip-span', function () {
                    me.$TipTextBoxEl.focus();
                });
                $this.off('.TipFocusEvent').on('focus.TipFocusEvent', function () {
                    $wrap.find('span.comsys-tip-span').hide();
                });
                $this.off('.TipChangeEvent').on('focusout.TipChangeEvent change.TipChangeEvent keyup.TipChangeEvent', function (e) {
                    var v = $this.val();
                    if (e.type == 'keydown' && oldvalue == v)
                        return;
                    if (v)
                        $wrap.find('span.comsys-tip-span').hide();
                    else
                        $wrap.find('span.comsys-tip-span').show();
                    oldvalue = v;
                });
                $this.removeAttr('tip-title');
                $this.data(ClassName, this);
            }
            return this;
        }
    }, TextBox);
    $.fn.extend({
        TipTextBoxInit: function () {
            return this.each(function () {
                new TipTextBox({ element: this }).initialize();
            });
        }
    });
    return TipTextBox;
});
define('comsys/widget/ButtonTextBox', [
    'jquery',
    'Class',
    'TPLEngine',
    'comsys/widget/TipTextBox'
], function ($, Class, TPLEngine, TipTextBox) {
    var ClassName = 'Control.ButtonTextBox';
    var ButtonTextBox = Class(ClassName, {
        constructor: function (args) {
            this.callParent(args);
            this.setting.ButtonClass = this.setting.ButtonClass || 'comsys-ButtonTextBox-button-icon';
            this.$ButtonTextBoxEl = $(args.element);
            this.ButtonTextBoxRightClickHandler = this.setting.ClickHandler || args.element.onclick || function () {
            };
            args.element.onclick = null;
        },
        initialize: function () {
            var $ElememControl = this.$ButtonTextBoxEl;
            var oData = this;
            if (this.$ButtonTextBoxEl.data('Control.TipTextBox') != undefined || this.$ButtonTextBoxEl.data('Control.TextBox') != undefined) {
                oData = this.$ButtonTextBoxEl.data('Control.TextBox') || this.$ButtonTextBoxEl.data('Control.TipTextBox');
                $ElememControl = oData.$TipTextBoxControl ? oData.$TipTextBoxControl : oData.$TextBoxControl ? oData.$TextBoxControl : this.$ButtonTextBoxEl;
            }
            if (this.$ButtonTextBoxEl.data(ClassName) == undefined) {
                this.$ButtonTextBoxController = $(TPLEngine.render(this.TPL.main, this));
                $ElememControl.parent().append(this.$ButtonTextBoxController);
                this.$ButtonTextBoxController.find('.comsys-ButtonTextBox-input').append(oData ? $ElememControl : this.$ButtonTextBoxEl);
                this.$ButtonTextBoxController.find('.comsys-ButtonTextBox-button').off('.ButtonTextBoxRightClickHandler').on('click.ButtonTextBoxRightClickHandler', this.ButtonTextBoxRightClickHandler);
                this.$ButtonTextBoxEl.data(ClassName, this);
                this.$TipTextBoxEl = this.$ButtonTextBoxEl;
                this.callParent();
                this.$ButtonTextBoxController.append(oData.$HiddenBaseElContainer);
            }
            return this;
        },
        TPL: {
            layout: '<div class=\'comsys-base comsys-ButtonTextBox-layout\' id=\'<%= this.classids%>\'>@{layout}@</div>',
            main: '@{layout:this.TPL.layout,this}@<div class=\'comsys-ButtonTextBox-input\'></div><div class=\'comsys-ButtonTextBox-button <%=this.setting.ButtonClass%>\'></div>'
        }
    }, TipTextBox);
    $.fn.extend({
        ButtonTextBoxInit: function (setting) {
            return this.each(function () {
                new ButtonTextBox({
                    element: this,
                    setting: setting
                }).initialize();
            });
        }
    });
    return ButtonTextBox;
});
define('comsys/widget/baseClass/LabelBase', [
    'jquery',
    'Class',
    'comsys/widget/baseClass/WidgetBase',
    'common/setting'
], function ($, Class, WidgetBase, Setting) {
    var ClassName = 'Control.LabelBase';
    return Class(ClassName, {
        constructor: function (args) {
            this.callParent(args);
        },
        initialize: function () {
            this.callParent();
            var id = this.$BaseEl.attr('id');
            if (id && this.$BaseEl.parent().find('label[for=' + id + ']').length != 0) {
                this.$LabelContainer = this.$BaseEl.parent().find('label[for=' + id + ']');
                return this.moveLabel();
            } else {
                this.$LabelContainer = $('<label for="' + this.$BaseEl.attr('id') + '"></label>');
                return this.wrapLabel();
            }
        },
        moveLabel: function () {
            var data = this.$BaseEl.data(ClassName);
            if (data == undefined) {
                this.$BaseEl.after(this.$LabelContainer).appendTo(this.$LabelContainer);
            } else
                return data;
        },
        wrapLabel: function () {
            var $parent = this.$BaseEl.parent();
            var data = this.$BaseEl.data(ClassName);
            if (data == undefined) {
                if ($parent[0].nodeName != 'LABEL') {
                    var i = 0, nodes = $parent[0].childNodes, o;
                    do {
                    } while ((o = nodes[i++]) && o != this.$BaseEl[0]);
                    this.$BaseEl.after(this.$LabelContainer).appendTo(this.$LabelContainer);
                    var node = Setting.LabelSetting.getNode(nodes[i]);
                    if (Setting.LabelSetting.check(node)) {
                        this.$BaseEl.attr('data-label', $.trim(Setting.LabelSetting.get(node)));
                        this.$LabelContainer.append(node);
                    }
                } else {
                    if ($parent[0].childNodes.length >= 2)
                        this.$BaseEl.attr('data-label', $.trim(Setting.LabelSetting.get($parent[0].childNodes[1])));
                    this.$LabelContainer = $parent;
                }
                return this;
            } else
                return data;
        }
    }, WidgetBase);
});
define('comsys/widget/CheckBox', [
    'jquery',
    'Class',
    'comsys/widget/baseClass/LabelBase'
], function ($, Class, LabelBase) {
    var ClassName = 'Control.CheckBox';
    var CheckBox = Class(ClassName, {
        constructor: function (args) {
            this.callParent(args);
            this.$CheckBoxEl = $(args.element);
        },
        initialize: function () {
            var $this = this.$CheckBoxEl;
            if ($this.data(ClassName) == undefined) {
                this.callParent();
                var id = $this.attr('id');
                this.$CheckBoxControl = $('<div class="comsys-checkbox' + ($this.get(0).checked ? ' checkbox-checked' : '') + '"></div>');
                var $wrap = this.$CheckBoxControl;
                $this.before($wrap).appendTo($wrap);
                var $parent = $wrap.parent();
                if ($parent.get(0).nodeName == 'LABEL') {
                    $parent.addClass('comsys-checkbox-label').attr('for', id);
                }
                $(document).on('click.CheckBoxClickHandler' + id, '#' + id, function () {
                    if (this.checked)
                        $($wrap).addClass('checkbox-checked');
                    else
                        $($wrap).removeClass('checkbox-checked');
                });
                $this.data(ClassName, this);
            }
            return this;
        },
        destory: function () {
            $(document).off('.CheckBoxClickHandler' + this.$CheckBoxEl.attr('id'));
            this.$CheckBoxControl.parent().removeAttr('style');
            this.$CheckBoxControl.after(this.$CheckBoxEl);
            this.$CheckBoxControl.remove();
            this.$CheckBoxEl.removeData(ClassName);
        }
    }, LabelBase);
    $.fn.extend({
        CheckBoxInit: function () {
            return this.each(function () {
                new CheckBox({ element: this }).initialize();
            });
        }
    });
    return CheckBox;
});
define('comsys/widget/RadioBox', [
    'jquery',
    'Class',
    'comsys/widget/baseClass/LabelBase'
], function ($, Class, LabelBase) {
    var ClassName = 'Control.RadioBox';
    var RadioBox = Class(ClassName, {
        constructor: function (args) {
            this.callParent(args);
            this.$RadioBoxEl = $(args.element);
        },
        initialize: function () {
            var $this = this.$RadioBoxEl;
            if ($this.data(ClassName) == undefined) {
                this.callParent();
                var id = $this.attr('id');
                this.$RadioBoxControl = $('<div class="comsys-radiobox' + ($this.get(0).checked ? ' radiobox-checked' : '') + '"></div>');
                var $wrap = this.$RadioBoxControl;
                $this.before($wrap).appendTo($wrap);
                var $parent = $wrap.parent();
                if ($parent.get(0).nodeName == 'LABEL') {
                    $parent.addClass('comsys-checkbox-label').attr('for', id);
                }
                var $group = $('input[name=' + $this.attr('name') + ']');
                $(document).on('click.RadioBoxClickHandler' + id, '#' + id, function (e, state) {
                    if (this.checked)
                        $($wrap).addClass('radiobox-checked');
                    else
                        $($wrap).removeClass('radiobox-checked');
                    if (!state)
                        $group.not(this).trigger('radioChange');
                });
                $this.on('radioChange', function () {
                    if (this.checked)
                        $($wrap).addClass('radiobox-checked');
                    else
                        $($wrap).removeClass('radiobox-checked');
                });
                $this.data(ClassName, this);
            }
            return this;
        },
        destory: function () {
            $(document).off('.RadioBoxClickHandler' + this.$RadioBoxEl.attr('id'));
            this.$RadioBoxControl.parent().removeAttr('style');
            this.$RadioBoxControl.after(this.$RadioBoxEl);
            this.$RadioBoxControl.remove();
        }
    }, LabelBase);
    $.fn.extend({
        RadioBoxInit: function () {
            return this.each(function () {
                new RadioBox({ element: this }).initialize();
            });
        }
    });
    return RadioBox;
});
define('comsys/widget/SingleCombox', [
    'jquery',
    'Class',
    'TPLEngine',
    'comsys/widget/TipTextBox'
], function ($, Class, TPLEngine, TipTextBox) {
    var ClassName = 'Control.SingleCombox';
    var SingleCombox = Class(ClassName, {
        constructor: function (args) {
            this.callParent(args);
            var element = args.element;
            if (element.nodeName && element.nodeName.toLowerCase() != 'select')
                throw new Error('this is not a select');
            this.element = element;
            this.$element = $(element);
            this.appendTo = args.appendTo || document.body;
            this.setting = {
                lineHeight: this.setting.lineHeight || 28,
                dropLength: this.setting.dropLength || 5
            };
            this.element.style.display = 'none';
            this.OnOptionChange = args.onChange || this.element.onchange || function () {
            };
            this.Timer = null;
            var u = /MSIE (\d*).0|Chrome|Firefox/i.exec(window.navigator.userAgent);
            this.LowIEOrNoIE = u != null && ~~u[1] < 8;
        },
        initialize: function () {
            var $this = $(this.element);
            if ($this.data(ClassName) == undefined) {
                this.generate();
                $(this.element).data(ClassName, this);
                this.$TipTextBoxEl = this.$input;
                this.callParent();
            } else {
                $(this.element).trigger('reload');
            }
            return this;
        },
        TPL: {
            layout: '<div class=\'comsys-base comsys-SingleCombox-layout\' id=\'SingleCombox-<%= this.classids%>\'>@{layout}@</div>',
            main: '@{layout:this.TPL.layout,this}@<div class=\'comsys-SingleCombox-input\'><input type=\'text\' <%=$(this.element).attr("readonly")?"readonly":""%> tip-title=\'<%=$(this.element).attr("tip-title")?$(this.element).attr("tip-title"):""%>\' value=\'<%=this.element.options.length==0?\'\':this.element.options[this.element.selectedIndex].text%>\'/></div><div class=\'comsys-SingleCombox-button\'></div>@{section:this.TPL.drop,this}@',
            drop: '<div class=\'comsys-combox-base comsys-SingleCombox-drop\' id=\'SingleCombox-drop-<%= this.classids%>\'><%for(var i=0;i<this.element.options.length;i++){%>@{section:this.TPL.option,this.element.options[i]}@<%}%></div>',
            option: '<div class=\'comsys-base comsys-SingleCombox-option<%=this.selected?\' selected\':\'\'%>\' data-index=\'<%=this.index%>\'><%=this.text%></div>'
        },
        addPlaceHolderAfter: function () {
            this.$controller.prepend(this.$HiddenBaseElContainer);
            this.$HiddenBaseElContainer.append(this.element);
        },
        keyCode: {
            SPACE: 32,
            ENTER: 13,
            DOWN: 40,
            UP: 38,
            SHOW: 540
        },
        generate: function () {
            var THIS = this;
            THIS.state = false;
            THIS.$controller = $(TPLEngine.render(this.TPL.main, this));
            $(this.element.parentNode).append(THIS.$controller);
            THIS.$drop = THIS.$controller.find('.comsys-SingleCombox-drop');
            THIS.$input = THIS.$controller.find('input');
            $(this.appendTo).append(THIS.$drop);
            $(this.element).on('rebind', function () {
                return THIS.ReBind.apply(THIS, arguments);
            }).on('reload', function () {
                return THIS.ReLoad.apply(THIS, arguments);
            });
            THIS.$drop.on('mousedown', function () {
                return THIS.OnDropClick.apply(THIS, arguments);
            });
            THIS.$drop.bind('otherhide', function () {
                return THIS.OnOtherClick.apply(THIS, arguments);
            });
            THIS.$controller.delegate('.comsys-SingleCombox-button', 'click', function () {
                return THIS.OnButtonClick.apply(THIS, arguments);
            });
            THIS.$controller.delegate('.comsys-SingleCombox-input input', 'keydown', function () {
                return THIS.OnKeyDown.apply(THIS, arguments);
            });
            THIS.$drop.get(0).onmousewheel = function (e) {
                return THIS.OnMouseWheel.call(THIS, e, THIS.$drop.get(0));
            };
            THIS.$input.off('.SingleComboxFocusOut').on('focusout.SingleComboxFocusOut', function () {
                return THIS.OnFocusOut.apply(THIS, arguments);
            });
            THIS.$drop.delegate('.comsys-SingleCombox-option', 'click', function () {
                return THIS.OnOptionClick.apply(THIS, [
                    arguments[0],
                    this
                ]);
            });
        },
        ReBind: function () {
            var THIS = this;
            THIS.state = true;
            THIS.SelectedIndex(THIS.SelectedIndex());
        },
        ReLoad: function () {
            var THIS = this;
            THIS.$drop.html($(TPLEngine.render(this.TPL.drop, this)).html());
            this.ReBind();
        },
        OnOtherClick: function () {
            this.state = false;
        },
        OnMouseWheel: function (e, scroller) {
            var THIS = this;
            var k = e.wheelDelta ? e.wheelDelta / 120 * THIS.setting.lineHeight : -e.detail;
            scroller.scrollTop = scroller.scrollTop - k;
            return false;
        },
        OnOptionClick: function (e, t) {
            var THIS = this;
            THIS.element.selectedIndex = $(t).attr('data-index');
            THIS.$input.val(THIS.element.options[THIS.element.selectedIndex].text);
            THIS.element.options[THIS.element.selectedIndex].selected = true;
            THIS.DropHide();
        },
        OnDropClick: function (e) {
            var THIS = this;
            var p = e.currentTarget || e.delegateTarget;
            var c = e.target || e.toElement;
            THIS.cancelFocusOut = true;
            window.clearTimeout(THIS.Timer);
            THIS.Timer = null;
            var d = THIS.$drop.get(0);
            if (p.id == c.id && d.scrollHeight < d.offsetHeight)
                THIS.DropHide();
        },
        OnFocusOut: function () {
            var THIS = this;
            if (!THIS.cancelFocusOut) {
                THIS.Timer = window.setTimeout(function () {
                    THIS.DropHide();
                }, 10);
            }
            THIS.cancelFocusOut = false;
        },
        DropHide: function () {
            var THIS = this;
            if (!THIS.state)
                return;
            window.clearTimeout(THIS.Timer);
            THIS.Timer = null;
            THIS.$drop.hide();
            THIS.state = false;
            if (THIS.element.selectedIndex != -1) {
                THIS.$input.val(THIS.element.options[THIS.element.selectedIndex].text);
                THIS.element.options[THIS.element.selectedIndex].selected = true;
            } else
                THIS.$input.val('');
            THIS.cancelFocusOut = true;
            if (THIS.LastKey != THIS.$input.val()) {
                THIS.OnOptionChange.apply(this.element);
                THIS.LastKey = THIS.$input.val();
            }
            THIS.cancelFocusOut = false;
            THIS.$input.trigger('focusout.TipChangeEvent');
            $(document).off('.outerClickListener');
        },
        SelectedIndex: function () {
            var THIS = this;
            if (arguments.length === 0)
                return THIS.element.selectedIndex;
            else {
                THIS.element.selectedIndex = arguments[0];
                THIS.DropHide();
            }
        },
        Value: function () {
            var THIS = this;
            if (arguments.length === 0)
                return THIS.element.options[THIS.element.selectedIndex].value;
            else {
                for (var i = 0; i < THIS.element.options.length; i++) {
                    var option = THIS.element.options[i];
                    if (option.value === arguments[0]) {
                        THIS.SelectedIndex(option.index);
                        break;
                    }
                }
            }
        },
        OnOtherAreaClick: function (e) {
            var THIS = this;
            var $t = $(e.target || e.toElement), $d = $t.closest('.comsys-SingleCombox-drop'), $l = $t.closest('.comsys-SingleCombox-layout'), $did = $d.attr('id'), $tdid = 'SingleCombox-drop-' + THIS.classids, $lid = $l.attr('id'), $tlid = 'SingleCombox-' + THIS.classids;
            if ($d.length == 0 && $l.length == 0 || $d.length != 0 && $did != $tdid || $l.length != 0 && $lid != $tlid) {
                THIS.DropHide();
                return;
            }
            THIS.cancelFocusOut = true;
        },
        OnButtonClick: function (e, isFilter, type, isRange) {
            var THIS = this;
            window.clearTimeout(THIS.Timer);
            THIS.Timer = null;
            var offset = THIS.Offset(THIS.$controller.get(0));
            if (!THIS.state) {
                THIS.$input.focus();
                $('div.comsys-combox-base:visible').hide().trigger('otherhide');
                if (THIS.element.options.length == 0)
                    return false;
                THIS.$drop.css({
                    left: -99999,
                    maxHeight: THIS.setting.lineHeight * THIS.setting.dropLength
                }).show();
                THIS.$drop.css({
                    minWidth: THIS.$controller.width() + 2 - (THIS.LowIEOrNoIE || THIS.$drop.get(0).scrollHeight < THIS.$drop.get(0).offsetHeight ? 0 : 17),
                    left: offset.left,
                    top: offset.top + THIS.$controller.height() + 4
                });
                THIS.state = true;
                $(document).off('.outerClickListener').on('mousedown.outerClickListener', function () {
                    return THIS.OnOtherAreaClick.apply(THIS, arguments);
                });
            } else if (!isFilter && THIS.state) {
                THIS.DropHide();
            }
            if (THIS.element.selectedIndex !== -1) {
                THIS.$drop.find('.selected').removeClass('selected').end().find('div.comsys-SingleCombox-option:eq(' + THIS.element.selectedIndex + ')').addClass('selected');
            } else {
                THIS.$drop.find('.selected').removeClass('selected');
            }
            THIS.OptionPosition(!isFilter & THIS.state ? THIS.keyCode.SHOW : type, isRange);
        },
        OptionPosition: function (type, isRange) {
            var THIS = this;
            var obj = THIS.$drop.find('.selected').get(0);
            var drop = THIS.$drop.get(0);
            if (!obj) {
                drop.scrollTop = 0;
                return;
            }
            var top = obj.offsetTop;
            switch (type) {
            case THIS.keyCode.DOWN:
                if (isRange)
                    drop.scrollTop = 0;
                else {
                    if (drop.scrollTop + drop.offsetHeight - 2 <= top)
                        drop.scrollTop = top - drop.offsetHeight + obj.offsetHeight;
                }
                break;
            case THIS.keyCode.UP:
                if (isRange)
                    drop.scrollTop = drop.scrollHeight;
                else {
                    if (drop.scrollTop > top)
                        drop.scrollTop = top;
                }
                break;
            case THIS.keyCode.SHOW:
            default:
                drop.scrollTop = top;
                break;
            }
            if (THIS.element.selectedIndex !== -1) {
                THIS.$drop.find('.selected').removeClass('selected').end().find('div.comsys-SingleCombox-option:eq(' + THIS.element.selectedIndex + ')').addClass('selected');
            } else {
                THIS.$drop.find('.selected').removeClass('selected');
            }
        },
        OnKeyDown: function (e) {
            var THIS = this;
            var isRange = false;
            switch (e.keyCode) {
            case THIS.keyCode.DOWN:
                if (THIS.state) {
                    isRange = THIS.element.selectedIndex === THIS.element.options.length - 1;
                    isRange ? THIS.element.selectedIndex = 0 : THIS.element.selectedIndex += 1;
                }
                THIS.$controller.find('.comsys-SingleCombox-button').trigger('click', [
                    true,
                    e.keyCode,
                    isRange
                ]);
                e.stopPropagation();
                return false;
            case THIS.keyCode.UP:
                if (THIS.state) {
                    isRange = THIS.element.selectedIndex === 0;
                    isRange ? THIS.element.selectedIndex = THIS.element.options.length - 1 : THIS.element.selectedIndex -= 1;
                }
                THIS.$controller.find('.comsys-SingleCombox-button').trigger('click', [
                    true,
                    e.keyCode,
                    isRange
                ]);
                e.stopPropagation();
                return false;
            case THIS.keyCode.ENTER:
                var index = THIS.$drop.find('.selected').attr('data-index');
                THIS.element.selectedIndex = index == undefined ? -1 : index;
                THIS.DropHide();
                e.stopPropagation();
                return false;
            default:
                THIS.FTimer = window.setTimeout(function () {
                    if (THIS.LastKey != THIS.$input.val()) {
                        THIS.Search(THIS.$input.val());
                        THIS.LastKey = THIS.$input.val();
                    }
                });
                break;
            }
        },
        Search: function (key) {
            var index = -1;
            var THIS = this;
            if (key !== '') {
                var options = $(THIS.element).find('option:contains(\'' + $.trim(key) + '\')');
                if (options.length != 0) {
                    index = options[0].index;
                }
            }
            THIS.element.selectedIndex = index;
            THIS.$controller.find('.comsys-SingleCombox-button').trigger('click', [
                true,
                THIS.keyCode.SHOW,
                false
            ]);
        },
        Offset: function (obj) {
            var THIS = this, o = obj, re = {
                    left: 0,
                    top: 0
                }, pos, outer = false;
            do {
                re.left += o.offsetLeft;
                re.top += o.offsetTop;
                o = o.offsetParent;
                if (!o)
                    break;
                outer = !outer ? THIS.appendTo === o : true;
                pos = $(o).css('position');
            } while (outer && pos !== 'absolute' && pos !== 'relative' || outer === false);
            return re;
        }
    }, TipTextBox);
    $.fn.extend({
        SingleComboxInit: function () {
            return this.each(function () {
                new SingleCombox({ element: this }).initialize();
            });
        }
    });
    return SingleCombox;
});
var WebApi = {};
define('application', [
    'jquery',
    'common/setting',
    'comsys/layout/MaskLayer',
    'comsys/widget/Window',
    '../../Content/js/util/common',
    'common/client/XImage',
    'common/client/Sync',
    'vue',
    'comsys/widget/TextBox',
    'comsys/widget/TipTextBox',
    'comsys/widget/ButtonTextBox',
    'comsys/widget/CheckBox',
    'comsys/widget/RadioBox',
    'comsys/widget/SingleCombox'
], function ($, CommonSetting, MaskLayer, Win, common, XImage, Sync) {
    var layer = new MaskLayer(CommonSetting.layerSetting);
    var concatArg = function (arg, arr) {
        return [].splice.call(arg, 0).concat(arr);
    };
    $.extend(WebApi, {
        progress: function (setting) {
            layer.upload(setting);
        },
        showlayer: function (text, setting) {
            layer.show(text, setting);
        },
        hidelayer: function () {
            layer.hide();
        },
        confirm: function (message) {
            return Win.show({
                content: message,
                buttons: Window.button.OKANDCANCEL,
                icon: Window.icon.question
            });
        },
        alert: function (message) {
            return Win.show({
                content: message,
                buttons: Window.button.OK,
                icon: Window.icon.info
            });
        },
        error: function (message) {
            return Win.show({
                content: message,
                buttons: Window.button.OK,
                icon: Window.icon.error
            });
        },
        modal: function () {
            return Win.show.apply(Win, concatArg(arguments, ['window']));
        },
        window: function () {
            var arr = concatArg(arguments, ['resizewindow']);
            return Win.show.apply(Win, arr);
        },
        close: function (setting) {
            setting = setting || {};
            if (!Window.close(undefined, setting.name, setting.command) && !setting.formChild && window.parent && window.parent.WebApi)
                window.parent.WebApi.close({
                    name: setting.name,
                    command: setting.command,
                    formChild: true
                });
        },
        initControl: function (parent) {
            var $parent = parent ? $(parent) : $(document);
            $parent.find('input[tip-title]').TipTextBoxInit();
            $parent.find('select').SingleComboxInit();
            $parent.find('input[type=\'text\']').TextBoxInit();
            $parent.find(':radio').RadioBoxInit();
            $parent.find(':checkbox').CheckBoxInit();
        },
        ImageViewerInit: function () {
            Sync.ClearAsync('ImageLoad');
            $('div.imageViewer[bind-width][bind-height][bind-src]').each(function (i) {
                var $this = $(this);
                Sync.SetAsync(function () {
                    var width = $this.attr('bind-width'), height = $this.attr('bind-height'), src = $this.attr('bind-src'), after = function () {
                            $(this.re).fadeIn();
                        }, before = function () {
                            $(this.re).hide();
                        };
                    $this.css({ lineHeight: height + 'px' }).removeAttr('bind-width').removeAttr('bind-height').removeAttr('bind-src').prepend(new XImage(src, width, height, after, after, before, before));
                }, 'ImageLoad', i * 50);
            });
        }
    });
    return {
        interface: function (action) {
            common.init();
            if (action) {
                $.extend(WebApi, action);
                WebApi.init();
            }
        },
        initialize: function () {
            var browser = CommonSetting.Browser();
            document.getElementsByTagName('HTML').item(0).className = browser;
            WebApi.ImageViewerInit();
            this.load();
        },
        load: function () {
            var scripts = document.getElementsByTagName('script'), l = scripts.length, main;
            for (var i = 0; i < l; i++)
                if (main = scripts[i].getAttribute('main'))
                    break;
            if (main)
                require(['../../Content/js/' + main], this.interface);
            else
                common.init();
        }
    };
});
require.config({
    baseUrl: 'Static/js',
    paths: {
        'css': 'libs/require-css/css.min',
        'jquery': 'libs/jquery/dist/jquery.min',
        'jquery.ui': 'libs/jquery-ui',
        'Class': 'common/core/Class',
        'Core': 'common/core/Core',
        'Guid': 'common/core/Guid',
        'TPLEngine': 'common/engine/tplEngine',
        'widget': 'comsys/widget',
        'client': 'common/client',
        'vue': 'libs/vue/dist/vue'
    }
});
require([
    'jquery',
    'application'
], function ($, application) {
    application.initialize();
});
define('config', [
    'jquery',
    'application'
], function () {
    return;
});