define(function(){
	return {
		init:function(){
			$("#search").ButtonTextBoxInit({ButtonClass:"search"});
		}
	}
})